﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace MvcApplication_HostelManagementProject.Models
{
    public class RoomAllocationModel
    {

        public int RoomAlocationID { get; set; }

        
        public int RoomNo { get; set; }

        [Required(ErrorMessage="Enter Inmate ID")]
        [Remote("checkID", "Home", ErrorMessage = "Inmate Already exists")]

        public int InmateID { get; set; }

        [Required(ErrorMessage="Enter Start Date-- Format MM/DD/YYYY")]
        public DateTime Startdate { get; set; }

        [Required(ErrorMessage = "Enter Start Date-- Format MM/DD/YYYY")]
        public DateTime EndDate { get; set; }

        

        
    }
}