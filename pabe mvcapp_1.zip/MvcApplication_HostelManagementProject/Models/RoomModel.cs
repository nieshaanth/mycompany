﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication_HostelManagementProject.Models
{
    public class RoomModel
    {
        public int RoomNo { get; set; }
        public int NoOfPersons { get; set; }
        public int Availability { get; set; }
        public string RoomType { get; set; }
        public string RoomDetails { get; set; }
        public int Price { get; set; }
        public string Image { get; set; }
    }
}