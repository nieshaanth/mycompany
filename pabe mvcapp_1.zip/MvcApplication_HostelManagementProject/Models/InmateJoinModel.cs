﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication_HostelManagementProject.Models
{
    public class InmateJoinModel
    {
        public int InmateID { get; set; }
        public int RoomNo { get; set; }
        public string InmateName { get; set; }
        public string Address { get; set; }
        public string ContactNo { get; set; }
        public string PanNumber { get; set; }
        public string ImageAddress { get; set; }
        public int RoomAllocationID { get; set; }
        


    }
}