﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;

namespace MvcApplication_HostelManagementProject.Models
{
    public class EmployeesDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool AddEmployee(EmployeesModel model)
        {
            try
            {

                SqlCommand com_add_employee = new SqlCommand("insert Employees values(@name,@salary,@desg,@addr,null)", con);
                com_add_employee.Parameters.AddWithValue("@name", model.EmployeeName);
                com_add_employee.Parameters.AddWithValue("@salary", model.EmployeeSalary);
                com_add_employee.Parameters.AddWithValue("@desg", model.EmployeeDesignation);
                com_add_employee.Parameters.AddWithValue("@addr", model.EmployeeAddress);

                con.Open();
                SqlTransaction tran = con.BeginTransaction();
                com_add_employee.Transaction = tran;
                com_add_employee.ExecuteNonQuery();

                SqlCommand com_empid = new SqlCommand("select @@identity", con);
                com_empid.Transaction = tran;
                int empid = Convert.ToInt32(com_empid.ExecuteScalar());
                model.EmployeeID = empid;

                model.EmployeeImageAdddress = "/Images/" + empid + ".jpg";
                SqlCommand com_product_update_image_address = new SqlCommand("update Employees set EmployeeImageAddress=@address where EmployeeID=@empid", con);
                com_product_update_image_address.Parameters.AddWithValue("@empid", model.EmployeeID);
                com_product_update_image_address.Parameters.AddWithValue("@address", model.EmployeeImageAdddress);

                com_product_update_image_address.Transaction = tran;
                com_product_update_image_address.ExecuteNonQuery();
                tran.Commit();
                con.Close();

                MembershipCreateStatus status;
                Membership.CreateUser(model.EmployeeID.ToString(), model.Password, model.EmailID, model.SecurityQuestion, model.SecurityAnswer, true, out status);
                if (status == MembershipCreateStatus.Success)
                {
                    return true;
                }

                else
                {
                    return false;
                }
            }
            finally
            {
                if(con.State==System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

    }
}