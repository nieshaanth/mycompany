﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace MvcApplication_HostelManagementProject.Models
{
    public class InmateModel
    {
        public int InmateID { get; set; }

        [Required(ErrorMessage = "Enter Name")]
        [StringLength(50, MinimumLength = 5, ErrorMessage = "Name 5-50 chars")]
        [RegularExpression("[a-zA-Z]+$", ErrorMessage = "Only alphabets are allowed")]
        [Display(Name="Your name")]
        public string InmateName { get; set; }

        [Required(ErrorMessage = "Enter address")]
        [StringLength(50, MinimumLength = 5, ErrorMessage = "Address 5-50 chars")]
        [RegularExpression("[a-zA-Z]+$", ErrorMessage = "Only alphabets are allowed")]
        [Display(Name = "Your Addrerss")]
        public string Address { get;set;}

        [Required(ErrorMessage = "Enter Contact No")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Mobile no: 10")]
        [Display(Name = "Your Contact Number")]
        public string ContactNo { get; set; }

        [Required(ErrorMessage = "Enter PAN ")]
        public string PanNumber { get; set; }
       
        [Required(ErrorMessage = "Choose Image ")]
        [Display(Name = "Choose Image")]
        public string ImageAddress { get; set; }

        [EmailAddress(ErrorMessage = "Invalid Email")]
        [Required(ErrorMessage = "EnterEmailAddress")]
        [Display(Name = "Your Email ID")]
        public string EmailID { get; set; }

        [Required(ErrorMessage = "Enter security Question")]
        [Display(Name = "Security Question")]
        public string SecurityQuestion { get; set; }

        [Required(ErrorMessage = "Enter Security Answer")]
        [Display(Name = "Security Answer")]
        public string SecurityAnswer { get; set; }

        [Required(ErrorMessage = "Enter password")]
        public string Password { get; set; }

        public int RoomNo { get; set; }

        public string status { get; set; }
        public int MonthlyBill { get; set; }
    }
}