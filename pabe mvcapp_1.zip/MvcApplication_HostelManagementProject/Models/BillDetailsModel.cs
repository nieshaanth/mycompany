﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication_HostelManagementProject.Models
{
    public class BillDetailsModel
    {
        public int BillNo { get; set; }
        public int RoomRent { get; set; }
        public int FacilityCharge{ get; set; }
    }
}