﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace MvcApplication_HostelManagementProject.Models
{
    public class BillsDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        
        public bool GenerateBill(BillsModel model)
        {
            try
            {
                SqlCommand com_get_inmate = new SqlCommand("select inmateid from inmate where status='Staying' and inmateid not in ( select inmateid from bill where billmonth=@month and billyear=@year)", con);
                com_get_inmate.Parameters.AddWithValue("@month", model.BillMonth);
                com_get_inmate.Parameters.AddWithValue("@year", model.BillYear);
                con.Open();
                
               
                SqlDataReader dr = com_get_inmate.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        model.InmateId = dr.GetInt32(0);

                        SqlCommand com_amount = new SqlCommand("insert Bill values(@id,0,@month,@year,getdate(),'Not Paid')", con);
                        com_amount.Parameters.AddWithValue("@id", model.InmateId);
                        com_amount.Parameters.AddWithValue("@month", model.BillMonth);
                        com_amount.Parameters.AddWithValue("@year", model.BillYear);
                      
                        com_amount.ExecuteNonQuery();

                        SqlCommand com_get_billno = new SqlCommand("select @@identity", con);
                        
                        int billno = Convert.ToInt32(com_get_billno.ExecuteScalar());

                        SqlCommand com_billdetails = new SqlCommand("select price,FaciltyCharges from roomallocationdetails join Room on roomallocationdetails.roomno=Room.roomno join (select roomallocationid,sum(amount)as FaciltyCharges from RoomFacility group by roomallocationid) as y on roomallocationdetails.roomallocationid=y.roomallocationid where inmateid=@id", con);
                        com_billdetails.Parameters.AddWithValue("@id", model.InmateId);
                        
                        SqlDataReader dr_bill = com_billdetails.ExecuteReader();
                        int billamount = 0;
                        if (dr_bill.Read())
                        {
                            int rent = dr_bill.GetInt32(0);
                            int faccharge = dr_bill.GetInt32(1);
                            billamount = rent + faccharge;
                            SqlCommand com_insert_bill_details = new SqlCommand("insert billdetails values(@billno,@id,@rent,@charge)", con);
                            com_insert_bill_details.Parameters.AddWithValue("@billno", billno);
                            com_insert_bill_details.Parameters.AddWithValue("@id", model.InmateId);
                            com_insert_bill_details.Parameters.AddWithValue("@rent", dr_bill.GetInt32(0));
                            com_insert_bill_details.Parameters.AddWithValue("@charge", dr_bill.GetInt32(1));
                           
                            com_insert_bill_details.ExecuteNonQuery();
                            
                        }
                      
                        SqlCommand com_update = new SqlCommand("update Bill set Billamount=@billamount where inmateid=@id", con);
                        com_update.Parameters.AddWithValue("@id", model.InmateId);
                        com_update.Parameters.AddWithValue("@billamount", billamount);
                    
                        com_update.ExecuteNonQuery();
                        
                    }
                   
                    return true;
                }
              
                else
                {
                   
                    return false;
                }
                 
            }
                
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    
                    con.Close();
                }
            }
                
        }

        public List<BillsModel> ShowBillDetails(int inmateid)
        {
            SqlCommand com_showbill = new SqlCommand("select * from bill where BillStatus='Not Paid' and inmateid=@inmateid",con);
            com_showbill.Parameters.AddWithValue("@inmateid",inmateid);
            List<BillsModel> list = new List<BillsModel>();
            con.Open();
            SqlDataReader dr = com_showbill.ExecuteReader();
            while(dr.Read())
            {
                BillsModel model = new BillsModel();
                model.BillNo = dr.GetInt32(0);
                model.BillAmount = dr.GetInt32(2);
                model.BillMonth = dr.GetInt32(3);
                model.BillYear = dr.GetInt32(4);
                list.Add(model);
            }
            con.Close();
            return list;

        }

        public BillDetailsModel GetBillDetails(int billno, int inmateid)
        {
            SqlCommand com_get = new SqlCommand("select * from BillDetails where billno=@no and inmateid=@id",con);
            com_get.Parameters.AddWithValue("@no",billno);
            com_get.Parameters.AddWithValue("@id",inmateid);
            con.Open();
            BillDetailsModel bill = new BillDetailsModel();
            SqlDataReader dr = com_get.ExecuteReader();
            if(dr.Read())
            {
                
                bill.BillNo = dr.GetInt32(0);
                bill.RoomRent = dr.GetInt32(2);
                bill.FacilityCharge = dr.GetInt32(3);
                
            }
            con.Close();
            return bill;

        }


        public bool GenerateBillForInmate(BillsModel model)
        {
            SqlCommand com_insert_bill = new SqlCommand("select count(*) from inmate where status='Staying' and inmateid not in( select inmateid from bill where billmonth=@month and billyear=@year) ", con);
            com_insert_bill.Parameters.AddWithValue("@month",model.BillMonth);
            com_insert_bill.Parameters.AddWithValue("@year",model.BillYear);
            con.Open();
            int count=Convert.ToInt32( com_insert_bill.ExecuteScalar() );
            if(count==1)
            {
                SqlCommand com_amount = new SqlCommand("insert Bill values(@id,0,@month,@year,getdate(),'Not Paid')", con);
                com_amount.Parameters.AddWithValue("@id", model.InmateId);
                com_amount.Parameters.AddWithValue("@month", model.BillMonth);
                com_amount.Parameters.AddWithValue("@year", model.BillYear);

                com_amount.ExecuteNonQuery();

                SqlCommand com_get_billno = new SqlCommand("select @@identity", con);

                int billno = Convert.ToInt32(com_get_billno.ExecuteScalar());

               

                SqlCommand com_roomrent = new SqlCommand("select price,FaciltyCharges from roomallocationdetails join Room on roomallocationdetails.roomno=Room.roomno join (select roomallocationid,sum(amount)as FaciltyCharges from RoomFacility group by roomallocationid) as y on roomallocationdetails.roomallocationid=y.roomallocationid where inmateid=@id", con);
                com_roomrent.Parameters.AddWithValue("@id",model.InmateId);
                SqlDataReader dr_bill = com_roomrent.ExecuteReader();
                int billamount = 0;
                if (dr_bill.Read())
                {
                    int rent = dr_bill.GetInt32(0);
                    int faccharge = dr_bill.GetInt32(1);
                    billamount = rent + faccharge;
                    SqlCommand com_insert_bill_details = new SqlCommand("insert billdetails values(@billno,@id,@rent,@charge)", con);
                    com_insert_bill_details.Parameters.AddWithValue("@billno", billno);
                    com_insert_bill_details.Parameters.AddWithValue("@id", model.InmateId);
                    com_insert_bill_details.Parameters.AddWithValue("@rent", dr_bill.GetInt32(0));
                    com_insert_bill_details.Parameters.AddWithValue("@charge", dr_bill.GetInt32(1));

                    com_insert_bill_details.ExecuteNonQuery();

                }

                SqlCommand com_update = new SqlCommand("update Bill set Billamount=@billamount where inmateid=@id", con);
                com_update.Parameters.AddWithValue("@id", model.InmateId);
                com_update.Parameters.AddWithValue("@billamount", billamount);

                com_update.ExecuteNonQuery();
                con.Close();
                return true;      
            }
            else
            {
                con.Close();
                return false;
            }
           
        }


        public List<BillsModel> GetBill()
        {
            SqlCommand com_get = new SqlCommand("select * from Bill order by billno",con);
   
            List<BillsModel> list = new List<BillsModel>();
            con.Open();
            SqlDataReader dr = com_get.ExecuteReader();
            while (dr.Read())
            {
                BillsModel bill = new BillsModel();
                bill.BillNo = dr.GetInt32(0);
                bill.InmateId = dr.GetInt32(1);
                bill.BillAmount = dr.GetInt32(2);
                bill.BillMonth = dr.GetInt32(3);
                bill.BillYear = dr.GetInt32(4);
                bill.BillGenDate = dr.GetDateTime(5);
                bill.status = dr.GetString(6);
                list.Add(bill);

            }
            con.Close();
            return list;

        }
    }
}