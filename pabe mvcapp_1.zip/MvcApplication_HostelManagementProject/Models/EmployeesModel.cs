﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace MvcApplication_HostelManagementProject.Models
{
    public class EmployeesModel
    {
        public int EmployeeID { get; set; }

        [Required(ErrorMessage="Enter Employee Name")]
        [StringLength(50,MinimumLength=5,ErrorMessage="Minimum 5 chars")]
        [Display(Name = "Your Name")]
        [RegularExpression("[a-zA-Z]+$", ErrorMessage = "Only alphabets are allowed")]
        public string EmployeeName { get; set; }
        
        [Required(ErrorMessage="Enter Salary")]
        [Display(Name = "Salary")]
        public int EmployeeSalary { get; set; }

        [Required(ErrorMessage="Enter Employee Designation")]
        [Display(Name = "Your Designation")]
        [RegularExpression("[a-zA-Z]+$", ErrorMessage = "Only alphabets are allowed")]
        public string EmployeeDesignation { get; set; }

        [Required(ErrorMessage="Enter Address")]
        [StringLength(50, MinimumLength = 5, ErrorMessage = "Minimum 5 chars")]
        [Display(Name = "Your address")]
        [RegularExpression("[a-zA-Z]+$", ErrorMessage = "Only alphabets are allowed")]
        public string EmployeeAddress { get; set; }

        [Required(ErrorMessage="Choose Image")]
        [Display(Name = "Choose Image")]
        public string EmployeeImageAdddress { get; set; }

        [EmailAddress(ErrorMessage="Invalid Email")]
        [Required(ErrorMessage="EnterEmailAddress")]
        [Display(Name = "Enter Email ID")]
        public string EmailID { get; set; }

        [Required(ErrorMessage = "Enter security Question")]
        [Display(Name = "Security Question")]
        public string SecurityQuestion { get; set; }

        [Required(ErrorMessage = "Enter Security Answer")]
        [Display(Name = "Security Answer")]
        public string SecurityAnswer { get; set; }

        [Required(ErrorMessage = "Enter password")]
        public string Password { get; set; }

    }
}