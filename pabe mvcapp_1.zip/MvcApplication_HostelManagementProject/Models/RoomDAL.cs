﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

namespace MvcApplication_HostelManagementProject.Models
{
    public class RoomDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        //public List<RoomModel> GetRoom()
        //{
        //    List<RoomModel> list_room = new List<RoomModel>();
        //    SqlCommand com_room = new SqlCommand("select * from Room where Availability>0", con);
        //    con.Open();
        //    SqlDataReader dr = com_room.ExecuteReader();
        //    while (dr.Read())
        //    {
        //        RoomModel room = new RoomModel();
        //        room.RoomNo = dr.GetInt32(0);
        //        room.NoOfPersons = dr.GetInt32(1);
        //        list_room.Add(room);

        //    }
        //    con.Close();
        //    return list_room;
        //}

        public List<RoomModel> ShowRoom()
        {
            List<RoomModel> list_room = new List<RoomModel>();
            SqlCommand com_room = new SqlCommand("select * from Room where Availability>0", con);
            con.Open();
            SqlDataReader dr = com_room.ExecuteReader();
            while (dr.Read())
            {
                RoomModel room = new RoomModel();
                room.RoomNo = dr.GetInt32(0);
                room.NoOfPersons = dr.GetInt32(1);
                room.Availability = dr.GetInt32(2);
                room.RoomType = dr.GetString(3);
                room.RoomDetails = dr.GetString(4);
                room.Price = dr.GetInt32(5);
                room.Image = dr.GetString(6);
                list_room.Add(room);

            }
            con.Close();
            return list_room;
        }

        
    }
}