﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;


namespace MvcApplication_HostelManagementProject.Models
{
    public class FacilityDetails
    {
        public int FacilityID { get; set; }
        public int AllocationID { get; set; }
        public string Status { get; set; }
        public int Amount { get; set; }

    }
}