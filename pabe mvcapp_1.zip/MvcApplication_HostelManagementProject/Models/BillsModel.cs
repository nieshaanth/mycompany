﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication_HostelManagementProject.Models
{
    public class BillsModel
    {
        public int BillNo{get;set;}
        public int InmateId{get;set;}
        public int BillAmount{get;set;}
        public int BillMonth { get; set; }
        public int BillYear { get; set; }
        public DateTime BillGenDate{get;set;}
        public string status{get;set;}
    }
}