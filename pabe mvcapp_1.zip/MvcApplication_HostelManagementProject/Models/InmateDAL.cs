﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;

namespace MvcApplication_HostelManagementProject.Models
{
    public class InmateDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddInmate(InmateModel model)
        {
            try
            {
                SqlCommand com_add_inmate = new SqlCommand("insert Inmate values(@name,@addr,@number,@pan,null,'Staying')", con);
                com_add_inmate.Parameters.AddWithValue("@name", model.InmateName);

                com_add_inmate.Parameters.AddWithValue("@addr", model.Address);
                com_add_inmate.Parameters.AddWithValue("@number", model.ContactNo);
                com_add_inmate.Parameters.AddWithValue("@pan", model.PanNumber);

                con.Open();
                SqlTransaction tran = con.BeginTransaction();
                com_add_inmate.Transaction = tran;
                com_add_inmate.ExecuteNonQuery();

                SqlCommand com_empid = new SqlCommand("select @@identity", con);
                com_empid.Transaction = tran;
                int id = Convert.ToInt32(com_empid.ExecuteScalar());
                model.InmateID = id;

                model.ImageAddress = "/Images/" + model.InmateID + ".jpg";
                SqlCommand com_update_image_address = new SqlCommand("update Inmate set InmatePhotoAddress=@address where InmateID=@id", con);
                com_update_image_address.Parameters.AddWithValue("@id", model.InmateID);
                com_update_image_address.Parameters.AddWithValue("@address", model.ImageAddress);
                com_update_image_address.Transaction = tran;
                com_update_image_address.ExecuteNonQuery();
                


                MembershipCreateStatus status;
                Membership.CreateUser(model.InmateID.ToString(), model.Password, model.EmailID, model.SecurityQuestion, model.SecurityAnswer, true, out status);
                if (status == MembershipCreateStatus.Success)
                {
                    tran.Commit();
                    con.Close();
                    return true;
                }

                else
                {

                    return false;
                }
            }
            finally
            {
                if(con.State==System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public List<InmateModel> GetInmates()
        {
            SqlCommand com_get = new SqlCommand("select inmate.inmateid,inmate.inmatename,r.roomno,inmate.InmatePhotoAddress from Inmate join RoomAllocationDetails as r on inmate.inmateid=r.inmateid",con);
            con.Open();
            SqlDataReader dr = com_get.ExecuteReader();
            List<InmateModel> list_inmate = new List<InmateModel>();
            while(dr.Read())
            {
                InmateModel inmate = new InmateModel();
                inmate.InmateID = dr.GetInt32(0);
                inmate.InmateName = dr.GetString(1);
                inmate.RoomNo = dr.GetInt32(2);
                inmate.ImageAddress = dr.GetString(3);
                list_inmate.Add(inmate);

            }
            con.Close();
            return list_inmate;
        }

        public bool CheckInmateID(int inmateid)
        {
            SqlCommand com_check = new SqlCommand("select count(*) from RoomAllocationDetails where inmateid=@id",con);
            com_check.Parameters.AddWithValue("@id",inmateid);
            con.Open();
            int count = Convert.ToInt32(com_check.ExecuteScalar());
            con.Close();
            if(count>0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public InmateJoinModel ShowInmate(int inmateid)
        {
            SqlCommand com_show = new SqlCommand("select inmate.inmateid,inmate.inmatename,RoomAllocationDetails.RoomNo,inmate.address,inmate.ContactNo,inmate.PanNumber,inmate.InmatePhotoAddress,RoomAllocationDetails.RoomAllocationID from Inmate join RoomAllocationDetails on Inmate.inmateid=RoomAllocationDetails.inmateid where inmate.inmateid=@inmateid",con);
            com_show.Parameters.AddWithValue("@inmateid",inmateid);
            InmateJoinModel model = new InmateJoinModel();
            con.Open();
            SqlDataReader dr = com_show.ExecuteReader();
            if(dr.Read())
            {
                model.InmateID = dr.GetInt32(0);
                model.InmateName = dr.GetString(1);
                model.RoomNo = dr.GetInt32(2);
                model.Address = dr.GetString(3);
                model.ContactNo = dr.GetString(4);
                model.PanNumber = dr.GetString(5);
                model.ImageAddress = dr.GetString(6);
                model.RoomAllocationID = dr.GetInt32(7);

            }
            return model;
        }

        


    }
}