﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace MvcApplication_HostelManagementProject.Models
{
    public class RoomAllocationDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        
        public bool AllocateRoom(RoomAllocationModel model)
        {
            SqlCommand com_insert = new SqlCommand("insert RoomAllocationDetails values(@roomno,@inmateid,@sdate,@edate)", con);
            com_insert.Parameters.AddWithValue("@roomno",model.RoomNo);
            com_insert.Parameters.AddWithValue("@inmateid",model.InmateID);
            com_insert.Parameters.AddWithValue("@sdate",model.Startdate);
            com_insert.Parameters.AddWithValue("@edate",model.EndDate);

            con.Open();
            com_insert.ExecuteNonQuery();

            SqlCommand com_allocationid = new SqlCommand("select @@identity",con);
            int allocationid = Convert.ToInt32(com_allocationid.ExecuteScalar());
            model.RoomAlocationID = allocationid;
            con.Close();
            return true;
            
        }

        public bool VacateInmate(int allocid)
        {
            SqlCommand com_delete = new SqlCommand("delete roomallocationdetails where roomallocationid=@id",con);
            com_delete.Parameters.AddWithValue("@id",allocid);
            con.Open();
            int count=com_delete.ExecuteNonQuery();
            if (count > 0)
            {
                con.Close();
                return true;
            }
            else
            {
                return false;
            }
        }
   

    }
}