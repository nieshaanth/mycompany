﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication_HostelManagementProject.Models
{
    public class FacilityModel
    {
        
        public int FacilityID { get; set; }
        public string FacilityType { get; set; }
        public int Amount { get; set; }

    }
}