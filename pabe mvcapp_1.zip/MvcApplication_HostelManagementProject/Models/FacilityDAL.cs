﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

namespace MvcApplication_HostelManagementProject.Models
{
    public class FacilityDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public List<FacilityModel> GetFacility()
        {
            List<FacilityModel> list_facility = new List<FacilityModel>();
            SqlCommand com_facility = new SqlCommand("select * from Facility", con);
            con.Open();
            SqlDataReader dr = com_facility.ExecuteReader();
            while (dr.Read())
            {
                FacilityModel facility = new FacilityModel();
                facility.FacilityID = dr.GetInt32(0);
                facility.FacilityType = dr.GetString(1);
                facility.Amount = dr.GetInt32(2);
                list_facility.Add(facility);

            }
            con.Close();
            return list_facility;
        }

        public bool AddFacilityDetails(FacilityDetails model)
        {
            SqlCommand com_check = new SqlCommand("select count(*) from roomallocationdetails where roomallocationid=@id", con);
            com_check.Parameters.AddWithValue("@id", model.AllocationID);
            con.Open();
            int count = Convert.ToInt32(com_check.ExecuteScalar());
            if (count == 0)
            {
                con.Close();
                return false;
            }
            else
            {
                SqlCommand com_insert = new SqlCommand("insert RoomFacility values(@facid,@allid,@status,@amount)", con);
                com_insert.Parameters.AddWithValue("@facid", model.FacilityID);
                com_insert.Parameters.AddWithValue("@allid", model.AllocationID);
                com_insert.Parameters.AddWithValue("@status", "Available");
                com_insert.Parameters.AddWithValue("@amount", model.Amount);
               
                com_insert.ExecuteNonQuery();
                con.Close();
                return true;
            }
        }

       
    }
}