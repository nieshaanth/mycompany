﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication_HostelManagementProject.Models;
using System.Web.Security;

namespace MvcApplication_HostelManagementProject.Controllers
{
    public class HomeController : Controller
    {
        [Authorize]      
        public ActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public ActionResult CreateEmployee()
        {
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult CreateEmployee(EmployeesModel model, HttpPostedFileBase fileupdate)
        {
            EmployeesDAL dal = new EmployeesDAL();
            bool status=dal.AddEmployee(model);
            fileupdate.SaveAs(Server.MapPath(model.EmployeeImageAdddress));
            if(status)
            {
                ViewBag.msg = "Employee Created Successfully";
                ViewBag.empid = model.EmployeeID;
                ModelState.Clear();
                return View();
            }
            else
            {
                ViewBag.msg = "Employee Not Created";
                return View();
            }
        }
        [AllowAnonymous]
        public ActionResult EmployeeLogin()
        {
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult EmployeeLogin(int userid,string password,bool rememberme)
        {
            if (Membership.ValidateUser(userid.ToString(), password))
            {
                FormsAuthentication.SetAuthCookie(userid.ToString(), rememberme);
                ViewBag.empid = userid;
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.msg = "Invalid username or password";

                return View();
            }
        }
     
        [Authorize]
        public ActionResult CreateInmate()
        {
            return View();
        }
        [HttpPost]
        [Authorize]
        public ActionResult CreateInmate(InmateModel model, HttpPostedFileBase fileupdate)
        {
            try
            {
                InmateDAL dal1 = new InmateDAL();
                bool status = dal1.AddInmate(model);

                fileupdate.SaveAs(Server.MapPath(model.ImageAddress));

                if (status)
                {
                    ViewBag.msg = "Inmate Created Successfully";
                    ViewBag.inid = model.InmateID;
                    ModelState.Clear();
                    return View();
                }
                else
                {
                    ViewBag.msg = "Inmate Not Created";
                    return View();
                }
            }
            catch(Exception exp)
            {
                ViewBag.errormsg = "Enter Valid Credentials";
                ModelState.Clear();
                return View();
            }
        }
        [Authorize]
        public ActionResult ShowInmate()
        {
            InmateDAL dal = new InmateDAL();
            List<InmateModel> list= dal.GetInmates();
            return View(list);
        }

        [Authorize]
        public ActionResult RoomAllocation()
        {
            RoomDAL dal = new RoomDAL();
            List<RoomModel> list = dal.ShowRoom();
            return View(list);
        }

        [Authorize]
        public ActionResult BookRoom(int id,int price)
        {
            ViewBag.id = id;
            ViewBag.price = price;
            return View();
            
        }
        [Authorize]
        [HttpPost]
        public ActionResult BookRoom(int id, RoomAllocationModel model)
        {
            model.RoomNo = id;
            
            RoomAllocationDAL dal = new RoomAllocationDAL();
            bool status = dal.AllocateRoom(model);
            if (status)
            {
                ViewBag.msg = "Room Allocated";
                ViewBag.allocid = model.RoomAlocationID;
                ModelState.Clear();
                return View();
            }
            else
            {
                ViewBag.msg = "Room Not Allocated";
                return View();
            }

        }
        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("EmployeeLogin", "Home");
        }

        public ActionResult checkID(int inmateid)
        {
            InmateDAL dal=new InmateDAL();
            if (dal.CheckInmateID(inmateid))
            {
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }  
        
        [Authorize]
        public ActionResult AllocateFacility()
        {
           
            FacilityDAL dal = new FacilityDAL();
            List<FacilityModel> list = dal.GetFacility();
            return View(list);
        }

        public ActionResult FacilityDetails(int id, int amount)
        {
            ViewBag.id = id;
            ViewBag.amount = amount;
            return View();
        }
        
        [Authorize]
        [HttpPost]
        public ActionResult FacilityDetails(int id,int amount,FacilityDetails details)
        {
            details.FacilityID = id;
            details.Amount = amount;
            FacilityDAL dal = new FacilityDAL();
            bool status = dal.AddFacilityDetails(details);
            if (status)
            {
                ModelState.Clear();
                ViewBag.xyz = true;
                return View();
            }
            else
            {
                ViewBag.xyz = false;
                return View();
            }
        }

        [Authorize]
        public ActionResult ShowDetails(int inmateid)
        {
            InmateDAL dal = new InmateDAL();
            InmateJoinModel model = dal.ShowInmate(inmateid);
            return View(model);
        }

        [Authorize]
        public ActionResult GenerateBill()
        {
            List<SelectListItem> months = new List<SelectListItem>();
            months.Add(new SelectListItem { Text = "January", Value = "1" });
            months.Add(new SelectListItem { Text = "Febraury", Value = "2" });
            months.Add(new SelectListItem { Text = "March", Value = "3" });
            months.Add(new SelectListItem { Text = "April", Value = "4" });
            months.Add(new SelectListItem { Text = "May", Value = "5" });
            months.Add(new SelectListItem { Text = "June", Value = "6" });
            months.Add(new SelectListItem { Text = "July", Value = "7" });
            months.Add(new SelectListItem { Text = "August", Value = "8" });
            months.Add(new SelectListItem { Text = "September", Value = "9" });
            months.Add(new SelectListItem { Text = "October", Value = "10" });
            months.Add(new SelectListItem { Text = "November", Value = "11" });
            months.Add(new SelectListItem { Text = "December", Value = "12" });
          

            ViewBag.months = months;


            List<SelectListItem> years = new List<SelectListItem>();
            years.Add(new SelectListItem { Text = "2017", Value = "2017" });
            years.Add(new SelectListItem { Text = "2018", Value = "2018" });
            years.Add(new SelectListItem { Text = "2019", Value = "2019" });
            years.Add(new SelectListItem { Text = "2020", Value = "2020" });
            years.Add(new SelectListItem { Text = "2021", Value = "2021" });

            ViewBag.years = years;

            return View();
        }

        [Authorize]
        [HttpPost]
        public ActionResult GenerateBill(BillsModel model)
        {

            List<SelectListItem> months = new List<SelectListItem>();
            months.Add(new SelectListItem { Text = "January", Value = "1" });
            months.Add(new SelectListItem { Text = "Febraury", Value = "2" });
            months.Add(new SelectListItem { Text = "March", Value = "3" });
            months.Add(new SelectListItem { Text = "April", Value = "4" });
            months.Add(new SelectListItem { Text = "May", Value = "5" });
            months.Add(new SelectListItem { Text = "June", Value = "6" });
            months.Add(new SelectListItem { Text = "July", Value = "7" });
            months.Add(new SelectListItem { Text = "August", Value = "8" });
            months.Add(new SelectListItem { Text = "September", Value = "9" });
            months.Add(new SelectListItem { Text = "October", Value = "10" });
            months.Add(new SelectListItem { Text = "November", Value = "11" });
            months.Add(new SelectListItem { Text = "December", Value = "12" });


            ViewBag.months = months;


            List<SelectListItem> years = new List<SelectListItem>();
            years.Add(new SelectListItem { Text = "2017", Value = "2017" });
            years.Add(new SelectListItem { Text = "2018", Value = "2018" });
            years.Add(new SelectListItem { Text = "2019", Value = "2019" });
            years.Add(new SelectListItem { Text = "2020", Value = "2020" });
            years.Add(new SelectListItem { Text = "2021", Value = "2021" });

            ViewBag.years = years;

                BillsDAL dal = new BillsDAL();
                bool status = dal.GenerateBill(model);
                if (status)
                {
                    ViewBag.msg = "Bill Generated Successfully";
                }
                else
                {
                    ViewBag.msg = "Bill Generation Failed";
                }
                ModelState.Clear();
            
            return View(); 
        }

        [Authorize]
        public ActionResult VacateInmate()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        public ActionResult VacateInmate(RoomAllocationModel model)
        {
            RoomAllocationDAL dal = new RoomAllocationDAL();
            bool status=dal.VacateInmate(model.RoomAlocationID);
            if(status)
            {
                ViewBag.msg = "Successful";
            }
            else
            {
                ViewBag.msg = "Not Successful!! Enter Valid ID";
            }
            ModelState.Clear();
            return View();
        }

        [Authorize]
       public ActionResult BillSelect()
        {
            return View();
        }
        
        [Authorize]
        public ActionResult BillGenInmate()
        {

            List<SelectListItem> months = new List<SelectListItem>();
            months.Add(new SelectListItem { Text = "January", Value = "1" });
            months.Add(new SelectListItem { Text = "Febraury", Value = "2" });
            months.Add(new SelectListItem { Text = "March", Value = "3" });
            months.Add(new SelectListItem { Text = "April", Value = "4" });
            months.Add(new SelectListItem { Text = "May", Value = "5" });
            months.Add(new SelectListItem { Text = "June", Value = "6" });
            months.Add(new SelectListItem { Text = "July", Value = "7" });
            months.Add(new SelectListItem { Text = "August", Value = "8" });
            months.Add(new SelectListItem { Text = "September", Value = "9" });
            months.Add(new SelectListItem { Text = "October", Value = "10" });
            months.Add(new SelectListItem { Text = "November", Value = "11" });
            months.Add(new SelectListItem { Text = "December", Value = "12" });


            ViewBag.months = months;


            List<SelectListItem> years = new List<SelectListItem>();
            years.Add(new SelectListItem { Text = "2017", Value = "2017" });
            years.Add(new SelectListItem { Text = "2018", Value = "2018" });
            years.Add(new SelectListItem { Text = "2019", Value = "2019" });
            years.Add(new SelectListItem { Text = "2020", Value = "2020" });
            years.Add(new SelectListItem { Text = "2021", Value = "2021" });

            ViewBag.years = years;


            return View();
        }

        [Authorize]
        [HttpPost]
        public ActionResult BillGenInmate(BillsModel model)
        {
            List<SelectListItem> months = new List<SelectListItem>();
            months.Add(new SelectListItem { Text = "January", Value = "1" });
            months.Add(new SelectListItem { Text = "Febraury", Value = "2" });
            months.Add(new SelectListItem { Text = "March", Value = "3" });
            months.Add(new SelectListItem { Text = "April", Value = "4" });
            months.Add(new SelectListItem { Text = "May", Value = "5" });
            months.Add(new SelectListItem { Text = "June", Value = "6" });
            months.Add(new SelectListItem { Text = "July", Value = "7" });
            months.Add(new SelectListItem { Text = "August", Value = "8" });
            months.Add(new SelectListItem { Text = "September", Value = "9" });
            months.Add(new SelectListItem { Text = "October", Value = "10" });
            months.Add(new SelectListItem { Text = "November", Value = "11" });
            months.Add(new SelectListItem { Text = "December", Value = "12" });


            ViewBag.months = months;


            List<SelectListItem> years = new List<SelectListItem>();
            years.Add(new SelectListItem { Text = "2017", Value = "2017" });
            years.Add(new SelectListItem { Text = "2018", Value = "2018" });
            years.Add(new SelectListItem { Text = "2019", Value = "2019" });
            years.Add(new SelectListItem { Text = "2020", Value = "2020" });
            years.Add(new SelectListItem { Text = "2021", Value = "2021" });

            ViewBag.years = years;


            BillsDAL dal = new BillsDAL();
            bool status = dal.GenerateBillForInmate(model);
            if (status)
            {
                ViewBag.msg = "Bill Generated Successfully";
            }
            else
            {
                ViewBag.msg = "Bill Generation Failed";
            }
            ModelState.Clear();

            return View(); 

            
        }

        [Authorize]

        public ActionResult ShowBillDetails()
        {
            BillsDAL dal = new BillsDAL();
            List<BillsModel> list = dal.GetBill();
            return View(list);
        }
    }
}

