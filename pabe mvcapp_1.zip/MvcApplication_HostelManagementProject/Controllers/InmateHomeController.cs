﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication_HostelManagementProject.Models;
using System.Web.Security;

namespace MvcApplication_HostelManagementProject.Controllers
{
    public class InmateHomeController : Controller
    {

        public ActionResult IndexInmate()
        {
            return View();
        }
        [AllowAnonymous]
        public ActionResult InmateLogin()
        {

            return View();
        }
        [HttpPost]
        public ActionResult InmateLogin(int inid, string pass, bool remember)
        {
            if (Membership.ValidateUser(inid.ToString(), pass))
            {
                FormsAuthentication.SetAuthCookie(inid.ToString(), remember);
                ViewBag.inmateid = inid;
                return RedirectToAction("IndexInmate", "InmateHome");
            }
            else
            {
                ViewBag.msg1 = "Invalid username or password";
                return View();
            }
        }
        

        [Authorize]
        public ActionResult ShowInmate()
        {
            int inmateid = Convert.ToInt32(User.Identity.Name);
            InmateDAL dal = new InmateDAL();
            InmateJoinModel model = dal.ShowInmate(inmateid);
            return View(model);
        }
        [Authorize]
        public ActionResult ShowBill()
        {
            int inmateid = Convert.ToInt32(User.Identity.Name);
            BillsDAL dal = new BillsDAL();
            List<BillsModel> list= dal.ShowBillDetails(inmateid);
            return View(list);
        }
        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("EmployeeLogin", "Home");
        }

        [Authorize]
        public ActionResult BillDetails(int id)
        {
            int inmateid = Convert.ToInt32(User.Identity.Name);
            BillsDAL dal = new BillsDAL();
            BillDetailsModel m = dal.GetBillDetails(id, inmateid);
            ViewBag.billno = m.BillNo;
            ViewBag.rent = m.RoomRent;
            ViewBag.charge = m.FacilityCharge;
            return PartialView("BillPartialView");
        }

    }
}
