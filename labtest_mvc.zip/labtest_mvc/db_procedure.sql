select * from customers


create proc proc_cust()