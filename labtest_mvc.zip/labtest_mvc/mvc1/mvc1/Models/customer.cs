﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace mvc1.Models
{
    public class customer
    {
        public int customerid { get; set; }
        
        [Display(Name="CustomerName")]
        
        [Required(ErrorMessage="Enter your name")]
        
        public string customerid { get; set; }

        [Display(Name = "mailid")]
        public string mailid { get; set; }

        public string password { get;set;}
        public string ques { get; set; }
        public string ans { get;set;}

    }
}