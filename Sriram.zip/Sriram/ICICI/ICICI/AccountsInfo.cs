﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ICICI
{
    public class AccountsInfo
    {

        public int CustomerID { get; set; }

        public int AccountID { get; set; }

        public string AccountType { get; set; }

        public int Account { get; set; }

        public DateTime AccountOpenDate { get; set; }

        public string AccountStatus { get; set; }

    }
}