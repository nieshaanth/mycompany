﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ICICI
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IICICIService" in both code and config file together.
    [ServiceContract]
    public interface IICICIService
    {
        [OperationContract] 
        bool AddAccountDetails(int CustomerID,string CustomerPassword,string AccountID);

        [OperationContract]
        int GetBalance(int CustomerID);

        [OperationContract]
        List<Transaction> ViewTransaction(int AccID);

        [OperationContract]
       int GetAccountIDs(int CustomerID);
    }
}
