﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace HDFC
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "HDFCService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select HDFCService.svc or HDFCService.svc.cs at the Solution Explorer and start debugging.
    public class HDFCService : IHDFCService
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool GetAccountDetails(int CustomerID, string CustomerPassword, string AccountID)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            SqlCommand com_add_account = new SqlCommand("Select count(*) from CustomersInfo where CustomerID = @custid and CustomerPassword = @password", con);
            com_add_account.Parameters.AddWithValue("@custid", CustomerID);
            com_add_account.Parameters.AddWithValue("@password", CustomerPassword);
            con.Open();
            int count = Convert.ToInt32(com_add_account.ExecuteScalar());
            SqlCommand com_acc = new SqlCommand("Select count(*) from AccountsInfo where CustomerID = @custid and AccountID = @accid ", con);
            com_acc.Parameters.AddWithValue("@custid", CustomerID);
            com_acc.Parameters.AddWithValue("@accid", AccountID);
            int c = Convert.ToInt32(com_acc.ExecuteScalar());
            if (count > 0 && c > 0)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }


        public int GetBalance(int CustomerID)
        {
            SqlCommand com_view_balance = new SqlCommand("Select * from AccountsInfo where CustomerID = @custid ", con);
            com_view_balance.Parameters.AddWithValue("@custid", CustomerID);

            con.Open();
            com_view_balance.ExecuteNonQuery();

            SqlDataReader dr = com_view_balance.ExecuteReader();
            ShowDetails sd = new ShowDetails();
            if (dr.Read())
            {

                sd.AccountBalance = dr.GetInt32(3);


            }
            con.Close();
            return sd.AccountBalance;
        }

        public List<Transaction> ViewTransaction(int AccID)
        {
            SqlCommand com_gcst = new SqlCommand("Select * from TransactionsInfo where AccountID = @accid", con);
            com_gcst.Parameters.AddWithValue("@accid", AccID);
            List<Transaction> tlist = new List<Transaction>();

            con.Open();



            SqlDataReader dr = com_gcst.ExecuteReader();

            while (dr.Read())
            {
                Transaction c = new Transaction();
                c.TransactionID = dr.GetInt32(0);
                c.AccountID = dr.GetInt32(1);
                c.TransactionType = dr.GetString(2);
                c.Amount = dr.GetInt32(3);
                c.TransactionDate = dr.GetDateTime(4);
                c.BankName = dr.GetString(5);
                tlist.Add(c);

            }
            con.Close();
            return tlist;
        }

        public int GetAccountIDs(int CustomerID)
        {
            
            SqlCommand com_getacccountid = new SqlCommand("select AccountID from AccountsInfo where CustomerID=@custid", con);
            com_getacccountid.Parameters.AddWithValue("@custid", CustomerID);
            con.Open();
            int id = Convert.ToInt32(com_getacccountid.ExecuteScalar());
            List<int> accntids = new List<int>();

            con.Close();
            return id;
        }


        //public int GetAccountIDs(int CustomerID)
        //{

        //    SqlCommand com_getacccountid = new SqlCommand("select AccountID from AccountsInfo where CustomerID=@custid", con);
        //    com_getacccountid.Parameters.AddWithValue("@custid", CustomerID);
        //    con.Open();
        //    int id = Convert.ToInt32(com_getacccountid.ExecuteScalar());
        //    List<int> accntids = new List<int>();

        //    con.Close();
        //    return id;
        //}
    }
}
