﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace MultiBanking.Models
{
    public class AddLinkedAccountModel
    {
        [Required(ErrorMessage="Enter the Customer ID")]
        public int CustomerID { get; set; }

        [Required(ErrorMessage="Enter the Customer Name")]
        public string CustomerName { get; set; }

        [Required(ErrorMessage = "Enter the Account ID")]
        public int AccountID { get; set; }

         [Required(ErrorMessage = "Enter the Bank Name")]
        public string BankName { get; set; }

    
    }
}