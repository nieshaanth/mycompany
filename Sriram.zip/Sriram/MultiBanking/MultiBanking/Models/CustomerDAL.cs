﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;

namespace MultiBanking.Models
{
    public class CustomerDAL
    {
    
            
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public bool AddCustomer(CustomerModel model)
    {

        SqlCommand com_insert_cust = new SqlCommand("insert CustomerProfile values(@CustomerPhoneNumber,@CustomerFirstName,@CustomerLastName,@CustomerGender,@CustomerMaritalStatus,@CustomerDOB,@CustomerIDType,@CustomerIDNumber,@CustomerAddress,@CustomerFatherName,@CustomerMotherName)", con);


        com_insert_cust.Parameters.AddWithValue("@CustomerPhoneNumber", model.CustomerPhoneNumber);
        com_insert_cust.Parameters.AddWithValue("@CustomerFirstName", model.CustomerFirstName);
        com_insert_cust.Parameters.AddWithValue("@CustomerLastName",model.CustomerLastName);
        com_insert_cust.Parameters.AddWithValue("@CustomerGender", model.CustomerGender);
        com_insert_cust.Parameters.AddWithValue("@CustomerMaritalStatus", model.CustomerMaritalStatus);
        com_insert_cust.Parameters.AddWithValue("@CustomerDOB", model.CustomerDOB);
        com_insert_cust.Parameters.AddWithValue("@CustomerIDType", model.CustomerIDType);
        com_insert_cust.Parameters.AddWithValue("@CustomerIDNumber", model.CustomerIDNumber);
        com_insert_cust.Parameters.AddWithValue("@CustomerAddress",model.CustomerAddress);
        com_insert_cust.Parameters.AddWithValue("@CustomerFatherName",model.CustomerFatherName);
        com_insert_cust.Parameters.AddWithValue("@CustomerMotherName", model.CustomerMotherName);

        con.Open();
        
        com_insert_cust.ExecuteNonQuery();


        SqlCommand com_custid = new SqlCommand("Select @@identity", con);
        int customerid = Convert.ToInt32(com_custid.ExecuteScalar());
        model.CustomerID = customerid;
        //model.CustomerImageAddress = "~/ProductImages/" + customerid + ".jpg";
        model.CustomerID = customerid;

        //SqlCommand com_update_image_address = new SqlCommand("update Products set ProductImageAddress = @address where productid = @productid", con);
        //com_update_image_address.Parameters.AddWithValue("@productid", model.CustomerID);
        ////com_update_image_address.Parameters.AddWithValue("@address", model.CustomerImageAddress);
        //com_update_image_address.ExecuteNonQuery();
        con.Close();
        MembershipCreateStatus status;
        Membership.CreateUser(model.CustomerPhoneNumber,
           model.Password,
           model.CustomerEmailID,
           model.SecurityQuestion,
           model.SecurityAnswer, true, out status);

        if (status == MembershipCreateStatus.Success)
        {
            con.Close();
            return true;
        }
        else
        {
            con.Close();
            return false;
        }
        // true; 

        }

    public int GetCustomerID(string mob)
    {
        SqlCommand com_getcustid = new SqlCommand("select CustomerID from CustomerProfile where CustomerPhoneNumber=@mobid",con);
        com_getcustid.Parameters.AddWithValue("@mobid", mob);
        con.Open();
        int custid = Convert.ToInt32(com_getcustid.ExecuteScalar());
        con.Close();
        return custid;
    }
    
    }
}