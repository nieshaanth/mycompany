﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MultiBanking.Models
{
    public class CustomerModel
    {
        public int CustomerID { get; set; }

        [Display(Name="Phone Number:")]
        [Required(ErrorMessage = "Enter the Customer Phone Number")]
        public string CustomerPhoneNumber { get; set; }

        [Display(Name = "First Name:")]
        [Required(ErrorMessage = "Enter the First Name of the Customer")]
        public string CustomerFirstName { get; set; }

        [Display(Name = "Last Name:")]
        [Required(ErrorMessage = "Enter the Last Name of the Customer")]
        public string CustomerLastName { get; set; }

        [Display(Name = "Gender:")]
        [Required(ErrorMessage = "Enter the Gender")]
        public string CustomerGender { get; set; }

        [Display(Name = "Marital Status:")]
        [Required(ErrorMessage = "Enter the Marital status")]
        public string CustomerMaritalStatus { get; set; }

        [Display(Name = "DOB:")]
        [Required(ErrorMessage = "Enter Customer DOB")]
        public Nullable<System.DateTime> CustomerDOB { get; set; }

        [Display(Name = "ID Type:")]
        [Required(ErrorMessage = "Select The Type of ID")]
        public string CustomerIDType { get; set; }

        [Display(Name = "ID Number:")]
        [Required(ErrorMessage = "Enter the Customer ID Number")]
        public string CustomerIDNumber { get; set; }

        [Display(Name = "Address:")]
        [Required(ErrorMessage = "Enter The Address")]
        public string CustomerAddress { get; set; }


        [Display(Name = "Father's Name:")]
        [Required(ErrorMessage = "Enter the Father's Name of the Customer")]
        public string CustomerFatherName { get; set; }

        [Display(Name = "Mother's Name")]
        [Required(ErrorMessage = "Enter the Mother's Name of the Customer")]
        public string CustomerMotherName { get; set; }

        [Display(Name = "Email ID:")]
        [Required(ErrorMessage = "Enter the Mail ID")]
        public string CustomerEmailID { get; set; }

        [Display(Name = "Password:")]
        [Required(ErrorMessage = "Enter the Password")]
        public string Password { get; set; }

        [Display(Name = "Security Question:")]
        [Required(ErrorMessage = "Enter the Security Question")]
        public string SecurityQuestion { get; set; }

        [Display(Name = "Security Answer:")]
        [Required(ErrorMessage = "Enter the Security Answer")]
        public string SecurityAnswer { get; set; }
    
    
    }
}