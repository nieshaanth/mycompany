﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

namespace MultiBanking.Models
{
    public class AddLinkedAccountDal
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        
        public bool AddLinkedAccount(AddLinkedAccountModel obj)
        {
            SqlCommand com_add_acc = new SqlCommand("Insert LinkAccount values(@BankName,@CustomerID,@CustomerName,@AccountID)", con);
            con.Open();
            com_add_acc.Parameters.AddWithValue("@BankName",obj.BankName);
            com_add_acc.Parameters.AddWithValue("@CustomerID",obj.CustomerID);
            com_add_acc.Parameters.AddWithValue("@CustomerName",obj.CustomerName);
            com_add_acc.Parameters.AddWithValue("@AccountID",obj.AccountID);

            com_add_acc.ExecuteNonQuery();

            con.Close();
            return true;

        }

        public List<AddLinkedAccountModel> GetAccoutDetails(AddLinkedAccountModel obj,int custid)
        {
            SqlCommand com_account = new SqlCommand("Select * from LinkAccount where CustomerID = @custid", con);
            com_account.Parameters.AddWithValue("@custid", custid);
            List<AddLinkedAccountModel> list_account = new List<AddLinkedAccountModel>();
            con.Open();
            SqlDataReader dr = com_account.ExecuteReader();
            while (dr.Read())
            {
               
                AddLinkedAccountModel p = new AddLinkedAccountModel();
                p.BankName = dr.GetString(0);
                p.CustomerID = dr.GetInt32(1);
                p.CustomerName = dr.GetString(2);
                p.AccountID = dr.GetInt32(3);
                list_account.Add(p);

            }
            con.Close();
            return list_account;
        }
       
   }

}
