﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MultiBanking.Models;
using System.Web.Security;

namespace MultiBanking.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Login(string CustomerPhoneNumber, string Password, bool RememberMe)
        {
            if (Membership.ValidateUser(CustomerPhoneNumber.ToString(),Password))
            {
                CustomerDAL dal = new CustomerDAL();
                ViewBag.customerid = CustomerPhoneNumber;
                FormsAuthentication.SetAuthCookie(CustomerPhoneNumber.ToString(), RememberMe);
                return RedirectToAction("HomePage", "Home");

            }
            else
            {
                ViewBag.msg = "Invalid UserID or Password";
                return View();
            }
        }

        public ActionResult NewCustomer()
        {
            return View();
        }

       
        
        [HttpPost]

        public ActionResult NewCustomer(CustomerModel c)
        {
            CustomerDAL dal = new CustomerDAL();
           bool flag =dal.AddCustomer(c);
           if (flag == true)
           {
               ViewBag.add_customer_status = "Customer Added";
               return View();
           }
           else
           {
               ViewBag.add_customer_status = "Customer Not Added";
               return View();
           }
         


        }



        public ActionResult HomePage()
        {
            return View();
        }

       

        
        public ActionResult AddLinkedAccount()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddLinkedAccount(AddLinkedAccountModel model)
        {
            AddLinkedAccountDal dal = new AddLinkedAccountDal();
            bool flag= dal.AddLinkedAccount(model);
            if (flag)
            {
                ViewBag.msg = "Account Linked";
                return View("AddLinkedAccount");
            }
            else
            {
                ViewBag.msg = "Account not linked";
                return View();

            }
        }

        

        public ActionResult ShowLinkedAccount(AddLinkedAccountModel show)
        {
          CustomerDAL dal = new CustomerDAL();
          int custid = dal.GetCustomerID(User.Identity.Name);

          AddLinkedAccountDal accdal = new AddLinkedAccountDal();
          List<AddLinkedAccountModel> list=  accdal.GetAccoutDetails(show,custid);
            return View(list);
        }

        public ActionResult Details(int id)
        {
            ServiceReference1.ICICIServiceClient proxy = new ServiceReference1.ICICIServiceClient("WSHttpBinding_IICICIService");
         
             int Balance = proxy.GetBalance(id);
            ViewBag.message = Balance;

            ServiceReference2.HDFCServiceClient proxy2 = new ServiceReference2.HDFCServiceClient("WSHttpBinding_IHDFCService");
            int Bal = proxy2.GetBalance(id);
            ViewBag.message = Bal;

            return View("Balance");
        }
        
       
      
        public ActionResult ViewTransaction()
        {
            CustomerDAL dal = new CustomerDAL();
            int custid = dal.GetCustomerID(User.Identity.Name);
                       
        
            ServiceReference1.ICICIServiceClient proxy = new ServiceReference1.ICICIServiceClient("WSHttpBinding_IICICIService");
            int accountid = proxy.GetAccountIDs(custid);
            List<ServiceReference1.Transaction> translist = proxy.ViewTransaction(accountid).ToList();


            ServiceReference2.HDFCServiceClient proxy2 = new ServiceReference2.HDFCServiceClient("WSHttpBinding_IHDFCService");
             accountid = proxy2.GetAccountIDs(custid);
            List<ServiceReference2.Transaction> translist2 = proxy2.ViewTransaction(accountid).ToList();
            

            List<TransactionModel> list_trans = new List<TransactionModel>();
            foreach (ServiceReference1.Transaction t in translist)
            {

                TransactionModel o = new TransactionModel();
                o.TransactionID = t.TransactionID;
                o.AccountID = t.AccountID;
                o.TransactionType = t.TransactionType;
                o.Amount = t.Amount;
                o.TransactionDate = t.TransactionDate;
                o.BankName = t.BankName;
                list_trans.Add(o);
            
            }

            foreach (ServiceReference2.Transaction t in translist2)
            {

                TransactionModel o = new TransactionModel();
                o.TransactionID = t.TransactionID;
                o.AccountID = t.AccountID;
                o.TransactionType = t.TransactionType;
                o.Amount = t.Amount;
                o.TransactionDate = t.TransactionDate;
                o.BankName = t.BankName;
                list_trans.Add(o);
            

            }



            return View("ViewTransaction", list_trans);

        }

        public ActionResult Logout()
        {
          FormsAuthentication.SignOut();
          return RedirectToAction("Login","Home");
        }

    }
}
