﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc_shopping_mainproject.Models
{
    public class statusModel
    {
        

           public int orderid { get; set; }
            public string orderstatus { get; set; }

           
        
    }
}