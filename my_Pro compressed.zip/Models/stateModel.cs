﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;


namespace mvc_shopping_mainproject.Models
{
    public class stateModel
    {
       

        public int stateid { get;set;}
        public string statename { get; set; }



    }
}