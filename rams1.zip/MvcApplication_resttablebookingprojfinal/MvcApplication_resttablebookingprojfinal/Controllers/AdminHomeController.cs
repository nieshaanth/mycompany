﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication_resttablebookingprojfinal.Models;
using System.Web.Security;

namespace MvcApplication_resttablebookingprojfinal.Controllers
{
    public class AdminHomeController : Controller
    {
        //
        // GET: /AdminHome/
        
        public ActionResult AdminIndex()
        {
            return View();
        }

        public ActionResult AdminLogin()
        {
            return View();
        }

        public ActionResult AdminHomePage()
        {
            return View();
        }
       
        [HttpPost]
        public ActionResult AdminLogin(string EmployeeEmail, string EmployeePassword, bool rememberme)
        {
            if (Membership.ValidateUser(EmployeeEmail,EmployeePassword))
            {
                FormsAuthentication.SetAuthCookie(EmployeeEmail, rememberme);
                return RedirectToAction("AdminIndex", "AdminHome");
            }
            else
            {
                ViewBag.msg = "Invalid Userid or Password";
                return View();
            }
        }

        public ActionResult NewEmployee()
        {
            return View();
        }
        [HttpPost]
        public ActionResult NewEmployee(AdminLoginModel model)
        {
            EmployeeDAL dal = new EmployeeDAL();

            dal.AddEmployee(model);
            ViewBag.msg = "Employee added";
            return View();

           
        }


        [Authorize]
        public ActionResult Tabledetails()
        {
            return View();
        }
        [Authorize]
    [HttpPost]
        public ActionResult Tabledetails(tabledetails tab)
        {
            TableDAL dal = new TableDAL();
            dal.AddTable(tab);
            ViewBag.msg = "Table Added Successfully";
            return View();
        }

       

        [Authorize]
        public ActionResult FeedbackDetails()
    {
        FeedbackDAL dal = new FeedbackDAL();
        List<FeedbackModel> list = dal.GetFeedback();
        return View(list);
       
    }


        [Authorize]
        public ActionResult AddRestaurant()
        {
           CustomerDAL dal=new CustomerDAL();
            List<SelectListItem> list_city = new List<SelectListItem>();
            List<CityModel> city = dal.GetCities();
            foreach (CityModel item in city)
            {
                list_city.Add(new SelectListItem { Text = item.CityName, Value = item.CityID.ToString() });
            }
            ViewBag.cities = list_city;

            return View();
        }
        [HttpPost]
        public ActionResult AddRestaurant(RestaurantModel model,HttpPostedFileBase img) 
        {
            CustomerDAL dal = new CustomerDAL();
            List<SelectListItem> list_city = new List<SelectListItem>();
            List<CityModel> city = dal.GetCities();
            foreach (CityModel item in city)
            {
                list_city.Add(new SelectListItem { Text = item.CityName, Value = item.CityID.ToString() });
            }
            ViewBag.cities = list_city;
            RestaurantDAL dall = new RestaurantDAL();
        
            dall.AddRestaurant(model);
            img.SaveAs(Server.MapPath(model.RestaurantImage));
            ViewBag.msg = "Restaurant Added Successfully";
            ModelState.Clear();
            return View();
        }



        public ActionResult ViewRestaurants()
        {
            RestaurantDAL dal = new RestaurantDAL();
            List<RestaurantModel> list = dal.ViewRestaurantsAt();
            
            return View(list);
        }


        public ActionResult ViewUserReservations()
        {
            
            ReservationDAL dal = new ReservationDAL();
            List<ReservationModel> list = dal.GetUserReservations();
            return View(list);
        }


        [Authorize]
        public ActionResult AdminLogout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("AdminLogin", "AdminHome");
        }
    }
}
