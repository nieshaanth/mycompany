﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication_resttablebookingprojfinal.Models;
using System.Web.Security;


namespace MvcApplication_resttablebookingprojfinal.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Home");
        }

        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(string CustomerEmail, string CustomerPassword, bool rememberme)
        {
            if (Membership.ValidateUser(CustomerEmail, CustomerPassword))
            {
                FormsAuthentication.SetAuthCookie(CustomerEmail, rememberme);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.msg = "Invalid Userid or Password";
                return View();
            }
        }


        [Authorize]
        public ActionResult MyProfile()
        {
            string CustomerEmail = User.Identity.Name;
            CustomerDAL dal = new CustomerDAL();
            List<CustomerModel> list = dal.GetCustomer(CustomerEmail);
            return View(list);
        }


        public ActionResult NewUserSignupPage()
        {
            return View();
        }
        [HttpPost]
        public ActionResult NewUserSignupPage(CustomerModel cus)
        {
            CustomerDAL dal = new CustomerDAL();

            dal.AddCustomer(cus);
            ViewBag.msg = "User Created";


            return View();
        }


        [Authorize]
        public ActionResult Gallery()
        {
            return View();
        }


        [Authorize]
        public ActionResult ReserveTable(int TableID, string Seat, string CustomerEmail)
        {
            List<SelectListItem> SeatingArea = new List<SelectListItem>();
            SeatingArea.Add(new SelectListItem { Text = "AC", Value = "1" });
            SeatingArea.Add(new SelectListItem { Text = "NON-AC", Value = "2" });
            ViewBag.SeatingArea = SeatingArea;

            List<SelectListItem> time = new List<SelectListItem>();
            time.Add(new SelectListItem { Text = "09.00am", Value = "09.00am" });
            time.Add(new SelectListItem { Text = "09.30am", Value = "09.30am" });
            time.Add(new SelectListItem { Text = "10.00am", Value = "10.00am" });
            time.Add(new SelectListItem { Text = "10.30am", Value = "10.30am" });
            time.Add(new SelectListItem { Text = "11.00am", Value = "11.00am" });
            time.Add(new SelectListItem { Text = "11.30am", Value = "11.30am" });
            time.Add(new SelectListItem { Text = "12.00pm", Value = "12.00pm" });
            time.Add(new SelectListItem { Text = "12.30pm", Value = "12.30pm" });
            time.Add(new SelectListItem { Text = "01.00pm", Value = "01.00pm" });
            time.Add(new SelectListItem { Text = "01.30pm", Value = "01.30pm" });
            time.Add(new SelectListItem { Text = "02.00pm", Value = "02.00pm" });
            time.Add(new SelectListItem { Text = "02.30pm", Value = "02.30pm" });
            time.Add(new SelectListItem { Text = "03.00pm", Value = "03.00pm" });
            time.Add(new SelectListItem { Text = "03.30pm", Value = "03.30pm" });
            time.Add(new SelectListItem { Text = "04.00pm", Value = "04.00pm" });
            time.Add(new SelectListItem { Text = "04.30pm", Value = "04.30pm" });
            time.Add(new SelectListItem { Text = "05.00pm", Value = "05.00pm" });
            time.Add(new SelectListItem { Text = "05.30pm", Value = "05.30pm" });
            time.Add(new SelectListItem { Text = "06.00pm", Value = "06.00pm" });
            time.Add(new SelectListItem { Text = "06.30pm", Value = "06.30pm" });
            time.Add(new SelectListItem { Text = "07.00pm", Value = "07.00pm" });
            time.Add(new SelectListItem { Text = "07.30pm", Value = "07.30pm" });
            time.Add(new SelectListItem { Text = "08.00pm", Value = "08.00pm" });
            time.Add(new SelectListItem { Text = "08.30pm", Value = "08.30pm" });
            time.Add(new SelectListItem { Text = "09.00pm", Value = "09.00pm" });
            ViewBag.time = time;


            TempData["CustomerEmail"] = User.Identity.Name;
            TempData["TableID"] = TableID;
            //TempData["SeatingArea"]=Seat;
            return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult ReserveTable(ReservationModel res)
        {
            List<SelectListItem> SeatingArea = new List<SelectListItem>();
            SeatingArea.Add(new SelectListItem { Text = "AC", Value = "1" });
            SeatingArea.Add(new SelectListItem { Text = "NON-AC", Value = "2" });
            ViewBag.SeatingArea = SeatingArea;

            List<SelectListItem> time = new List<SelectListItem>();
            time.Add(new SelectListItem { Text = "09.00am", Value = "09.00am" });
            time.Add(new SelectListItem { Text = "09.30am", Value = "09.30am" });
            time.Add(new SelectListItem { Text = "10.00am", Value = "10.00am" });
            time.Add(new SelectListItem { Text = "10.30am", Value = "10.30am" });
            time.Add(new SelectListItem { Text = "11.00am", Value = "11.00am" });
            time.Add(new SelectListItem { Text = "11.30am", Value = "11.30am" });
            time.Add(new SelectListItem { Text = "12.00pm", Value = "12.00pm" });
            time.Add(new SelectListItem { Text = "12.30pm", Value = "12.30pm" });
            time.Add(new SelectListItem { Text = "01.00pm", Value = "01.00pm" });
            time.Add(new SelectListItem { Text = "01.30pm", Value = "01.30pm" });
            time.Add(new SelectListItem { Text = "02.00pm", Value = "02.00pm" });
            time.Add(new SelectListItem { Text = "02.30pm", Value = "02.30pm" });
            time.Add(new SelectListItem { Text = "03.00pm", Value = "03.00pm" });
            time.Add(new SelectListItem { Text = "03.30pm", Value = "03.30pm" });
            time.Add(new SelectListItem { Text = "04.00pm", Value = "04.00pm" });
            time.Add(new SelectListItem { Text = "04.30pm", Value = "04.30pm" });
            time.Add(new SelectListItem { Text = "05.00pm", Value = "05.00pm" });
            time.Add(new SelectListItem { Text = "05.30pm", Value = "05.30pm" });
            time.Add(new SelectListItem { Text = "06.00pm", Value = "06.00pm" });
            time.Add(new SelectListItem { Text = "06.30pm", Value = "06.30pm" });
            time.Add(new SelectListItem { Text = "07.00pm", Value = "07.00pm" });
            time.Add(new SelectListItem { Text = "07.30pm", Value = "07.30pm" });
            time.Add(new SelectListItem { Text = "08.00pm", Value = "08.00pm" });
            time.Add(new SelectListItem { Text = "08.30pm", Value = "08.30pm" });
            time.Add(new SelectListItem { Text = "09.00pm", Value = "09.00pm" });
            ViewBag.time = time;
            ReservationDAL dal = new ReservationDAL();
            dal.AddReservation(res);
            //string CustomerEmail = User.Identity.Name;
            //res.CustomerEmail = CustomerEmail; 
            // addres dal = new addres();
            //dal.AddReservation(res);
            ViewBag.msg = "Reservation Successful";
            ModelState.Clear();
            return View();
        }


        [Authorize]
        public ActionResult UserFeedback()
        {
            return View();
        }


        [Authorize]
        [HttpPost]
        public ActionResult UserFeedback(FeedbackModel model)
        {
            FeedbackDAL dal = new FeedbackDAL();
            dal.AddFeedback(model);

            ViewBag.msg = "Thanks for your valuable Feedback";
            ModelState.Clear();
            return View();
        }


        [Authorize]
        public ActionResult SearchCity()
        {
            RestaurantDAL dal = new RestaurantDAL();
            CustomerDAL cdal = new CustomerDAL();
            List<SelectListItem> list_city = new List<SelectListItem>();
            List<CityModel> city = cdal.GetCities();
            foreach (CityModel item in city)
            {
                list_city.Add(new SelectListItem { Text = item.CityName, Value = item.CityID.ToString() });
            }
            ViewBag.cities = list_city;
            return View();
        }



        [Authorize]
        [HttpPost]
        public ActionResult SearchCity(RestaurantModel res)
        {
            RestaurantDAL dal = new RestaurantDAL();
            CustomerDAL cdal = new CustomerDAL();
            List<SelectListItem> list_city = new List<SelectListItem>();
            List<CityModel> city = cdal.GetCities();
            foreach (CityModel item in city)
            {
                list_city.Add(new SelectListItem { Text = item.CityName, Value = item.CityID.ToString() });
            }
            ViewBag.cities = list_city;
            RestaurantModel r = new RestaurantModel();
            int cityid = Convert.ToInt32(res.CityID);
            List<RestaurantModel> list = dal.GetRestaurantsByCity(cityid);
            return View("ShowRestaurants", list);
        }


        [Authorize]
        public ActionResult ShowTable()
        {
            TableDAL dal = new TableDAL();
            List<tabledetails> list_tab = dal.GetTable();
            return View(list_tab);
        }


        [Authorize]
        public ActionResult AboutUs()
        {
            return View();
        }


        [Authorize]
        public ActionResult ViewReservations(ReservationModel model)
        {
            ReservationDAL dal = new ReservationDAL();
            string customeremail = User.Identity.Name;
            List<ReservationModel> list = dal.GetReservations(customeremail);
            return View(list);
        }


        [Authorize]
        public ActionResult ModifyReservationhere(int ReservationID)
        {
            string customeremail = User.Identity.Name;
            ReservationDAL dal = new ReservationDAL();
            ReservationModel rs = dal.Getreserve(customeremail, ReservationID);
            return View(rs);
        }
        [Authorize]
        [HttpPost]
        public ActionResult ModifyReservationhere(ReservationModel model)
        {
            string customeremail = User.Identity.Name;
            ReservationDAL dal = new ReservationDAL();
            dal.Editreservation(model, customeremail);
            ViewBag.msg = "Modified Successfully";
            return View("ModifyReservationhere");
        }


        [Authorize]
        public ActionResult RemoveRes(int ReservationID)
        {

            ReservationDAL dal = new ReservationDAL();
            dal.RemoveReservations(ReservationID);
            return View();
        }


    }
}
           
         




      
       

            



