﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class FeedbackDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddFeedback(FeedbackModel model)
        {
            SqlCommand com_addfeedback = new SqlCommand("insert UserFeedback values(@name,@cusemail,@description,getdate())", con);
            com_addfeedback.Parameters.AddWithValue("@name", model.CustomerName);
            com_addfeedback.Parameters.AddWithValue("@cusemail", model.CustomerEmail);
            com_addfeedback.Parameters.AddWithValue("@description", model.FeedbackDescription);
            con.Open();
            com_addfeedback.ExecuteNonQuery();
            SqlCommand com_feedbackid = new SqlCommand("Select @@identity", con);
            int feedbackid = Convert.ToInt32(com_feedbackid.ExecuteScalar());
            model.FeedBackID = feedbackid;
            con.Close();
            return true;
        }
        public List<FeedbackModel> GetFeedback()
        {

            List<FeedbackModel> list_fb = new List<FeedbackModel>();
            SqlCommand com_get_feedback = new SqlCommand("select * from UserFeedback ", con);
            //com_get_feedback.Parameters.AddWithValue("@cusemail",CustomerEmail);
            con.Open();
            SqlDataReader dr = com_get_feedback.ExecuteReader();
            while (dr.Read())
            {
                FeedbackModel feed = new FeedbackModel();
                feed.FeedBackID = dr.GetInt32(0);
                feed.CustomerName = dr.GetString(1);
                feed.CustomerEmail = dr.GetString(2);
                feed.FeedbackDescription = dr.GetString(3);
                feed.FeedBackDate= dr.GetDateTime(4);
                list_fb.Add(feed);

            }
            con.Close();
            return list_fb;
        } 
    }
}