﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc; 
namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class CityModel
    {
        [Display(Name = "CityID")]
        public int CityID { get; set; }

        [Display(Name = "City Name")]
        public string CityName { get; set; }

    }
}