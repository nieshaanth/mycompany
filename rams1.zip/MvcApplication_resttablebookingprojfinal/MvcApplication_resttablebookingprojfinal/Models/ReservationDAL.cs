﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class ReservationDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddReservation(ReservationModel model)
        {
            SqlCommand com_addreserve = new SqlCommand("insert ReserveUsersHere1 values(@cusemail,@tableid,@seatingarea,@noofpersons,@date,@starttime,@endtime)", con);
           
            com_addreserve.Parameters.AddWithValue("@cusemail", model.CustomerEmail);
            com_addreserve.Parameters.AddWithValue("@tableid", model.TableID);
            com_addreserve.Parameters.AddWithValue("@seatingarea", model.SeatingArea);
            com_addreserve.Parameters.AddWithValue("@noofpersons", model.NoofPersons);
            com_addreserve.Parameters.AddWithValue("@date", model.ReservationDate);
            com_addreserve.Parameters.AddWithValue("@starttime", model.ReservationStartTime);
            com_addreserve.Parameters.AddWithValue("@endtime", model.ReservationEndTime);
           
            con.Open();
            com_addreserve.ExecuteNonQuery(); 
            SqlCommand com_resid = new SqlCommand("Select @@identity", con);
            int reservationid = Convert.ToInt32(com_resid.ExecuteScalar());
            model.ReservationID = reservationid;
            con.Close();
            return true;
        }


        public List<ReservationModel> GetReservations(string cusemail)
        {
            con.Open();

            List<ReservationModel> list_reservation = new List<ReservationModel>();
            SqlCommand com_view = new SqlCommand("select * from ReserveUsersHere1 where CustomerEmail=@cusemail ", con);
            com_view.Parameters.AddWithValue("@cusemail", cusemail);
        
            SqlDataReader dr = com_view.ExecuteReader();
            while (dr.Read()) 
            {
                ReservationModel res = new ReservationModel();

                res.ReservationID= dr.GetInt32(0);
                res.CustomerEmail = dr.GetString(1);

                res.TableID = dr.GetInt32(2);
                res.SeatingArea = dr.GetString(3);
                res.NoofPersons = dr.GetInt32(4);
                res.ReservationDate = dr.GetDateTime(5);
                res.ReservationStartTime = dr.GetString(6);
                res.ReservationEndTime = dr.GetString(7);
                list_reservation.Add(res);

            }
            con.Close();
            return list_reservation;
        } 
        public List<ReservationModel> GetUserReservations()
        {
            con.Open();

            List<ReservationModel> list_reservation = new List<ReservationModel>();
            SqlCommand com_view = new SqlCommand("select * from ReserveUsersHere1 ", con);
           
            SqlDataReader dr = com_view.ExecuteReader();
            while (dr.Read())
            {
                ReservationModel res = new ReservationModel();

                res.ReservationID = dr.GetInt32(0);
                res.CustomerEmail = dr.GetString(1);

                res.TableID = dr.GetInt32(2);
                res.SeatingArea = dr.GetString(3);
                res.NoofPersons = dr.GetInt32(4);
                res.ReservationDate = dr.GetDateTime(5);
                res.ReservationStartTime = dr.GetString(6);
                res.ReservationEndTime = dr.GetString(7);
                list_reservation.Add(res);

            }
            con.Close();
            return list_reservation;
        }
        public ReservationModel Getreserve(string cusemail, int ReservationID)
    {
        con.Open();
        SqlCommand com_view = new SqlCommand("select * from ReserveUsersHere1 where  CustomerEmail=@cusemail and ReservationID=@resid", con);
            com_view.Parameters.AddWithValue("@cusemail",cusemail);
            com_view.Parameters.AddWithValue("@resid", ReservationID);
        ReservationModel res = new ReservationModel();
            SqlDataReader dr = com_view.ExecuteReader();
            while (dr.Read())
            {                

                res.ReservationID= dr.GetInt32(0);
                res.CustomerEmail = dr.GetString(1);

                res.TableID = dr.GetInt32(2);
                res.SeatingArea = dr.GetString(3);
                res.NoofPersons = dr.GetInt32(4);
                res.ReservationDate = dr.GetDateTime(5);
                res.ReservationStartTime = dr.GetString(6);
                res.ReservationEndTime = dr.GetString(7);
               

            }
        con.Close();
        return res;


    }


             public bool Editreservation(ReservationModel model, string cusemail)
        {
            SqlCommand com_edit = new SqlCommand("Update ReserveUsersHere1 set TableID=@tableid,SeatingArea=@seatingarea,NoofPersons=@noofpersons,ReservationDate=@date,ReservationStartTime=@starttime,ReservationEndTime=@endtime where CustomerEmail=@cusemail and ReservationID=@resid", con);
            con.Open();
            com_edit.Parameters.AddWithValue("@resid", model.ReservationID);
            com_edit.Parameters.AddWithValue("@cusemail", cusemail);
            com_edit.Parameters.AddWithValue("@tableid", model.TableID);
            com_edit.Parameters.AddWithValue("@seatingarea", model.SeatingArea);
            com_edit.Parameters.AddWithValue("@noofpersons", model.NoofPersons);
            com_edit.Parameters.AddWithValue("@date", model.ReservationDate);
            com_edit.Parameters.AddWithValue("@starttime", model.ReservationStartTime);
            com_edit.Parameters.AddWithValue("@endtime", model.ReservationEndTime);
            com_edit.ExecuteNonQuery();
            con.Close(); 
            return true;
        }



             public bool RemoveReservations( int ReservationID)
        {
            
            con.Open();
            SqlCommand com_remove_tab = new SqlCommand("delete  ReserveUsersHere1 where  ReservationID=@resid ", con);
            //com_remove_tab.Parameters.AddWithValue("@tabid", TableID);
            com_remove_tab.Parameters.AddWithValue("@resid", ReservationID);
                 com_remove_tab.ExecuteNonQuery();
         
            con.Close();
            return true;
            }

    }
    }
