﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class RestaurantDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddRestaurant(RestaurantModel model)
        {
            SqlCommand com_addres = new SqlCommand("insert Restaurants values(null,@name,@type,@cid,@location,@landmark)", con);
            com_addres.Parameters.AddWithValue("@name",model.RestaurantName);
            com_addres.Parameters.AddWithValue("@type", model.RestaurantType);
            com_addres.Parameters.AddWithValue("@cid", model.CityID);
            com_addres.Parameters.AddWithValue("@location", model.RestaurantLocation);
            com_addres.Parameters.AddWithValue("@landmark", model.Landmark);
            con.Open();
            com_addres.ExecuteNonQuery();

            SqlCommand com_res_id = new SqlCommand("Select @@identity", con);
            int restaurantid = Convert.ToInt32(com_res_id.ExecuteScalar());
            model.RestaurantImage = "/RestaurantImages/" + restaurantid + ".jpg";
            model.RestaurantID = restaurantid;

            SqlCommand com_update_imgaddress = new SqlCommand("update Restaurants set RestaurantImage=@imag where RestaurantID=@rid", con);
            com_update_imgaddress.Parameters.AddWithValue("@rid", model.RestaurantID);
            com_update_imgaddress.Parameters.AddWithValue("@imag", model.RestaurantImage);
            com_update_imgaddress.ExecuteNonQuery();
            con.Close();

            return true;

        }


        public List<RestaurantModel> SearchViewRestaurants()
        {
            List<RestaurantModel> RestaurantList = new List<RestaurantModel>();
            SqlCommand com_viewrestaurants = new SqlCommand("select r.restaurantid,r.restaurantimg,r.restaurantname,r.restauranttype,c.cityname,r.restaurantlocation,r.landmark from Restaurants r join cities c on r.cityid=c.cityid where r.cityid=@cid ", con);

            con.Open();
            SqlDataReader dr = com_viewrestaurants.ExecuteReader();

            while (dr.Read())
            {
                RestaurantModel res = new RestaurantModel();
                res.RestaurantID = dr.GetInt32(0);
                res.RestaurantImage = dr.GetString(1);

                res.RestaurantName = dr.GetString(2);
                res.RestaurantType = dr.GetString(3);
                res.CityID = dr.GetString(4);
                res.RestaurantLocation = dr.GetString(5);
                res.Landmark = dr.GetString(6);

                RestaurantList.Add(res);
            }
            con.Close();
            return RestaurantList;
        }


        public List<RestaurantModel> ViewRestaurantsAt()
        {
            List<RestaurantModel> RestaurantList = new List<RestaurantModel>();
            SqlCommand com_viewrestaurants = new SqlCommand("select * from Restaurants", con);

            con.Open();
            SqlDataReader dr = com_viewrestaurants.ExecuteReader();

            while (dr.Read())
            {
                RestaurantModel res = new RestaurantModel();
                res.RestaurantID = dr.GetInt32(0);
               res.RestaurantImage = dr.GetString(1);

                res.RestaurantName = dr.GetString(2);
                res.RestaurantType = dr.GetString(3);
                //res.CityID = dr.GetInt32(4);
                res.RestaurantLocation = dr.GetString(5);
                res.Landmark = dr.GetString(6);

                RestaurantList.Add(res);
            }
            con.Close();
            return RestaurantList;
        }


         public List<RestaurantModel> GetRestaurantsByCity(int cityid)
        {
            con.Open();
          
            List<RestaurantModel> list_cust = new List<RestaurantModel>();
            SqlCommand com_view = new SqlCommand("select r.restaurantid,r.restaurantimage,r.restaurantname,r.restauranttype,c.cityname,r.restaurantlocation,r.landmark from Restaurants r join cities c on r.cityid=c.cityid where r.cityid=@cid ", con);
            com_view.Parameters.AddWithValue("@cid", cityid);
            SqlDataReader dr = com_view.ExecuteReader();
            while (dr.Read())
            {
                RestaurantModel res = new RestaurantModel();
               
                 res.RestaurantID = dr.GetInt32(0);
                res.RestaurantImage = dr.GetString(1);

                res.RestaurantName = dr.GetString(2);
                res.RestaurantType = dr.GetString(3);
                res.CityID = dr.GetString(4);
                res.RestaurantLocation = dr.GetString(5);
                res.Landmark = dr.GetString(6);
                list_cust.Add(res);

            }
            con.Close();
            return list_cust;
        }
    }
}
    
