﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;

namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class CustomerDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddCustomer(CustomerModel model)
        {
            SqlCommand com_addcus = new SqlCommand("insert CustomerDetails values(@name,@email,@city,@address,@contactno)", con);
            con.Open();
            com_addcus.Parameters.AddWithValue("@name", model.CustomerName);
            com_addcus.Parameters.AddWithValue("@email", model.CustomerEmail);
            
            com_addcus.Parameters.AddWithValue("@city", model.CustomerCity);
            
            com_addcus.Parameters.AddWithValue("@address", model.CustomerAddress);
            com_addcus.Parameters.AddWithValue("@contactno", model.CustomerContactNo);
          

            com_addcus.ExecuteNonQuery();
            SqlCommand com_custid = new SqlCommand("Select @@identity", con);
            int customerid = Convert.ToInt32(com_custid.ExecuteScalar());
            model.CustomerID = customerid;
            con.Close();
           
           MembershipCreateStatus status;
            Membership.CreateUser(model.CustomerEmail,model.CustomerPassword, model.CustomerEmail, model.SecurityQuestion,model.SecurityAnswer, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public List<CustomerModel> GetCustomer(string CustomerEmail)
        {
            List<CustomerModel> cuslist = new List<CustomerModel>();
            CustomerModel mod = new CustomerModel();
            SqlCommand com_cust = new SqlCommand("select CustomerID,CustomerName,CustomerEmail,CustomerCity,CustomerAddress ,CustomerContactNo from CustomerDetails where CustomerEmail=@cusemail", con);
            com_cust.Parameters.AddWithValue("@cusemail", CustomerEmail);
            con.Open();
            SqlDataReader dr = com_cust.ExecuteReader();
            while (dr.Read())
            {
                mod.CustomerID = dr.GetInt32(0);
                mod.CustomerName = dr.GetString(1);
                mod.CustomerEmail = dr.GetString(2);
                mod.CustomerCity = dr.GetString(3);
                mod.CustomerAddress = dr.GetString(4);
                mod.CustomerContactNo = dr.GetString(5);
                cuslist.Add(mod);
            }
            con.Close();
            return cuslist;

        }
        public List<CityModel> GetCities()
        {
            List<CityModel> list_cities = new List<CityModel>();
            SqlCommand com_city = new SqlCommand("select * from Cities", con);
            con.Open();
            SqlDataReader dr = com_city.ExecuteReader();
            while (dr.Read())
            {
                CityModel c = new CityModel();
                c.CityID = dr.GetInt32(0);
                c.CityName = dr.GetString(1);
                list_cities.Add(c);

            }
            con.Close();
            return list_cities;
        }



    }
}