﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class CityDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public CityModel SearchCity(int Cityid)
        {
            SqlCommand com_SearchCity = new SqlCommand("select * from Cities where CityID=@Cid", con);
            com_SearchCity.Parameters.AddWithValue("Cid", Cityid);
            CityModel model = new CityModel();
            con.Open();
            SqlDataReader dr = com_SearchCity.ExecuteReader();
            if (dr.Read())
            {
                model.CityID = dr.GetInt32(0);

                model.CityName = dr.GetString(1);
            }
            return model;

        }
    }
}