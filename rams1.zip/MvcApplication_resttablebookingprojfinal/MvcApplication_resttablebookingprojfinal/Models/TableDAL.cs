﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class TableDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddTable(tabledetails model)
        {
            SqlCommand com_addtab = new SqlCommand("insert TableArrangement values(@maxcap,@seatingarea)",con);
            com_addtab.Parameters.AddWithValue("@maxcap",model.MaximumCapacity);
            com_addtab.Parameters.AddWithValue("@seatingarea", model.SeatingArea);
            con.Open();
            com_addtab.ExecuteNonQuery();
            SqlCommand com_tabid = new SqlCommand("Select @@identity", con);
            int tableid = Convert.ToInt32(com_tabid.ExecuteScalar());
            model.TableID = tableid;
            con.Close();
            return true;
        }
        public List<tabledetails> GetTable()
        {

            List<tabledetails> list_tab = new List<tabledetails>();
            SqlCommand com_get_table = new SqlCommand("select * from TableArrangement where MaximumCapacity>0", con);
            //com_get_table.Parameters.AddWithValue("@count", 0);
            con.Open();
            SqlDataReader dr = com_get_table.ExecuteReader();
            while (dr.Read())
            {
                tabledetails tab = new tabledetails();
                tab.TableID = dr.GetInt32(0);
                tab.MaximumCapacity = dr.GetInt32(1);
                tab.SeatingArea = dr.GetString(2);
                list_tab.Add(tab);

            }
            con.Close();
            return list_tab;
        } 
           
    }
}