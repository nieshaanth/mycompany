﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc; 

namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class RestaurantModel
    {
       
            [Display(Name = "Restaurant ID ")]
            public int RestaurantID { get; set; }

        [Required(ErrorMessage="*")]
            [Display(Name = "Restaurant Image")]
            public string RestaurantImage { get; set; }

        [Required(ErrorMessage = "*")]
            [Display(Name = " Restaurant Name ")]
            public string RestaurantName { get; set; }

        [Required(ErrorMessage = "*")]
            [Display(Name = "  Restaurant Type  ")]
            public string RestaurantType { get; set; }

        [Required(ErrorMessage = "*")]
            [Display(Name = "City")]
            public string CityID { get; set; }

        [Required(ErrorMessage = "*")]
            [Display(Name = "Restaurant Location")]
            public string RestaurantLocation { get; set; }

        [Required(ErrorMessage = "*")]
            [Display(Name = "Landmark Nearby")]
            public string Landmark { get; set; }
        
    }
}