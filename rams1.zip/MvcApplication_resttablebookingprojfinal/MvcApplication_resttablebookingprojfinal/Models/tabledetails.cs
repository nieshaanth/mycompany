﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc; 

namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class tabledetails
    {
        public int TableID { get; set; }

        [Display(Name = "Maximum Availability")]
        [Required(ErrorMessage = "Enter Maximum Capacity")]
        public int MaximumCapacity { get; set; }

        [Display(Name = "Seating Area")]    
        [Required(ErrorMessage = "Select Seating Area")]
        public string SeatingArea { get; set; }

    }
}