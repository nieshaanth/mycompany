﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
namespace MvcApplication_resttablebookingprojfinal.Models 
{
    public class addres
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddReservation(ReservationModel model)
        {
            SqlCommand com_addreserve = new SqlCommand("insert ReserveUsersHere values(@cusemail,@tableid,@seatingarea,@noofpersons,@date,@starttime,@endtime)", con);

            com_addreserve.Parameters.AddWithValue("@cusemail", model.CustomerEmail);
            com_addreserve.Parameters.AddWithValue("@tableid", model.TableID);
            com_addreserve.Parameters.AddWithValue("@seatingarea", model.SeatingArea);
            com_addreserve.Parameters.AddWithValue("@noofpersons", model.NoofPersons);
            com_addreserve.Parameters.AddWithValue("@date", model.ReservationDate);
            com_addreserve.Parameters.AddWithValue("@starttime", model.ReservationStartTime);
            com_addreserve.Parameters.AddWithValue("@endtime", model.ReservationEndTime);

            con.Open();
            com_addreserve.ExecuteNonQuery();
            SqlCommand com_resid = new SqlCommand("Select @@identity", con);
            int reservationid = Convert.ToInt32(com_resid.ExecuteScalar());
            model.ReservationID = reservationid;
            con.Close();
            return true;
        }
    }
}