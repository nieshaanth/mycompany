﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc; 

namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class FeedbackModel
    {
        public int FeedBackID { get; set; }

        [Display(Name = "Customer Name")]
        [Required(ErrorMessage = "Enter Customer Name")]
        public string CustomerName { get; set; }

        [Display(Name = "Customer Email")]
        [Required(ErrorMessage = "Enter Customer Email")]
        public string CustomerEmail { get; set; }

        [Display(Name = "Feedback Description")]
        [StringLength(200, MinimumLength = 5, ErrorMessage = "Minimum must be 5 characters")]
        [Required(ErrorMessage = "Enter Feedback Description")]
     
        public string FeedbackDescription { get; set; }

        public DateTime FeedBackDate { get; set; }
    }
}