﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class AdminLoginModel
    {
        
        public int EmployeeID { get; set; }

        [Display(Name = "Employee Name")]
        [Required(ErrorMessage = "Enter Employee Name")]
        [StringLength(30, MinimumLength = 5, ErrorMessage = "Minimum must be 5 characters")]
        public string EmployeeName { get; set; }

        [Display(Name = "Employee Email")]
        [Required(ErrorMessage = "Enter Employee Email")]
        [EmailAddress(ErrorMessage="Invalid Email")]
        public string EmployeeEmail { get; set; }

        [Display(Name = "Security Question")]
        [Required(ErrorMessage = "Enter Security Question")]
        public string SecurityQuestion { get; set; }

        [Display(Name = "Security Answer")]
        [Required(ErrorMessage = "Enter Security Answer")]
        public string SecurityAnswer { get; set; }

        [Display(Name = "User Password")]
        [Required(ErrorMessage = "Enter Password")]
        [DataType(DataType.Password)]
        public string CustomerPassword { get; set; }

    }
}