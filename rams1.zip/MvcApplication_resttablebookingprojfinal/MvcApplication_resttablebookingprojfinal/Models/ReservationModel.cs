﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc; 

namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class ReservationModel
    {
        public int ReservationID { get; set; }

       

        [Display(Name="Customer Email")]
        [Required(ErrorMessage = "Enter Customer Email")]
        public string CustomerEmail { get; set; }

        [Display(Name = "Table ID")]
        [Required(ErrorMessage = "Select Table ID")]
        public int TableID { get; set; }

        [Display(Name="Seating Area")]
        [Required(ErrorMessage = "Select Seating Area")]
        public string SeatingArea { get; set; }

        [Display(Name = "No of Persons")]
        [Range(1, 4, ErrorMessage = "Range must be between 1-4")]
       [Required(ErrorMessage = "Select NoofPersons")]
        public int NoofPersons { get; set; }

        [Display(Name = "Resrvation Date")]
        [Required(ErrorMessage = "Select Reservation Date")]
        public DateTime ReservationDate { get; set; }

        [Display(Name = "Reservation Start Time")]
        [Required(ErrorMessage = "Select Reservation Time")]
        public string ReservationStartTime { get; set; }

        [Display(Name = "Reservation End Time")]
        [Required(ErrorMessage = "Select Reservation Time")]
        public string ReservationEndTime { get; set; }

        
    }
}