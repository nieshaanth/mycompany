﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;

namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class EmployeeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddEmployee(AdminLoginModel model)
        {
            SqlCommand com_addemp = new SqlCommand("insert employee values(@name,@email)", con);
            com_addemp.Parameters.AddWithValue("@name",model.EmployeeName);
            com_addemp.Parameters.AddWithValue("@email", model.EmployeeEmail);
            con.Open();
            com_addemp.ExecuteNonQuery();

            SqlCommand com_empid = new SqlCommand("Select @@identity", con);
            int employeeid = Convert.ToInt32(com_empid.ExecuteScalar());
            model.EmployeeID= employeeid;
            con.Close();

            MembershipCreateStatus status;
            Membership.CreateUser(model.EmployeeEmail, model.CustomerPassword, model.EmployeeEmail, model.SecurityQuestion, model.SecurityAnswer, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}