﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc; 

namespace MvcApplication_resttablebookingprojfinal.Models
{
    public class CustomerModel
    {
        [Display(Name = "Customer ID")]
        public int CustomerID { get; set; }


        [Display(Name = "Customer Name")]
        [Required(ErrorMessage = "Enter Customer Name")]
        [StringLength(50, MinimumLength = 5, ErrorMessage = "Minimum must be 5 characters")]
        public string CustomerName { get; set; }

        [Display(Name = "Customer Email")]

        [Required(ErrorMessage = "Enter Email ID")]
        public string CustomerEmail { get; set; }

        [Display(Name = "Customer City")]
        [StringLength(30, MinimumLength = 5, ErrorMessage = "Minimum must be 5 characters")]
        [Required(ErrorMessage = "Enter Customer City")]
        public string CustomerCity { get; set; }

        [Display(Name = "Customer Address")]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "Minimum must be 5 characters")]
        [Required(ErrorMessage = "Enter Customer Address")]
        public string CustomerAddress { get; set; }

        [Display(Name = "Customer Contact No")]
        [Required(ErrorMessage = "Enter Contact No")]
        public string CustomerContactNo { get; set; }

        [Display(Name = "Security Question")]
        [Required(ErrorMessage = "Enter Security Question")]
        public string SecurityQuestion { get; set; }

        [Display(Name = "Security Answer")]
        [Required(ErrorMessage = "Enter Security Answer")]
        public string SecurityAnswer { get; set; }

        [Display(Name = "User Password")]
        [Required(ErrorMessage = "Enter Password")]
        [DataType(DataType.Password)]
        public string CustomerPassword { get; set; }
    }
}