create database Hostel_DB

use Hostel_DB

create table Room
(
RoomNo int primary key,
NoOfPersons int,
Availability int,
RoomType varchar(50),
RoomDetails varchar(50),
Price int
)


create table Inmate
(
InmateID int identity(100,1) primary key,
InmateName varchar(30),
Address varchar(50),
ContactNo varchar(10),
PanNumber varchar(10) unique,
InmatePhotoAddress varchar(50),

)

create table RoomAllocationDetails
(
RoomAllocationID int identity(2000,1) primary key,
RoomNo int foreign key references Room(RoomNo),
InmateID int foreign key references Inmate(InmateID),
StartDate DateTime,
EndDate DateTime,

)

create table Facility
(
FacilityID int identity(1,1) primary key,
FacilityType varchar(50),
Amount int
)


create table RoomFacility
(
RoomFacilityID int foreign key references Facility(FacilityID),
RoomAllocationID int foreign key references RoomAllocationDetails(RoomAllocationID) on delete cascade,
Status varchar(20) check ( status in ('Available','Not Available') ),
Amount int
)


create table Employees
(
EmployeeID int identity(5000,1) primary key,
EmployeeName varchar(30),
EmployeeSalary int,
EmployeeDesignation varchar(30),
EmployeeAddress varchar(50),
EmployeeImageAddress varchar(50)
)


select * from Room
select * from Facility
select * from RoomFacility
select * from RoomAllocationDetails
select * from Inmate
select * from Bill
select * from BillDetails
select * from Employees




create trigger room_update on RoomAllocationDetails
FOR INSERT as
begin
declare @roomno int
select @roomno=roomno from inserted
update room set Availability=Availability-1 where roomno=@roomno
end


insert Room values(500,4,4,'AC','I Floor')
insert Room values(501,4,4,'AC','I Floor')
insert Room values(502,2,2,'AC','I Floor')
insert Room values(503,4,4,'AC','II Floor')
insert Room values(504,4,4,'AC','II Floor')
insert Room values(505,3,3,'Non AC','II Floor')

select * from Inmate join RoomAllocationDetails on Inmate.InmateID=RoomAllocationDetails.InmateID

select * from room

 insert facility values('laundry',800)
 
 insert facility values('North Indian Veg Food',1000)
 
  insert facility values('North Indian Non-Veg Food',2000)
  
   insert facility values('South Indian Veg Food',1500)
   
  
alter table Inmate add Status varchar(10)
alter table Inmate add MonthlyBill int

select inmate.inmateid,inmate.inmatename,RoomAllocationDetails.RoomNo,inmate.address,inmate.ContactNo,inmate.PanNumber,inmate.InmatePhotoAddress,
		RoomAllocationDetails.RoomAllocationID
		from Inmate join RoomAllocationDetails on Inmate.inmateid=RoomAllocationDetails.inmateid where inmate.inmateid=113



select inmateid, price,FaciltyCharges from roomallocationdetails join Room on 
roomallocationdetails.roomno=Room.roomno 
join (select roomallocationid,sum(amount)as FaciltyCharges from RoomFacility group by roomallocationid) as y
on
roomallocationdetails.roomallocationid=y.roomallocationid
where inmateid=113

select * from Inmate


select  
roomallocationdetails.inmateid, (price+ FaciltyCharges) as FinalAmt,getDate() as Date from roomallocationdetails join Room on 
roomallocationdetails.roomno=Room.roomno 
join (select roomallocationid,sum(amount)as FaciltyCharges from RoomFacility group by roomallocationid) as y
on
roomallocationdetails.roomallocationid=y.roomallocationid



create table Bill
(
BillNo int identity(3000,1) unique not null,
InmateId int,
BillAmount int,
BillMonth int,
BillYear int,
BillGenDate date,
BillStatus varchar(30),
primary key(inmateid,BillMonth,BillYear)
)


create table BillDetails
(
BillNo int foreign key references Bill(BillNo),
InmateId int foreign key references Inmate(inmateId),
RoomRent int,
FacilityCharges int
)

select inmate.inmateid from inmate  join 
Bill on inmate.inmateid=Bill.inmateid 
where BillMonth!=datepart(mm,getdate()) and status='Staying'






select inmateid from inmate where status='Staying' and inmateid not in ( select inmateid from bill where billmonth=2 and billyear=2017)

select price,FaciltyCharges from roomallocationdetails join Room on roomallocationdetails.roomno=Room.roomno join (select roomallocationid,sum(amount)as FaciltyCharges from RoomFacility group by roomallocationid) as y on roomallocationdetails.roomallocationid=y.roomallocationid where inmateid=113

create trigger room_update on RoomAllocationDetails
FOR INSERT as
begin
declare @roomno int
select @roomno=roomno from inserted
update room set Availability=Availability-1 where roomno=@roomno
end


create trigger Del_inmate on RoomAllocationDetails
for delete as
begin
declare @inmateid int
declare @roomno int
select @inmateid=inmateid,@roomno=roomno from deleted
update room set  Availability=Availability+1 where roomno=@roomno
update inmate set status='NotStaying' where inmateid=@inmateid
end


delete RoomAllocationDetails where RoomAllocationid=2010



alter table room add roomimage varchar(50)




update room set roomimage='/Images/room1.jpg' where roomno=501
update room set roomimage='/Images/room4.jpg' where roomno=504
update room set roomimage='/Images/room5.jpg' where roomno=505
update room set roomimage='/Images/room6.jpg' where roomno=500
select * from roomallocationdetails 
select * from inmate

update room set availability=4 where roomno=500
update room set availability=0 where roomno=501
update room set availability=0 where roomno=502
update room set availability=3 where roomno=503
update room set availability=3 where roomno=504
update room set availability=2 where roomno=505

