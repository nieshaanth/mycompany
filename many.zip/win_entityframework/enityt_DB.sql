create database entity
use entity