﻿namespace win_entityframework
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_custid = new System.Windows.Forms.TextBox();
            this.txt_custname = new System.Windows.Forms.TextBox();
            this.txt_custage = new System.Windows.Forms.TextBox();
            this.txt_custcity = new System.Windows.Forms.TextBox();
            this.btn_addcustomer = new System.Windows.Forms.Button();
            this.btn_findcustomer = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.gv_data = new System.Windows.Forms.DataGridView();
            this.btn_showall = new System.Windows.Forms.Button();
            this.txt_search_city = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.gv_data)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Id:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Customer Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Customer Age:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Customer City:";
            // 
            // txt_custid
            // 
            this.txt_custid.Location = new System.Drawing.Point(132, 29);
            this.txt_custid.Name = "txt_custid";
            this.txt_custid.Size = new System.Drawing.Size(100, 20);
            this.txt_custid.TabIndex = 4;
            // 
            // txt_custname
            // 
            this.txt_custname.Location = new System.Drawing.Point(132, 77);
            this.txt_custname.Name = "txt_custname";
            this.txt_custname.Size = new System.Drawing.Size(100, 20);
            this.txt_custname.TabIndex = 5;
            // 
            // txt_custage
            // 
            this.txt_custage.Location = new System.Drawing.Point(132, 116);
            this.txt_custage.Name = "txt_custage";
            this.txt_custage.Size = new System.Drawing.Size(100, 20);
            this.txt_custage.TabIndex = 6;
            // 
            // txt_custcity
            // 
            this.txt_custcity.Location = new System.Drawing.Point(132, 161);
            this.txt_custcity.Name = "txt_custcity";
            this.txt_custcity.Size = new System.Drawing.Size(100, 20);
            this.txt_custcity.TabIndex = 7;
            // 
            // btn_addcustomer
            // 
            this.btn_addcustomer.Location = new System.Drawing.Point(94, 214);
            this.btn_addcustomer.Name = "btn_addcustomer";
            this.btn_addcustomer.Size = new System.Drawing.Size(138, 52);
            this.btn_addcustomer.TabIndex = 8;
            this.btn_addcustomer.Text = "Add customer";
            this.btn_addcustomer.UseVisualStyleBackColor = true;
            this.btn_addcustomer.Click += new System.EventHandler(this.btn_addcustomer_Click);
            // 
            // btn_findcustomer
            // 
            this.btn_findcustomer.Location = new System.Drawing.Point(55, 0);
            this.btn_findcustomer.Name = "btn_findcustomer";
            this.btn_findcustomer.Size = new System.Drawing.Size(75, 23);
            this.btn_findcustomer.TabIndex = 9;
            this.btn_findcustomer.Text = "Find Customer";
            this.btn_findcustomer.UseVisualStyleBackColor = true;
            this.btn_findcustomer.Click += new System.EventHandler(this.btn_findcustomer_Click);
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(497, 77);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(75, 23);
            this.btn_search.TabIndex = 10;
            this.btn_search.Text = "Seacrh Customer";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // gv_data
            // 
            this.gv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_data.Location = new System.Drawing.Point(332, 116);
            this.gv_data.Name = "gv_data";
            this.gv_data.Size = new System.Drawing.Size(240, 150);
            this.gv_data.TabIndex = 11;
            // 
            // btn_showall
            // 
            this.btn_showall.Location = new System.Drawing.Point(349, 65);
            this.btn_showall.Name = "btn_showall";
            this.btn_showall.Size = new System.Drawing.Size(75, 35);
            this.btn_showall.TabIndex = 12;
            this.btn_showall.Text = "Show All Csutomers";
            this.btn_showall.UseVisualStyleBackColor = true;
            this.btn_showall.Click += new System.EventHandler(this.btn_showall_Click);
            // 
            // txt_search_city
            // 
            this.txt_search_city.Location = new System.Drawing.Point(596, 77);
            this.txt_search_city.Name = "txt_search_city";
            this.txt_search_city.Size = new System.Drawing.Size(100, 20);
            this.txt_search_city.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 336);
            this.Controls.Add(this.txt_search_city);
            this.Controls.Add(this.btn_showall);
            this.Controls.Add(this.gv_data);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_findcustomer);
            this.Controls.Add(this.btn_addcustomer);
            this.Controls.Add(this.txt_custcity);
            this.Controls.Add(this.txt_custage);
            this.Controls.Add(this.txt_custname);
            this.Controls.Add(this.txt_custid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.gv_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_custid;
        private System.Windows.Forms.TextBox txt_custname;
        private System.Windows.Forms.TextBox txt_custage;
        private System.Windows.Forms.TextBox txt_custcity;
        private System.Windows.Forms.Button btn_addcustomer;
        private System.Windows.Forms.Button btn_findcustomer;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.DataGridView gv_data;
        private System.Windows.Forms.Button btn_showall;
        private System.Windows.Forms.TextBox txt_search_city;
    }
}

