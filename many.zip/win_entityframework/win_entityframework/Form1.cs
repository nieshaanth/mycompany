﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_entityframework
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       

        entityEntities dc = new entityEntities();//database name this is a context class (dc)
        

        private void btn_addcustomer_Click(object sender, EventArgs e)
        {
            customer c = new customer();
            c.CustomerName = txt_custname.Text;
            c.CustomerAge =Convert.ToInt32( txt_custage.Text);
            c.CustomerCity = txt_custcity.Text;

            dc.customers.Add(c);
            dc.SaveChanges();//Update database
            MessageBox.Show("CustomerId:" + c.CustomerId);


            
        }

        private void btn_findcustomer_Click(object sender, EventArgs e)
        {
            int cusid = Convert.ToInt32(txt_custid.Text);
            var custobj = (from cust in dc.customers
                          where cust.CustomerId == cusid
                          select cust).FirstOrDefault(); //firstordefault will run the query if it has dat it will give it to custobj else it will return null value to custobj
            if (custobj == null)
            {
                MessageBox.Show("Customer Not Found");

            }
            else {
                //update customer
                custobj.CustomerName = "Name Changed";
                dc.SaveChanges();
                MessageBox.Show("Customer name got updated");
                
                
                ////delete query
                //dc.customers.Remove(custobj);
                //dc.SaveChanges();//delete query
                //MessageBox.Show("Customer got deleted");

                //find query
                //txt_custname.Text = custobj.CustomerName;
                //txt_custage.Text = custobj.CustomerAge.ToString();
                //txt_custcity.Text = custobj.CustomerCity;

            }

        }

        private void btn_showall_Click(object sender, EventArgs e)
        {
            //var i = 100;//var is dyanmmic data type given to object depending on the value,i.e now i is int type.var is not a datatype its spl feature of c#
            var q = from cust in dc.customers //cust is local variable
                    select cust; //q gets intrepret from sql dB and return customer list

            //above is linc query


            gv_data.DataSource = q.ToList();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            var q = from cust in dc.customers
                    where cust.CustomerCity == txt_search_city.Text
                    select cust;
            List<customer> list = q.ToList();
            gv_data.DataSource = list;
        }
    }
}
