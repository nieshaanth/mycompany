﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace win_entityframework
{
    class CustomerCityCount
    {
        public string Customercity { get; set; }
        public int CustomerCount { get; set; }
    }
}
