﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_entityframework
{
    public partial class complex_query : Form
    {
        public complex_query()
        {
            InitializeComponent();
        }
        entityEntities dc = new entityEntities();
        private void button1_Click(object sender, EventArgs e)
        {
            var data = dc.customers.SqlQuery("select * from customers where customercity=@p0",textBox1.Text).ToList();    //@p only to be used
            gv_querydata .DataSource= data;
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var count = dc.Database.ExecuteSqlCommand("update customers set customername=@p1 where customerid=@p1", "abc", textBox1.Text);
            MessageBox.Show(count.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var data = dc.Database.SqlQuery<CustomerCityCount>("select Customercity,count(*) as'CustomerCount' from customers group by customercity");
            gv_querydata.DataSource = data.ToList();
        }
    }
}
