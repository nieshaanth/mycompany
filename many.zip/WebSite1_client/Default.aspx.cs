﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Runtime.Serialization.Json;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_create_Click(object sender, EventArgs e)
    {
        WebClient create = new WebClient();
        string address = "http://localhost:61558/WebSite1/Service.svc/myrestservice/addemp/" + txt_name.Text + "/" + txt_age.Text + "/" + txt_sal.Text;
        create.OpenReadCompleted += new OpenReadCompletedEventHandler(create_OpenReadCompleted);
        create.OpenReadAsync(new Uri(address, UriKind.Absolute));

    }

    void create_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
    {
        DataContractJsonSerializer json = new DataContractJsonSerializer(typeof(int));
        int id =Convert.ToInt32( json.ReadObject(e.Result));

        lbl_createstatus.Text="Your are added successfully  adn ur id is"+id;

        //     order obj = json.ReadObject(e.Result) as order;
            //MessageBox.Show(obj.OrderId + "\n" + obj.empname + "\n" + obj.OrderAmount + "\n" + obj.OrderDetails);
        
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        WebClient show = new WebClient();
        string addr="http://localhost:61558/WebSite1/Service.svc/myrestservice/emplist/"+txt_age.Text;
        show.OpenReadCompleted+=new OpenReadCompletedEventHandler(show_OpenReadCompleted);
        show.OpenReadAsync(new Uri(addr,UriKind.Absolute));
    }

    void show_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
    {
        DataContractJsonSerializer json1 = new DataContractJsonSerializer(typeof(List<employee>));
        List<employee> elist = json1.ReadObject(e.Result) as List<employee>;
        GridView1.DataSource = elist;
        GridView1.DataBind();

    }
}