﻿namespace first__web_serviceclient_application
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_getsal = new System.Windows.Forms.Button();
            this.txt_sal = new System.Windows.Forms.TextBox();
            this.txt_days = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_getsal
            // 
            this.btn_getsal.Location = new System.Drawing.Point(43, 167);
            this.btn_getsal.Name = "btn_getsal";
            this.btn_getsal.Size = new System.Drawing.Size(75, 23);
            this.btn_getsal.TabIndex = 0;
            this.btn_getsal.Text = "Get Salary";
            this.btn_getsal.UseVisualStyleBackColor = true;
            this.btn_getsal.Click += new System.EventHandler(this.btn_getsal_Click);
            // 
            // txt_sal
            // 
            this.txt_sal.Location = new System.Drawing.Point(139, 109);
            this.txt_sal.Name = "txt_sal";
            this.txt_sal.Size = new System.Drawing.Size(100, 20);
            this.txt_sal.TabIndex = 1;
            // 
            // txt_days
            // 
            this.txt_days.Location = new System.Drawing.Point(139, 69);
            this.txt_days.Name = "txt_days";
            this.txt_days.Size = new System.Drawing.Size(100, 20);
            this.txt_days.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Per Day Salary";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Location = new System.Drawing.Point(40, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "No of Days";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_days);
            this.Controls.Add(this.txt_sal);
            this.Controls.Add(this.btn_getsal);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_getsal;
        private System.Windows.Forms.TextBox txt_sal;
        private System.Windows.Forms.TextBox txt_days;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

