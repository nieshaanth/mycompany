﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


   
    public employee updateemp(string id, employee emp)
    {
        employeeDAL dal = new employeeDAL();
        dal.updateemp(Convert.ToInt32(id), emp);
        return emp;

   
    }

    public void deleteemp(string id)
    {
        employeeDAL dal = new employeeDAL();
        dal.deleteemp(Convert.ToInt32(id));
        
    }


    public employee GetAPerson(string id)
    {
        employeeDAL dal =new employeeDAL();
        employee emp = dal.GetAPerson(Convert.ToInt32( id));
        return emp;
    
    }



    public int addemp(string name, string age, string salary)
    {
        int sal = Convert.ToInt32(salary);
        int ag = Convert.ToInt32(age);
        SqlCommand com_add = new SqlCommand("insert employee values(@name,@age,@sal)", con);
        com_add.Parameters.AddWithValue("@name", name);
        com_add.Parameters.AddWithValue("@age", ag);
        com_add.Parameters.AddWithValue("@sal", sal);
        con.Open();
        com_add.ExecuteNonQuery();
        SqlCommand com_id = new SqlCommand("select @@identity", con);
        employee emp = new employee();
        emp.empid = Convert.ToInt32(com_id.ExecuteScalar());
        con.Close();
      
        return emp.empid;

    }


    public List<employee> emplist(string empid)
    {
        List<employee> emp_list = new List<employee>();
        SqlCommand com_list = new SqlCommand("select * from employee", con);
        con.Open();
        SqlDataReader dr = com_list.ExecuteReader();
        while (dr.Read())
        {
            employee emp = new employee();
            emp.empid = dr.GetInt32(0);
            emp.empname = dr.GetString(1);
            emp.empage = dr.GetInt32(2);
            emp.empsalary = dr.GetInt32(3);
            emp_list.Add(emp);



        }
        con.Close();
        return emp_list;
    }
}
