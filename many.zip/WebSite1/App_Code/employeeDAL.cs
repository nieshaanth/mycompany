﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
/// <summary>
/// Summary description for employeeDAL
/// </summary>
public class employeeDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cosntr"].ConnectionString);

    public bool addemp(string name,int age,int sal)
    {
        SqlCommand com_add = new SqlCommand("insert employee values(@name,@age,@sal)", con);
        com_add.Parameters.AddWithValue("@name", name);
        com_add.Parameters.AddWithValue("@age", age);
        com_add.Parameters.AddWithValue("@sal", sal);
        con.Open();
        com_add.ExecuteNonQuery();
        SqlCommand com_id = new SqlCommand("select @@identity", con);
        employee emp = new employee();
        emp.empid=Convert.ToInt32( com_id.ExecuteScalar());
        con.Close();
        return true;

    }
    public bool updateemp(int id,employee emp)
    {
        SqlCommand com_update = new SqlCommand("update employee set empname=@name,empage=@age,empsalary=@sal where empid=@id)", con);
        com_update.Parameters.AddWithValue("@name", emp.empname);
        com_update.Parameters.AddWithValue("@age", emp.empage);
        com_update.Parameters.AddWithValue("@sal", emp.empsalary);
        com_update.Parameters.AddWithValue("@id", id);
        con.Open();
        com_update.ExecuteNonQuery();
        con.Close();
        return true;


       

    }

    public employee GetAPerson(int id)
    {
        SqlCommand com_getemp = new SqlCommand("select * from employee where empid=@id ", con);
        com_getemp.Parameters.AddWithValue("@id", id);
        con.Open();
        SqlDataReader dr = com_getemp.ExecuteReader();
        employee emp = new employee();
        emp.empname = dr.GetString(1);
        emp.empage = dr.GetInt32(2);
        emp.empsalary = dr.GetInt32(3);
        return emp;
    
    }

    public bool deleteemp(int id)
    {
        SqlCommand com_del = new SqlCommand("delete employee where empid=@id ", con);
        con.Open();
        com_del.ExecuteNonQuery();
        con.Close();
        return true;





    }
    public List<employee> emplist()
    {
        List<employee> emp_list = new List<employee>();
        SqlCommand com_list = new SqlCommand("select * from employee", con);
        con.Open();
        SqlDataReader dr = com_list.ExecuteReader();
        while (dr.Read())
        {
            employee emp = new employee();
            emp.empid = dr.GetInt32(0);
            emp.empname = dr.GetString(1);
            emp.empage = dr.GetInt32(2);
            emp.empsalary = dr.GetInt32(3);
            emp_list.Add(emp);


        
        }
        con.Close();
        return emp_list;

    
    }
 	
}