﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace products_entity
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        entityEntities dc = new entityEntities();
        private void btn_addproducts_Click(object sender, EventArgs e)
        {
            Product p = new Product();
            p.CategoryName = txt_categoryname.Text;
            p.ProductName = txt_ProductName.Text;
            p.ProductPrice =Convert.ToInt32( txt_ProductPrice.Text);
            p.ProductDescription = txt_ProductDesc.Text;
            dc.Products.Add(p);
            dc.SaveChanges();
            
            MessageBox.Show("Products Added Successfully and product id is"+p.ProductId);
        }

        private void btn_getproducts_Click(object sender, EventArgs e)
        {
            var q = from prod in dc.Products
                    select prod;

            gv_data.DataSource = q.ToList();
        }

        private void btn_findproducts_Click(object sender, EventArgs e)
        {
            string cat_name = txt_categoryname.Text;
            var q = from prod in dc.Products
                    where prod.CategoryName == cat_name
                    select prod;
            if (q.ToList().Count!=0)
            {
                gv_data.DataSource = q;
            }
            else 
            { MessageBox.Show("cateogory name not found"); 
            }
        }

        private void btn_searchproducts_Click(object sender, EventArgs e)
        {
            int pid = Convert.ToInt32(txt_Productid.Text);
            var q = (from prod in dc.Products
                     where prod.ProductId == pid
                     select prod).FirstOrDefault();
            if (q == null)
            {
                MessageBox.Show("Product not found");

            }
            else {
                txt_ProductName.Text = q.ProductName;
                txt_Productid.Text = q.ProductId.ToString();
                txt_ProductPrice.Text = q.ProductPrice.ToString();
                txt_ProductDesc.Text = q.ProductDescription;
                txt_categoryname.Text = q.CategoryName;
            }
        }
    }
}
