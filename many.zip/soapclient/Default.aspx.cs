﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Runtime.Serialization;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_create_Click(object sender, EventArgs e)
    {
        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
        ServiceReference1.employee emp = new ServiceReference1.employee();
        emp.empname = txt_name.Text;
        emp.empsalary = Convert.ToInt32(txt_sal.Text);
        emp.empage = Convert.ToInt32(txt_age.Text);
        emp.empid = proxy.addemp(emp);
        lbl_status.Text = "emp id is" + emp.empid.ToString();
    }
    protected void Btn_show_Click(object sender, EventArgs e)
    {
        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
        gv_show.DataSource = proxy.show();
        gv_show.DataBind();

        dl_show.DataSource = proxy.show();
        dl_show.DataBind();
    }
    protected void gv_show_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void dl_show_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}