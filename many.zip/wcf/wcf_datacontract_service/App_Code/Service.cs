﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public int AddCustomer(Customer obj)
    {
        try
{
        SqlCommand com_addcust = new SqlCommand("insert customers1 values(@name,@city)", con);
        com_addcust.Parameters.AddWithValue("@name", obj.CustomerName);
        com_addcust.Parameters.AddWithValue("@city", obj.CustomerCity);
        con.Open();
        com_addcust.ExecuteNonQuery();
        SqlCommand com_cusid = new SqlCommand("select @@identity", con);
        obj.CustomerId = Convert.ToInt32(com_cusid.ExecuteScalar());

        con.Close();
        return obj.CustomerId;
            }
        catch(Exception exp)
        {
            Errorinfo info = new Errorinfo();
            info.Errorid = 101;
            info.ErrorDatatime = DateTime.Now.ToString();
            info.ErrorDetails = "Database Server Error";
            throw new FaultException<Errorinfo>(info);//typed fault
            //throw new FaultException("Database Error");
        
        }
     }
    public List<Customer> GetCustomers(string CustomerCity)
    {
        System.Threading.Thread.Sleep(15000);
        List<Customer> cust_list = new List<Customer>();
        SqlCommand com_custlist = new SqlCommand("select * from customers where customercity=@city", con);
        com_custlist.Parameters.AddWithValue("@city", CustomerCity);
        con.Open();
        SqlDataReader dr = com_custlist.ExecuteReader();
        
        while (dr.Read())
        {
            Customer obj = new Customer();
            obj.CustomerId = dr.GetInt32(0);
            obj.CustomerName = dr.GetString(1);
            obj.CustomerCity = dr.GetString(2);
            cust_list.Add(obj);
        }
        con.Close();
        return cust_list;
    }
}
