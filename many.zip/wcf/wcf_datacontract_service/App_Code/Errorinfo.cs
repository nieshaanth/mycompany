﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

/// <summary>
/// Summary description for Errorinfo
/// </summary>

[DataContract]
public class Errorinfo
{
	
        [DataMember]
		public int Errorid{get;set;}
     [DataMember]
    public string ErrorDatatime{get;set;}
     [DataMember]
    public string ErrorDetails{get;set;}
	
}