﻿namespace order_client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.txt_amt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.btn_plaecorder = new System.Windows.Forms.Button();
            this.btn_getorders = new System.Windows.Forms.Button();
            this.gv_getorders = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gv_getorders)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "CustomerName";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Amt";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "City";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(109, 6);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 3;
            // 
            // txt_city
            // 
            this.txt_city.Location = new System.Drawing.Point(109, 60);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(100, 20);
            this.txt_city.TabIndex = 4;
            // 
            // txt_amt
            // 
            this.txt_amt.Location = new System.Drawing.Point(109, 34);
            this.txt_amt.Name = "txt_amt";
            this.txt_amt.Size = new System.Drawing.Size(100, 20);
            this.txt_amt.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Cursor = System.Windows.Forms.Cursors.No;
            this.label4.Location = new System.Drawing.Point(12, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 6;
            this.label4.Tag = "OrderId";
            this.label4.Text = "label4";
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Location = new System.Drawing.Point(106, 103);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(35, 13);
            this.lbl_orderid.TabIndex = 7;
            this.lbl_orderid.Text = "label5";
            // 
            // btn_plaecorder
            // 
            this.btn_plaecorder.Location = new System.Drawing.Point(15, 130);
            this.btn_plaecorder.Name = "btn_plaecorder";
            this.btn_plaecorder.Size = new System.Drawing.Size(75, 23);
            this.btn_plaecorder.TabIndex = 8;
            this.btn_plaecorder.Text = "PlaceORder";
            this.btn_plaecorder.UseVisualStyleBackColor = true;
            this.btn_plaecorder.Click += new System.EventHandler(this.btn_plaecorder_Click);
            // 
            // btn_getorders
            // 
            this.btn_getorders.Location = new System.Drawing.Point(15, 168);
            this.btn_getorders.Name = "btn_getorders";
            this.btn_getorders.Size = new System.Drawing.Size(75, 23);
            this.btn_getorders.TabIndex = 9;
            this.btn_getorders.Text = "GetOrder";
            this.btn_getorders.UseVisualStyleBackColor = true;
            this.btn_getorders.Click += new System.EventHandler(this.btn_getorders_Click);
            // 
            // gv_getorders
            // 
            this.gv_getorders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_getorders.Location = new System.Drawing.Point(96, 155);
            this.gv_getorders.Name = "gv_getorders";
            this.gv_getorders.Size = new System.Drawing.Size(240, 150);
            this.gv_getorders.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 425);
            this.Controls.Add(this.gv_getorders);
            this.Controls.Add(this.btn_getorders);
            this.Controls.Add(this.btn_plaecorder);
            this.Controls.Add(this.lbl_orderid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_amt);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.gv_getorders)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.TextBox txt_amt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Button btn_plaecorder;
        private System.Windows.Forms.Button btn_getorders;
        private System.Windows.Forms.DataGridView gv_getorders;
    }
}

