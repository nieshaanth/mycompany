﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace order_client
{
    public partial class Form1 : Form
    {
        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_plaecorder_Click(object sender, EventArgs e)
        {
            try
            {
                ServiceReference1.Order obj = new ServiceReference1.Order();
                obj.customerName = txt_name.Text;
                obj.OrderAmt = Convert.ToInt32(txt_amt.Text);
                obj.OrderCity = (txt_city.Text);


                int oid = proxy.placeorder(obj);
                lbl_orderid.Text = "Order Placed   " + oid;
            }
            catch(FaultException<ServiceReference1.ErrorInfo>exp)

            {
                MessageBox.Show(exp.Detail.errorid + "\n" + exp.Detail.errordate + "\n" + exp.Detail.errordeatils);
            }
        }


        private void btn_getorders_Click(object sender, EventArgs e)
        {
            proxy.getordersCompleted += new EventHandler<ServiceReference1.getordersCompletedEventArgs>(proxy_getordersCompleted);
            proxy.getordersAsync(txt_name.Text);
            
            //List<ServiceReference1.Order> ordlist = proxy.getorders(txt_name.Text).ToList();
            //gv_getorders.DataSource = ordlist;
 
        }

        void proxy_getordersCompleted(object sender, ServiceReference1.getordersCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                gv_getorders.DataSource = e.Result.ToList();
            }
            else {
                MessageBox.Show( e.Error.Message);
            }
        }
    }
}
