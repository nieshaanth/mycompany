﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;

namespace win_datacontract_client
{
    public partial class Form1 : Form
    {
        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_addcustomer_Click(object sender, EventArgs e)
        {
            try
            {
                ServiceReference1.Customer obj = new ServiceReference1.Customer();
                obj.CustomerName = txt_name.Text;
                obj.CustomerCity = txt_city.Text;
                proxy.AddCustomer(obj);
                MessageBox.Show("Customer Added");
                txt_id.Text = obj.CustomerId.ToString();
            }
            catch (FaultException<ServiceReference1.Errorinfo> exp)
            {
                MessageBox.Show(exp.Detail.Errorid+"\n"+exp.Detail.ErrorDatatime+"\n"+exp.Detail.ErrorDetails);


            }
        }

        private void btn_customerlist_Click(object sender, EventArgs e)
        {
            proxy.GetCustomersCompleted += new EventHandler<ServiceReference1.GetCustomersCompletedEventArgs>(proxy_GetCustomersCompleted);
            proxy.GetCustomersAsync(txt_search.Text);

        //List<ServiceReference1.Customer> custlist= proxy.GetCustomers(txt_search.Text).ToList();
        //gv_custlist.DataSource = custlist;
 
            

        }

        void proxy_GetCustomersCompleted(object sender, ServiceReference1.GetCustomersCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                gv_custlist.DataSource = e.Result.ToList();
            }
            else {
                MessageBox.Show(e.Error.Message);
            }
        }

    }
}
