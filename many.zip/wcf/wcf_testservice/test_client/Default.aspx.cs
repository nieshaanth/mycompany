﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        ServiceReference1.mycontractClient client = new ServiceReference1.mycontractClient("WSHttpBinding_mycontract");
        int ret = client.Method1(TextBox1.Text);
        Label1.Text = ret.ToString();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
            ServiceReference1.mycontractClient proxy=new ServiceReference1.mycontractClient("WSHttpBinding_mycontract");
            proxy.Method1Completed+=new EventHandler<ServiceReference1.Method1CompletedEventArgs>(proxy_Method1Completed);
          proxy.Method1Async(TextBox1.Text);    
    
    }

    void  proxy_Method1Completed(object sender, ServiceReference1.Method1CompletedEventArgs e)
    {
        Label1.Text = e.Result.ToString();  // go to default aspx html page and add async=true
    }
}