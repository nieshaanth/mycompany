﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wcf_rest_client
{
   public class order //class should be public for rest service
    {
        public int OrderId { get; set; }
        public string CustomerName { get; set; }
        public int OrderAmount { get; set; }

       public string OrderDetails { get; set; }

    }
}
