﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;



using System.Net;
using System.Runtime.Serialization.Json;//add dll ref


namespace wcf_rest_client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_restservice_Click(object sender, EventArgs e)
        {
            WebClient client_order = new WebClient();
            //string address="http://localhost:53102/wcf_restservice/Service.svc/myrestservice/FindOrder/1000";
            string address = "http://localhost:53102/wcf_restservice/Service.svc/myrestservice/FindOrder/"+txt_oid.Text;
            client_order.OpenReadCompleted += new OpenReadCompletedEventHandler(client_order_OpenReadCompleted);
            client_order.OpenReadAsync(new Uri(address, UriKind.Absolute));
        }

        void client_order_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {

            DataContractJsonSerializer json = new DataContractJsonSerializer(typeof(order));

            order obj = json.ReadObject(e.Result) as order;
            MessageBox.Show(obj.OrderId + "\n" + obj.CustomerName + "\n" + obj.OrderAmount + "\n" + obj.OrderDetails);
        }

       


        private void button1_Click(object sender, EventArgs e)
        {
            WebClient client_getorers = new WebClient();

            string address = "http://localhost:53102/wcf_restservice/Service.svc/myrestservice/GetOrders/" + txt_customername.Text;
            client_getorers.OpenReadCompleted += new OpenReadCompletedEventHandler(client_getorers_OpenReadCompleted);

            client_getorers.OpenReadAsync(new Uri(address, UriKind.Absolute));

        }

        void client_getorers_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            DataContractJsonSerializer json = new DataContractJsonSerializer(typeof(List<order>));
            List<order> ord_list = json.ReadObject(e.Result) as List<order>;
            gv_data.DataSource = ord_list;



        }

        private void gv_data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
