﻿namespace wcf_rest_client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_oid = new System.Windows.Forms.TextBox();
            this.btn_restservice = new System.Windows.Forms.Button();
            this.gv_data = new System.Windows.Forms.DataGridView();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.buton1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gv_data)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_oid
            // 
            this.txt_oid.Location = new System.Drawing.Point(42, 30);
            this.txt_oid.Name = "txt_oid";
            this.txt_oid.Size = new System.Drawing.Size(100, 20);
            this.txt_oid.TabIndex = 0;
            // 
            // btn_restservice
            // 
            this.btn_restservice.Location = new System.Drawing.Point(226, 30);
            this.btn_restservice.Name = "btn_restservice";
            this.btn_restservice.Size = new System.Drawing.Size(120, 47);
            this.btn_restservice.TabIndex = 1;
            this.btn_restservice.Text = "Call Rest Service _find _order";
            this.btn_restservice.UseVisualStyleBackColor = true;
            this.btn_restservice.Click += new System.EventHandler(this.btn_restservice_Click);
            // 
            // gv_data
            // 
            this.gv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_data.Location = new System.Drawing.Point(156, 187);
            this.gv_data.Name = "gv_data";
            this.gv_data.Size = new System.Drawing.Size(294, 195);
            this.gv_data.TabIndex = 2;
            this.gv_data.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_data_CellContentClick);
            // 
            // txt_customername
            // 
            this.txt_customername.Location = new System.Drawing.Point(12, 212);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(100, 20);
            this.txt_customername.TabIndex = 3;
            // 
            // buton1
            // 
            this.buton1.Location = new System.Drawing.Point(12, 255);
            this.buton1.Name = "buton1";
            this.buton1.Size = new System.Drawing.Size(120, 47);
            this.buton1.TabIndex = 4;
            this.buton1.Text = "Call Rest Service_orderlist";
            this.buton1.UseVisualStyleBackColor = true;
            this.buton1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 445);
            this.Controls.Add(this.buton1);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.gv_data);
            this.Controls.Add(this.btn_restservice);
            this.Controls.Add(this.txt_oid);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.gv_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_oid;
        private System.Windows.Forms.Button btn_restservice;
        private System.Windows.Forms.DataGridView gv_data;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.Button buton1;
    }
}

