﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{

    public order FindOrder(string orderid)
    {
        //ado.net

        int oid = Convert.ToInt32(orderid);
        order obj = new order();
        obj.OrderId = 1000;
        obj.CustomerName = "Nishanth";
        obj.OrderAmount = 1000;
        obj.OrderDetails = "Online Order";
        return obj;

       
    }

    public List<order> GetOrders(string customername)
    {
        //ado.net;
        List<order> ordlist = new List<order>();
        ordlist.Add(new order
        {
            OrderId = 1001,
            CustomerName = "Nishanth",
            OrderAmount = 2500,
            OrderDetails = "Obnline order"

        });

        ordlist.Add(new order
        {
            OrderId=1002,
            CustomerName="Ganesh",
            OrderAmount=1200,
            OrderDetails="Online order"
        });

        ordlist.Add(new order
        {
            OrderId=1003,
        CustomerName="Vicky",
        OrderAmount=1500,
        OrderDetails="Online Order"
        });

        return ordlist;

        
    }
}
