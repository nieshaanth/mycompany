﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization; 

[DataContract]
public class order
{
	[DataMember]
    public int OrderId{get;set;}
    [DataMember]
    public string CustomerName{get;set;}
    [DataMember]
    public int OrderAmount{get;set;}

    [DataMember(IsRequired = false)]
    public string OrderDetails { get; set; }


    
   
	
}