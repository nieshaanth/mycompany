﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace wcf_assignment_client
{
    public partial class Form1 : Form
    {
        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
      

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            int num1, num2;
            num1 = Convert.ToInt32(txt_num1.Text);
            num2 = Convert.ToInt32(txt_num2.Text);
            int result = proxy.Getsum(num1, num2);
           
            lbl_result.Text = result.ToString();

        }

        private void btn_diff_Click(object sender, EventArgs e)
        {
            int num1, num2;
            num1 = Convert.ToInt32(txt_num1.Text);
            num2 = Convert.ToInt32(txt_num2.Text);
            int result = proxy.Getsub(num1, num2);
            
            lbl_result.Text = result.ToString();
        }

        private void btn_mul_Click(object sender, EventArgs e)
        {
            int num1, num2;
            num1 = Convert.ToInt32(txt_num1.Text);
            num2 = Convert.ToInt32(txt_num2.Text);
            int result = proxy.Getmul(num1, num2);
         
            lbl_result.Text = result.ToString();
        }

        private void btn_div_Click(object sender, EventArgs e)
        {
            
            int num1, num2;
            num1 = Convert.ToInt32(txt_num1.Text);
            num2 = Convert.ToInt32(txt_num2.Text);
            int result = proxy.Getdiv(num1, num2);
          
            lbl_result.Text = result.ToString();
        

        }


    }
}
