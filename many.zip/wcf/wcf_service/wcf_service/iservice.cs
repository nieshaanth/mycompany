﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace wcf_service
{
    [ServiceContract]
    interface iservice
    {
        [OperationContract]//seperate operation contarct for all functions is to defined
        int GetSalary(int days, int per_day_salary);

       
    }
}
