﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

/// <summary>
/// Summary description for ErrorInfo
/// </summary>
[DataContract]
public class ErrorInfo
{
    [DataMember]
    public int errorid { get; set; }
    [DataMember]
    public string errordate { get; set; }
    [DataMember]
    public string errordeatils { get; set; }
	
}