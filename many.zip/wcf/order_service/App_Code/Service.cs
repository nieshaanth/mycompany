﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
public class Service : IService
{
SqlConnection con=new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);



    public int placeorder(Order obj)
    {
        try
        {
            SqlCommand com_placeorder = new SqlCommand("insert orders values (@name,@amt,@city)", con);
            com_placeorder.Parameters.AddWithValue("@name", obj.customerName);
            com_placeorder.Parameters.AddWithValue("@amt", obj.OrderAmt);
            com_placeorder.Parameters.AddWithValue("@city", obj.OrderCity);
            con.Open();
            com_placeorder.ExecuteNonQuery();
            SqlCommand com_oid = new SqlCommand("select @@identity", con);
            obj.orderid = Convert.ToInt32(com_oid.ExecuteScalar());
            con.Close();
            return obj.orderid;
        }
        catch (Exception e)
        {
            ErrorInfo err = new ErrorInfo();
            err.errorid = 105;
            err.errordate = DateTime.Now.ToString();
            err.errordeatils = "Database Error  ";
            throw new FaultException<ErrorInfo>(err);

        
        }

        
    }

    public List<Order> getorders(string cname)
    {
        System.Threading.Thread.Sleep(8000);
        List<Order> ord_list = new List<Order>();
       
        SqlCommand com_orderlist = new SqlCommand("select * from orders where customername=@name", con);
        com_orderlist.Parameters.AddWithValue("@name", cname);
        con.Open();
        SqlDataReader dr = com_orderlist.ExecuteReader();

        while (dr.Read())
        {
            Order obj = new Order();
            obj.orderid = dr.GetInt32(0);
            obj.customerName = dr.GetString(1);
            obj.OrderAmt = dr.GetInt32(2);
            obj.OrderCity = dr.GetString(3);
            ord_list.Add(obj);
        }
        con.Close();
        return ord_list;
    }
}
