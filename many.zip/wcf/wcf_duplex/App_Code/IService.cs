﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService" in both code and config file together.
[ServiceContract(CallbackContract=typeof(ICallback))]
public interface IService//main contract for the service
{
    [OperationContract(IsOneWay=true)]
    void Sendrequest(string userid);

}
public interface ICallback //contract for the client
{
    [OperationContract(IsOneWay = true)]
    void Recievedata(string str);


}