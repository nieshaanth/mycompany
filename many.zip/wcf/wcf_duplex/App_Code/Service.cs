﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{

    public void Sendrequest(string userid)
    {
        ICallback client_ref = OperationContext.Current.GetCallbackChannel<ICallback>();//binding should be wshttpdualbinding
        client_ref.Recievedata("One" + DateTime.Now.ToString());
        
        System.Threading.Thread.Sleep(10000);
        client_ref.Recievedata("two" + DateTime.Now.ToString());

        System.Threading.Thread.Sleep(10000);
        client_ref.Recievedata("three" + DateTime.Now.ToString());

        System.Threading.Thread.Sleep(10000);
        client_ref.Recievedata("Four" +DateTime.Now.ToString());



    }
}
