﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace wcf_duplex_client
{
    public partial class Form1 : Form,ServiceReference1.IServiceCallback
    {
        public Form1()
        {
            InitializeComponent();
        }

       
      

        public void Recievedata(string str)
        {
            lst_data.Items.Add(str);
        }

        private void btn_callwcf_Click(object sender, EventArgs e)
        {
            ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient(new System.ServiceModel.InstanceContext(this), "WSDualHttpBinding_IService");
            proxy.Sendrequest("xyz");
        }
    }
}
