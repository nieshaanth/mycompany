﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
    [OperationBehavior(TransactionScopeRequired=true)]
    public int Placeorder(int productid, int productprice, int transid, string bankname)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        SqlCommand com_plaecorder = new SqlCommand("insert productorders values(@pid,@pprice,@tid,@bname,getdate())", con);
        com_plaecorder.Parameters.AddWithValue("@pid", productid);
        com_plaecorder.Parameters.AddWithValue("@pprice", productprice);
        com_plaecorder.Parameters.AddWithValue("@tid", transid);
        com_plaecorder.Parameters.AddWithValue("bname", bankname);
        con.Open();
        com_plaecorder.ExecuteNonQuery();
        SqlCommand com_orderid = new SqlCommand("select @@identity", con);
        int oid = Convert.ToInt32(com_orderid.ExecuteScalar());
        con.Close();
        return oid;
    }
}
