﻿namespace transaction_client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_accntno = new System.Windows.Forms.TextBox();
            this.txt_bankname = new System.Windows.Forms.TextBox();
            this.txt_prodid = new System.Windows.Forms.TextBox();
            this.txt_prodprice = new System.Windows.Forms.TextBox();
            this.btn_buynow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Account No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Bank Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Product Id:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Product Price";
            // 
            // txt_accntno
            // 
            this.txt_accntno.Location = new System.Drawing.Point(132, 19);
            this.txt_accntno.Name = "txt_accntno";
            this.txt_accntno.Size = new System.Drawing.Size(100, 20);
            this.txt_accntno.TabIndex = 4;
            // 
            // txt_bankname
            // 
            this.txt_bankname.Location = new System.Drawing.Point(132, 48);
            this.txt_bankname.Name = "txt_bankname";
            this.txt_bankname.Size = new System.Drawing.Size(100, 20);
            this.txt_bankname.TabIndex = 5;
            // 
            // txt_prodid
            // 
            this.txt_prodid.Location = new System.Drawing.Point(132, 81);
            this.txt_prodid.Name = "txt_prodid";
            this.txt_prodid.Size = new System.Drawing.Size(100, 20);
            this.txt_prodid.TabIndex = 6;
            // 
            // txt_prodprice
            // 
            this.txt_prodprice.Location = new System.Drawing.Point(132, 118);
            this.txt_prodprice.Name = "txt_prodprice";
            this.txt_prodprice.Size = new System.Drawing.Size(100, 20);
            this.txt_prodprice.TabIndex = 7;
            // 
            // btn_buynow
            // 
            this.btn_buynow.Location = new System.Drawing.Point(76, 188);
            this.btn_buynow.Name = "btn_buynow";
            this.btn_buynow.Size = new System.Drawing.Size(75, 23);
            this.btn_buynow.TabIndex = 8;
            this.btn_buynow.Text = "Buy Now";
            this.btn_buynow.UseVisualStyleBackColor = true;
            this.btn_buynow.Click += new System.EventHandler(this.btn_buynow_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btn_buynow);
            this.Controls.Add(this.txt_prodprice);
            this.Controls.Add(this.txt_prodid);
            this.Controls.Add(this.txt_bankname);
            this.Controls.Add(this.txt_accntno);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
           
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_accntno;
        private System.Windows.Forms.TextBox txt_bankname;
        private System.Windows.Forms.TextBox txt_prodid;
        private System.Windows.Forms.TextBox txt_prodprice;
        private System.Windows.Forms.Button btn_buynow;
    }
}

