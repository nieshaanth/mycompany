﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Transactions;

namespace transaction_client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void btn_buynow_Click(object sender, EventArgs e)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    ServiceReference_bank.ServiceClient bank_proxy = new ServiceReference_bank.ServiceClient("WSHttpBinding_IService");
                    int transid = bank_proxy.makepayment(Convert.ToInt32(txt_accntno.Text), Convert.ToInt32(txt_prodprice.Text));
                    ServiceReference_order.ServiceClient order_client = new ServiceReference_order.ServiceClient("WSHttpBinding_IService1");

                    int orderid = order_client.Placeorder(Convert.ToInt32(txt_prodid.Text), Convert.ToInt32(txt_prodprice.Text), transid, txt_bankname.Text);

                    MessageBox.Show("wait");
                    scope.Complete();
                    MessageBox.Show("Order placed Successfully : order id =" + orderid);

                }
            }
            catch(Exception exp) {
                MessageBox.Show("Order id denied"+exp.Message);
            }
        }
    }
}
