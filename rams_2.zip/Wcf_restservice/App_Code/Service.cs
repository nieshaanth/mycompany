﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;


// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.

public class Service : IService
{

    public Order FindOrder(string OrderID)
    {
        int oid = Convert.ToInt32(OrderID);
        Order obj = new Order();
        obj.OrderID = oid;
        obj.CustomerName = "Latha";
        obj.OrderAmt = 2500;
        obj.OrderDetails = "Online Order";
        return obj;
    }

    public List<Order> Getorders(string CustomerName)
    {
        List<Order> ordlist = new List<Order>();
        ordlist.Add(new Order
            {
            OrderID=1001,
            CustomerName="Latha",
            OrderAmt=2500,
        OrderDetails="Online Order"
         });
        ordlist.Add(new Order
            {
                  OrderID=1002,
            CustomerName="Lucy",
            OrderAmt=2500,
        OrderDetails="Online Order"
            });
        return ordlist;
    }
}
