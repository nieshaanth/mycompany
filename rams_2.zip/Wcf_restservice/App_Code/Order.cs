﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

/// <summary>
/// Summary description for Order
/// </summary>
/// 
[DataContract]
public class Order
{
    [DataMember]
    public int OrderID { get;set; }

    [DataMember]
    public string CustomerName { get; set; }

    [DataMember]
    public int OrderAmt { get; set; }

    [DataMember]
    public string OrderDetails { get; set; }
}