﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Runtime.Serialization.Json; //Add  dll reference

namespace Win_restservice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_call_Click(object sender, EventArgs e)
        {
            WebClient client_order = new WebClient();
            string address="http://localhost:53399/Wcf_restservice/Service.svc/myrestservice/FindOrder/"+txt_call.Text;
            client_order.OpenReadCompleted += new OpenReadCompletedEventHandler(client_order_OpenReadCompleted);
            client_order.OpenReadAsync(new Uri(address,UriKind.Absolute));
        }

        void client_order_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            DataContractJsonSerializer json = new DataContractJsonSerializer(typeof(Order));
            Order obj = json.ReadObject(e.Result) as Order;
            MessageBox.Show(obj.OrderID+" "+obj.OrderAmt);
        }

        private void btn_get_Click(object sender, EventArgs e)
        {
            WebClient client_getorders = new WebClient();
            string address = "http://localhost:53399/Wcf_restservice/Service.svc/myrestservice/Getorders/"+txt_call.Text;
            client_getorders.OpenReadCompleted += new OpenReadCompletedEventHandler(client_getorders_OpenReadCompleted);
            client_getorders.OpenReadAsync(new Uri(address, UriKind.Absolute));
        }

        void client_getorders_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            DataContractJsonSerializer json=new DataContractJsonSerializer(typeof(List<Order>));
            List<Order> list = json.ReadObject(e.Result) as List<Order>;
            dg_orders.DataSource = list;

        }
    }
}
