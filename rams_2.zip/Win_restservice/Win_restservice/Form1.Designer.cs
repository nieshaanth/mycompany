﻿namespace Win_restservice
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_call = new System.Windows.Forms.Button();
            this.txt_call = new System.Windows.Forms.TextBox();
            this.btn_get = new System.Windows.Forms.Button();
            this.dg_orders = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_orders)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_call
            // 
            this.btn_call.Location = new System.Drawing.Point(52, 44);
            this.btn_call.Name = "btn_call";
            this.btn_call.Size = new System.Drawing.Size(190, 41);
            this.btn_call.TabIndex = 0;
            this.btn_call.Text = "CALL REST SERVICE";
            this.btn_call.UseVisualStyleBackColor = true;
            this.btn_call.Click += new System.EventHandler(this.btn_call_Click);
            // 
            // txt_call
            // 
            this.txt_call.Location = new System.Drawing.Point(261, 55);
            this.txt_call.Name = "txt_call";
            this.txt_call.Size = new System.Drawing.Size(141, 20);
            this.txt_call.TabIndex = 1;
            // 
            // btn_get
            // 
            this.btn_get.Location = new System.Drawing.Point(52, 118);
            this.btn_get.Name = "btn_get";
            this.btn_get.Size = new System.Drawing.Size(363, 40);
            this.btn_get.TabIndex = 2;
            this.btn_get.Text = "GET ORDERS";
            this.btn_get.UseVisualStyleBackColor = true;
            this.btn_get.Click += new System.EventHandler(this.btn_get_Click);
            // 
            // dg_orders
            // 
            this.dg_orders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_orders.Location = new System.Drawing.Point(52, 189);
            this.dg_orders.Name = "dg_orders";
            this.dg_orders.Size = new System.Drawing.Size(580, 313);
            this.dg_orders.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(674, 546);
            this.Controls.Add(this.dg_orders);
            this.Controls.Add(this.btn_get);
            this.Controls.Add(this.txt_call);
            this.Controls.Add(this.btn_call);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Red;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dg_orders)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_call;
        private System.Windows.Forms.TextBox txt_call;
        private System.Windows.Forms.Button btn_get;
        private System.Windows.Forms.DataGridView dg_orders;
    }
}

