﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for department
/// </summary>
public class department
{
    public int dept_id { get; set; }
    public string deptname{get;set;}
}