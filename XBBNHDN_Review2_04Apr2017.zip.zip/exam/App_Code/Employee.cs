﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public class Employee
{
    public int employeeid { get; set; }

    public string employeeename { get; set; }
    public string employeedesignation { get; set; }
    public DateTime dob { get; set; }
    public int deptid { get; set; }
    public string deptname { get; set; }
    
    
}