﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;


/// <summary>
/// Summary description for employeeDAL
/// </summary>
public class employeeDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public bool addemployee(Employee emp)
    {
        SqlCommand com_addemployee = new SqlCommand("insert Employee_XBBNHDN values(@name,@dob,@desig,@deptid)", con);
        com_addemployee.Parameters.AddWithValue("@name", emp.employeeename);
        com_addemployee.Parameters.AddWithValue("@dob", emp.dob);
        com_addemployee.Parameters.AddWithValue("@desig", emp.employeedesignation);
        com_addemployee.Parameters.AddWithValue("@deptid", emp.deptid);
        con.Open();
        com_addemployee.ExecuteNonQuery();
        SqlCommand com_empid = new SqlCommand("select @@identity", con);
        emp.employeeid = Convert.ToInt32(com_empid.ExecuteScalar());
        return true;


    
    }

    public List<Employee> getdetails(int empid)
    {
        List<Employee> employeelist = new List<Employee>();
        SqlCommand com_check=new SqlCommand("select count(*) from Employee_XBBNHDN where emp_id=@id  ", con);
        con.Open();
        com_check.Parameters.AddWithValue("id", empid);
        int check=Convert.ToInt32( com_check.ExecuteScalar());

        if (check != 0)
        {
            SqlCommand com_select = new SqlCommand("select dept_id from Employee_XBBNHDN  where emp_id=@id", con);
             com_select.Parameters.AddWithValue("id", empid);
         
            int deptid=Convert.ToInt32(com_select.ExecuteScalar());

            SqlCommand com_dept_name = new SqlCommand("select dept_name from department_XBBNHDN where dept_id=@did", con);
            com_dept_name.Parameters.AddWithValue("did", deptid);
            string dnam = Convert.ToString(com_dept_name.ExecuteScalar());


            SqlCommand com_details = new SqlCommand("select * from Employee_XBBNHDN where emp_id=@id ", con);
            com_details.Parameters.AddWithValue("id", empid);

            SqlDataReader dr = com_details.ExecuteReader();
            Employee emp = new Employee();

            while (dr.Read())
            {
                emp.employeeid = dr.GetInt32(0);
                emp.employeeename = dr.GetString(1);
                emp.dob = dr.GetDateTime(2);
                emp.employeedesignation = dr.GetString(3);
                emp.deptid = dr.GetInt32(4);

               
                emp.deptname = dnam;
                

                employeelist.Add(emp);
            }
            con.Close();
            return employeelist;
        }
        else
        { 
            return null;
        }

    }

    
}