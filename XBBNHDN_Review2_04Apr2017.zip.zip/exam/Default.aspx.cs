﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
   
    protected void btn_addemp_Click(object sender, EventArgs e)
    {
        Employee emp = new Employee();
        emp.employeeename = txt_empname.Text;
        emp.dob =Convert.ToDateTime( txt_dob.Text);
        emp.employeedesignation = txt_desig.Text;
        emp.deptid = Convert.ToInt32(txt_deptid.Text);
        employeeDAL dal = new employeeDAL();
        dal.addemployee(emp);
        lbl_status.Text = "Employee Added Succesfully and employee id" + emp.employeeid.ToString();

    }
    protected void btn_getemp_Click(object sender, EventArgs e)
    {
        employeeDAL dal = new employeeDAL();
        int id = Convert.ToInt32(txt_empid.Text);
        List<Employee> emplist = dal.getdetails(id);
        if (emplist==null)
        {
            lbl_detailstatus.Text = "Sry EmployeeId Is not found in Database"; 
          
        }
        else
        {
            gv_empdetails.DataSource = emplist;
            gv_empdetails.DataBind();
                  
        }


    }
    protected void gv_empdetails_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}