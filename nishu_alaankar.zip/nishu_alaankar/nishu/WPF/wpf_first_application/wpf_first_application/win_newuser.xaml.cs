﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_first_application
{
    /// <summary>
    /// Interaction logic for win_newuser.xaml
    /// </summary>
    public partial class win_newuser : Window
    {
        public win_newuser()
        {
            InitializeComponent();
        }

        private void btn_SignUp_Click(object sender, RoutedEventArgs e)
        {
            
            if (txt_customername.Text == "nish" && Convert.ToInt32(txt_customerid.Text) == 1 && txt_customercity.Text == "chennai")
            {


                win_newproduct obj1 = new win_newproduct();
                MessageBox.Show("Welcome");
                obj1.Show();
                
                this.Close();
            }
            else
            {
                MessageBox.Show("User is not Registered");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txt_customerid.Text = App.Current.Properties["user_id"].ToString();
        }
    }
}
