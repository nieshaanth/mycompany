﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;


namespace wpf_databinding_employee
{
    class leaverequestDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool getleavereq(leaverequests obj)
        {
            SqlCommand com_leavereq = new SqlCommand("insert leaverequests values(@empid,getdate(),@leavedt,@total,@type,@reason,@manid", con);
            com_leavereq.Parameters.AddWithValue("@empid", obj.employeeId);
            com_leavereq.Parameters.AddWithValue("@leavdt", obj.leaveDt);
            com_leavereq.Parameters.AddWithValue("@total", obj.totalDays);
            com_leavereq.Parameters.AddWithValue("@type", obj.leaveType);
            com_leavereq.Parameters.AddWithValue("@reason", obj.leaveReason);
            com_leavereq.Parameters.AddWithValue("@manid", obj.managerId);
            con.Open();
            com_leavereq.ExecuteNonQuery();
            con.Close();
            SqlCommand com_leavid = new SqlCommand("select @@identity from leaverequests", con);
            int leavid = Convert.ToInt32( com_leavid.ExecuteScalar());
            return true;

            


        }

        public List<leaverequests> getLeavreq()
        {

            SqlCommand com_leavreq = new SqlCommand("select * from leavrequests", con);
            List<leaverequests> leavreqlist = new List<leaverequests>();



            con.Open();
            SqlDataReader dr = com_leavreq.ExecuteReader();
            while (dr.Read())
            {

                leaverequests l = new leaverequests();
                l.leaveId = dr.GetInt32(0);
                l.employeeId = dr.GetInt32(1);
                l.reqDt = dr.GetDateTime(2);
                l.leaveDt = dr.GetDateTime(3);
                l.totalDays = dr.GetInt32(4);
                l.leaveType = dr.GetString(5);
                l.leaveReason = dr.GetString(6);
                l.leaveStatus = dr.GetString(7);
               
                l.managerId = dr.GetInt32(8);


                leavreqlist.Add(l);            }
            con.Close();
            return leavreqlist;




        }
        
    }
}
