﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace wpf_databinding_employee
{
    class employeesDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool login(employees emp)
        {
            SqlCommand com_login = new SqlCommand("select count(*) from employees where employeeId=@empid and employeePassword=@emppwd", con);
            com_login.Parameters.Add("@empid", emp.employeeId);
            com_login.Parameters.Add("@emppwd", emp.employeePwd);
                       
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteNonQuery());
            con.Close();
            
            if (count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }


    }
}
