﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wpf_databinding_employee
{
    class leaverequests
    {
        public int leaveId { get; set; }
        public int employeeId { get; set; }
        public DateTime reqDt { get; set; }
        public DateTime leaveDt { get; set; }
        public int totalDays { get; set; }
        public string leaveReason { get; set; }
        public string leaveStatus { get; set; }
        public string leaveType { get; set; }
        public int managerId { get; set; }

    
    
    
    
    }
}
