﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wpf_databinding_employee
{
    class employees
    {
        public int employeeId { get; set; }
        public string employeeName { get; set; }
        public string employeeDept { get; set; }
        public string employeeDesig { get; set; }
        public int employeeExp { get; set; }
        public string employeePwd { get; set; }
        public int managerId { get; set; }
        
    
    
    
    }



}
