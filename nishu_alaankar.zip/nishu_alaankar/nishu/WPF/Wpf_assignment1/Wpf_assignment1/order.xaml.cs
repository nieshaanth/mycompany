﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_assignment1
{
    /// <summary>
    /// Interaction logic for order.xaml
    /// </summary>
    public partial class order : Window
    {
        public order()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txt_login.Text = App.Current.Properties["login_id"].ToString();
        }
    }
}
