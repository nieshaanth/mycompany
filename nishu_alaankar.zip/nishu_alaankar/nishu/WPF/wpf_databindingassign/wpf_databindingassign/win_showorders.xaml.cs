﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_databindingassign
{
    /// <summary>
    /// Interaction logic for win_showorders.xaml
    /// </summary>
    public partial class win_showorders : Window
    {
        public win_showorders()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            orderDAL dal = new orderDAL();
            int customer_ID=Convert.ToInt32(App.Current.Properties["cid"]);
            dg_orders.ItemsSource = dal.getorders(customer_ID);

        }
    }
}
