﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace wpf_databindingassign
{
    class productsDAL
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


        public List< products > getProduct()
        {
            
            SqlCommand com_product = new SqlCommand("select * from products", con);
            List<products> productslist = new List<products>();

           

            con.Open();
            SqlDataReader dr = com_product.ExecuteReader();
            while (dr.Read())
            {
                products p = new products();
                p.productId = dr.GetInt32(0);
                p.productName = dr.GetString(1);
                p.productPrice = dr.GetInt32(2);
                productslist.Add(p);
            }
                        con.Close();
                        return productslist;




        }


        public products getProduct(int productId)
        {
            products p = new products();
            SqlCommand com_product = new SqlCommand("select * from products where productId=@prodid", con);
            com_product.Parameters.AddWithValue("@prodid", productId);

            con.Open();
            SqlDataReader dr = com_product.ExecuteReader();
            if (dr.Read())
            {
                p.productId = dr.GetInt32(0);
                p.productName = dr.GetString(1);
                p.productPrice = dr.GetInt32(2);
            }
            con.Close();
            return p;




        }
 



    }
}
