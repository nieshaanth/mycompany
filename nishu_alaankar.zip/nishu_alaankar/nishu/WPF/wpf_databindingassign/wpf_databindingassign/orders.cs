﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wpf_databindingassign
{
    class orders
    {
        public string orderAddr { get; set; }
        public DateTime orderDate { get; set; }
        public int orderId { get; set; }
        
        public int productId { get; set; }
        public int productPrice { get; set; }
        public int productQty { get; set; }
        
        public int customerId { get; set; }
        public string customerName { get; set; }
       }
    }


