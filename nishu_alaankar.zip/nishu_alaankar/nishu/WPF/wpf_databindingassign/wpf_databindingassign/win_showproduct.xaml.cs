﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_databindingassign
{
    /// <summary>
    /// Interaction logic for win_showproduct.xaml
    /// </summary>
    public partial class win_showproduct : Window
    {
        public win_showproduct()
        {
            InitializeComponent();
        }

        private void btn_find_click_Click(object sender, RoutedEventArgs e)
        {
            productsDAL dal = new productsDAL();
            stp_product.DataContext = dal.getProduct(Convert.ToInt32(txt_pid.Text));
        }
    }
}
