﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_databindingassign
{
    /// <summary>
    /// Interaction logic for win_placeorder.xaml
    /// </summary>
    public partial class win_placeorder : Window
    {
        public win_placeorder()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            productsDAL dal = new productsDAL();
            lst_prod.ItemsSource = dal.getProduct();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            products p = lst_prod.SelectedItem as products;
            if (p != null)
            {
                orderDAL dal = new orderDAL();
                orders ord= new orders();
                ord.productId=p.productId;
                ord.productPrice=p.productPrice;
                ord.productQty=Convert.ToInt32(txt_qty.Text);
                ord.orderAddr=txt_addr.Text;
                ord.customerId=Convert.ToInt32(  App.Current.Properties["cid"]);
                dal.placeorder( ord);
                MessageBox.Show("YOur Order Is Placed Successfully" + ord.orderId);


            }
            else 
            {
                MessageBox.Show("Select atleast one product to place the order");

            }
        }

    }
}
