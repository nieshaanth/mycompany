﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace wpf_databindingassign
{
    class orderDAL
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool placeorder(orders ord)
        { 
        SqlCommand com_order_insert = new SqlCommand("insert orders values(@custid,getdate(),@custaddr,@prodid,@prodprice,@prodqty)",con);
            com_order_insert.Parameters.AddWithValue("@custid",ord.customerId);            
            com_order_insert.Parameters.AddWithValue("@custaddr",ord.orderAddr);
            com_order_insert.Parameters.AddWithValue("@prodid",ord.productId);
            com_order_insert.Parameters.AddWithValue("@prodprice",ord.productPrice);
            com_order_insert.Parameters.AddWithValue("@prodqty",ord.productQty);
             
            con.Open();
            com_order_insert.ExecuteNonQuery();

            SqlCommand com_orderid=new SqlCommand("select @@identity",con);
            
            int orderid = Convert.ToInt32(com_orderid.ExecuteScalar());
            ord.orderId = orderid;

            con.Close();
            return true;
      



        }
        public List<orders> getorders (int customerid)
        {

            List<orders> orderslist = new List<orders>();
            
            SqlCommand com_orders = new SqlCommand("select * from orders where customerId=@custid", con);
            com_orders.Parameters.AddWithValue("@custid",customerid);

            con.Open();
            SqlDataReader dr = com_orders.ExecuteReader();
            while (dr.Read())
            {

                orders ord = new orders();
                ord.orderId=dr.GetInt32(0);
                ord.customerId = dr.GetInt32(1);                
                ord.orderDate = dr.GetDateTime(2);
                ord.orderAddr = dr.GetString(3);
                ord.productId = dr.GetInt32(4);
                ord.productPrice = dr.GetInt32(5);
                ord.productQty = dr.GetInt32(6);

                orderslist.Add(ord);

            }
            con.Close();
            return orderslist;
        
        }
    }

}
