﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wpf_databindingassign
{
    class products
    {
        public int productId { get; set; }
        
        public string productName { get; set; }

        
        public int productPrice { get; set; }
        
        






    }



}
