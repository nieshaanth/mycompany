﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_databindingassign
{
    /// <summary>
    /// Interaction logic for win_login.xaml
    /// </summary>
    public partial class win_login : Window
    {
        public win_login()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, RoutedEventArgs e)
        {
            customerDAL dal = new customerDAL();
            customers c =new customers();
            c.customerId=Convert.ToInt32( txt_login.Text);
            c.customerPassword=txt_pwd.Password;

            if (dal.login(c))
            { 
            MessageBox.Show("Valid Customer");
            App.Current.Properties.Add("cid",txt_login.Text);
            win_Home home=new win_Home();
            home.Show();
            this.Close();

            }
            else
            {
            MessageBox.Show("Invalid User");
            }

        }
    }
}
