﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
namespace wpf_databindingassign
{
    class customerDAL
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public bool login(customers obj)
        {
            con.Open();
            SqlCommand com_cust_login = new SqlCommand("select count(*) from customers where customerId=@custid and customerPassword=@custpwd", con);
        com_cust_login.Parameters.AddWithValue("@custid",obj.customerId);
        com_cust_login.Parameters.AddWithValue("@custpwd", obj.customerPassword);

        int count = Convert.ToInt32(com_cust_login.ExecuteScalar());                    
                    
        con.Close();

        if (count > 0)
        {
            return true;

        }
        else
        {
            return false;

        }


      
    }






    }
}
