﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_databindingassign
{
    /// <summary>
    /// Interaction logic for win_Home.xaml
    /// </summary>
    public partial class win_Home : Window
    {
        public win_Home()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           txt_CustomerId.Text ="Welcome,"+ App.Current.Properties["cid"].ToString();

        }

        private void btn_find_product_Click(object sender, RoutedEventArgs e)
        {
            win_showproduct obj = new win_showproduct();
            obj.Show();

        }

        private void btn_place_order_Click(object sender, RoutedEventArgs e)
        {
            win_placeorder obj = new win_placeorder();
            obj.Show();

        }

        private void btn_show_order_Click(object sender, RoutedEventArgs e)
        {
            win_showorders obj = new win_showorders();
            obj.Show();
        }
    }
}
