﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wpf_databindingassign
{
    class customers
    {
        public int customerId { get; set; }
        public string customerName{get;set;}
        public string customerEmailid{get;set;}
        public string customerPassword { get; set; }
    }
}
