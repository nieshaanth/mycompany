﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace ado__proc_calling
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            employee obj = new employee();
            obj.empid = Convert.ToInt32(txt_username.Text);
            obj.emppwd = txt_pw.Text;
            employee_DAL dal = new employee_DAL();
            bool status = dal.login(obj);
            if (status)
            {
                MessageBox.Show("Valid User: " + obj.empname);
            }
            else 
            {
                MessageBox.Show("Invalid User");
            }
        }

       
    }
}
