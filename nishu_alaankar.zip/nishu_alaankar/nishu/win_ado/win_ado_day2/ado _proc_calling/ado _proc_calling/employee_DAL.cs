﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ado__proc_calling
{
     
    
    
    class employee_DAL
    {
        public bool login(employee obj)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

            SqlCommand com_login = new SqlCommand();

            com_login.Connection = con;
            com_login.CommandType = CommandType.StoredProcedure;

            com_login.CommandText = "proc_login";
         

        SqlParameter para_empid=new SqlParameter("@empid",SqlDbType.Int);
        SqlParameter para_emppw = new SqlParameter("@emppw", SqlDbType.VarChar, 30);
        SqlParameter para_empname= new SqlParameter("@empname",SqlDbType.VarChar,30);

        SqlParameter para_return = new SqlParameter();

        para_return.Direction = ParameterDirection.ReturnValue;
        
        para_empid.Value=obj.empid;
        para_emppw.Value=obj.emppwd;


            para_empname.Direction=ParameterDirection.Output;


            com_login.Parameters.Add(para_empid);
            com_login.Parameters.Add(para_emppw);
            com_login.Parameters.Add(para_empname);
            com_login.Parameters.Add(para_return);


            con.Open();
            com_login.ExecuteNonQuery();
            con.Close();

            int count = Convert.ToInt32(para_return.Value);
            if (count > 0)
            {
                obj.empname = para_empname.Value.ToString();
                return true;
            }
            else
            {
                return false;

            } 
        }






















    }
}
