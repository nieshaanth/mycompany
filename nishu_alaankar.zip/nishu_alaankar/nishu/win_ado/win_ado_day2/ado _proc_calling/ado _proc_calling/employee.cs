﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ado__proc_calling
{
    class employee
    {
        public int empid { get; set; }
        public string emppwd { get; set; }
        public string empname { get; set; }
    
    }

}
