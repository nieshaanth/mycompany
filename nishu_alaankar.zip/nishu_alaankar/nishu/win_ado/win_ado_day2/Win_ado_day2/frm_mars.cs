﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ado_day2
{
    public partial class frm_mars : Form
    {
        public frm_mars()
        {
            InitializeComponent();
        }

        private void btn_mars_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            con.Open();
            SqlCommand com_order = new SqlCommand("select * from orders", con);
            SqlDataReader dr_order=com_order.ExecuteReader();



            DataTable dt = new DataTable();
            dt.Load(dr_order);




            dg_order.DataSource = dt;

            SqlCommand com_items = new SqlCommand("select * from orderdetails", con);
            SqlDataReader dr_items = com_items.ExecuteReader();
            //reading;
            con.Close();
        }

        private void frm_mars_Load(object sender, EventArgs e)
        {

        }
    }
}
