﻿namespace Win_ado_day2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.txt_customerName = new System.Windows.Forms.TextBox();
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_custname = new System.Windows.Forms.Label();
            this.txt_itemid = new System.Windows.Forms.TextBox();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.lbl_itemqty = new System.Windows.Forms.Label();
            this.txt_itemqty = new System.Windows.Forms.TextBox();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_orderid
            // 
            this.txt_orderid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_orderid.Location = new System.Drawing.Point(359, 58);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(190, 29);
            this.txt_orderid.TabIndex = 0;
            // 
            // txt_customerName
            // 
            this.txt_customerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerName.Location = new System.Drawing.Point(359, 112);
            this.txt_customerName.Name = "txt_customerName";
            this.txt_customerName.Size = new System.Drawing.Size(190, 29);
            this.txt_customerName.TabIndex = 1;
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_orderid.Location = new System.Drawing.Point(133, 58);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(93, 24);
            this.lbl_orderid.TabIndex = 2;
            this.lbl_orderid.Text = "OrderId: ";
            // 
            // lbl_custname
            // 
            this.lbl_custname.AutoSize = true;
            this.lbl_custname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custname.Location = new System.Drawing.Point(133, 119);
            this.lbl_custname.Name = "lbl_custname";
            this.lbl_custname.Size = new System.Drawing.Size(166, 24);
            this.lbl_custname.TabIndex = 3;
            this.lbl_custname.Text = "Customer Name:";
            // 
            // txt_itemid
            // 
            this.txt_itemid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemid.Location = new System.Drawing.Point(359, 193);
            this.txt_itemid.Name = "txt_itemid";
            this.txt_itemid.Size = new System.Drawing.Size(190, 29);
            this.txt_itemid.TabIndex = 5;
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemid.Location = new System.Drawing.Point(133, 196);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(78, 24);
            this.lbl_itemid.TabIndex = 4;
            this.lbl_itemid.Text = "ItemId: ";
            // 
            // lbl_itemqty
            // 
            this.lbl_itemqty.AutoSize = true;
            this.lbl_itemqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemqty.Location = new System.Drawing.Point(133, 270);
            this.lbl_itemqty.Name = "lbl_itemqty";
            this.lbl_itemqty.Size = new System.Drawing.Size(82, 24);
            this.lbl_itemqty.TabIndex = 6;
            this.lbl_itemqty.Text = "Itemqty:";
            // 
            // txt_itemqty
            // 
            this.txt_itemqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemqty.Location = new System.Drawing.Point(359, 267);
            this.txt_itemqty.Name = "txt_itemqty";
            this.txt_itemqty.Size = new System.Drawing.Size(190, 29);
            this.txt_itemqty.TabIndex = 7;
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemprice.Location = new System.Drawing.Point(133, 347);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(103, 24);
            this.lbl_itemprice.TabIndex = 8;
            this.lbl_itemprice.Text = "ItemPrice:";
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemprice.Location = new System.Drawing.Point(359, 344);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(190, 29);
            this.txt_itemprice.TabIndex = 9;
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_placeorder.Location = new System.Drawing.Point(128, 430);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(145, 59);
            this.btn_placeorder.TabIndex = 10;
            this.btn_placeorder.Text = "Place Order";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(717, 642);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.txt_itemqty);
            this.Controls.Add(this.lbl_itemqty);
            this.Controls.Add(this.txt_itemid);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.lbl_custname);
            this.Controls.Add(this.lbl_orderid);
            this.Controls.Add(this.txt_customerName);
            this.Controls.Add(this.txt_orderid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.TextBox txt_customerName;
        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_custname;
        private System.Windows.Forms.TextBox txt_itemid;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.Label lbl_itemqty;
        private System.Windows.Forms.TextBox txt_itemqty;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.TextBox txt_itemprice;
        private System.Windows.Forms.Button btn_placeorder;
    }
}

