﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Win_ado_day2
{
    public partial class frm_xml : Form
    {
        public frm_xml()
        {
            InitializeComponent();
        }

        private void btn_xml_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            SqlDataAdapter adapter_orders = new SqlDataAdapter("select * from orders ", con);
            DataSet ds = new DataSet();

            adapter_orders.Fill(ds, "ord");
            ds.WriteXml("H:/nishu/xml_filegenerated/ords.xml ");
                MessageBox .Show ("XMl file generated");

        }

        private void btn_readxml_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            ds.ReadXml("H:/nishu/xml_filegenerated/ords.xml ");
            dg_ordersxml.DataSource = ds.Tables[0];
        }
    }
}
