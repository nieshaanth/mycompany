﻿namespace Win_ado_day2
{
    partial class frm_mars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_mars = new System.Windows.Forms.Button();
            this.dg_order = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_order)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_mars
            // 
            this.btn_mars.Location = new System.Drawing.Point(90, 29);
            this.btn_mars.Name = "btn_mars";
            this.btn_mars.Size = new System.Drawing.Size(75, 23);
            this.btn_mars.TabIndex = 0;
            this.btn_mars.Text = "MARS";
            this.btn_mars.UseVisualStyleBackColor = true;
            this.btn_mars.Click += new System.EventHandler(this.btn_mars_Click);
            // 
            // dg_order
            // 
            this.dg_order.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_order.Location = new System.Drawing.Point(90, 94);
            this.dg_order.Name = "dg_order";
            this.dg_order.Size = new System.Drawing.Size(240, 150);
            this.dg_order.TabIndex = 1;
            // 
            // frm_mars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(692, 434);
            this.Controls.Add(this.dg_order);
            this.Controls.Add(this.btn_mars);
            this.Name = "frm_mars";
            this.Text = "frm_mars";
            this.Load += new System.EventHandler(this.frm_mars_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_order)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_mars;
        private System.Windows.Forms.DataGridView dg_order;
    }
}