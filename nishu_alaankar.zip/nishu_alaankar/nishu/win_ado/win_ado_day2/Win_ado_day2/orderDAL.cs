﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace Win_ado_day2
{
    class orderDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public void Addorder(order ord)
        {

            try
            {
                con.Open();

                SqlTransaction trans = con.BeginTransaction();

                SqlCommand com_order = new SqlCommand("insert orders values(@custname,getdate())", con);
                com_order.Parameters.AddWithValue("@custname", ord.CustomerName);

                com_order.Transaction = trans;
                com_order.ExecuteNonQuery();

                SqlCommand com_orderID = new SqlCommand("select @@identity  ", con);
                com_orderID.Transaction = trans;

                int orderid = Convert.ToInt32(com_orderID.ExecuteScalar());
                ord.OrderId = orderid;

                foreach (item item in ord.items)
                {
                    SqlCommand com_item = new SqlCommand("insert orderdetails values (@oid,@itemid,@itemprice,@itemqty)", con);


                    com_item.Parameters.AddWithValue("@oid", orderid);
                    com_item.Parameters.AddWithValue("@itemid", item.itemId);
                    com_item.Parameters.AddWithValue("@itemprice", item.itemPrice);
                    com_item.Parameters.AddWithValue("@itemqty", item.itemQty);
                    com_item.Transaction = trans;
                    com_item.ExecuteNonQuery();



                }
                // System.Windows.Forms.MessageBox.Show("wait");
                trans.Commit();
            }

            finally
            {
                if (con.State ==  System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
            
             

        //ADO.NET

    
            
        
        
        }
    }

