﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ado_day2
{
    class order
    {
        public int OrderId { get; set; }
        public String CustomerName { get; set; }
        public DateTime OrderDate{get;set;}


        public List<item > items = new List<item>();

        public void AddItem(item item)
        {
            items.Add(item);
        
        }



    }
}
