﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_ado_day2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_placeorder_Click(object sender, EventArgs e)
        {
            try
            {
                order ord = new order();
                ord.CustomerName = txt_customerName.Text;

                item item = new item();
                item.itemId = Convert.ToInt32(txt_itemid.Text);
                item.itemPrice = Convert.ToInt32(txt_itemprice.Text);
                item.itemQty = Convert.ToInt32(txt_itemqty.Text);

                ord.AddItem(item);

                orderDAL dal = new orderDAL();
                dal.Addorder(ord);

                txt_orderid.Text = ord.OrderId.ToString();


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message); 
            }



        }

       
    }
}
