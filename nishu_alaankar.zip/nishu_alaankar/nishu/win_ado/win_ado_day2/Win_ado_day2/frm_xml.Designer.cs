﻿namespace Win_ado_day2
{
    partial class frm_xml
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_xml = new System.Windows.Forms.Button();
            this.btn_readxml = new System.Windows.Forms.Button();
            this.dg_ordersxml = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_ordersxml)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_xml
            // 
            this.btn_xml.Location = new System.Drawing.Point(67, 43);
            this.btn_xml.Name = "btn_xml";
            this.btn_xml.Size = new System.Drawing.Size(75, 23);
            this.btn_xml.TabIndex = 0;
            this.btn_xml.Text = "Save XML";
            this.btn_xml.UseVisualStyleBackColor = true;
            this.btn_xml.Click += new System.EventHandler(this.btn_xml_Click);
            // 
            // btn_readxml
            // 
            this.btn_readxml.Location = new System.Drawing.Point(67, 144);
            this.btn_readxml.Name = "btn_readxml";
            this.btn_readxml.Size = new System.Drawing.Size(75, 23);
            this.btn_readxml.TabIndex = 1;
            this.btn_readxml.Text = "Read XML";
            this.btn_readxml.UseVisualStyleBackColor = true;
            this.btn_readxml.Click += new System.EventHandler(this.btn_readxml_Click);
            // 
            // dg_ordersxml
            // 
            this.dg_ordersxml.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_ordersxml.Location = new System.Drawing.Point(29, 200);
            this.dg_ordersxml.Name = "dg_ordersxml";
            this.dg_ordersxml.Size = new System.Drawing.Size(385, 225);
            this.dg_ordersxml.TabIndex = 2;
            // 
            // frm_xml
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 475);
            this.Controls.Add(this.dg_ordersxml);
            this.Controls.Add(this.btn_readxml);
            this.Controls.Add(this.btn_xml);
            this.Name = "frm_xml";
            this.Text = "frm_xml";
            ((System.ComponentModel.ISupportInitialize)(this.dg_ordersxml)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_xml;
        private System.Windows.Forms.Button btn_readxml;
        private System.Windows.Forms.DataGridView dg_ordersxml;
    }
}