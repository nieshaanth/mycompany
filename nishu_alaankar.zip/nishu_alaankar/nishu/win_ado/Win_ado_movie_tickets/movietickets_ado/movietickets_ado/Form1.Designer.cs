﻿namespace movietickets_ado
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_transid = new System.Windows.Forms.Label();
            this.lbl_accntno = new System.Windows.Forms.Label();
            this.lbl_amount = new System.Windows.Forms.Label();
            this.btn_buytickets = new System.Windows.Forms.Button();
            this.txt_transid = new System.Windows.Forms.TextBox();
            this.txt_accntno = new System.Windows.Forms.TextBox();
            this.txt_amount = new System.Windows.Forms.TextBox();
            this.lbl_ticketNo = new System.Windows.Forms.Label();
            this.lbl_movname = new System.Windows.Forms.Label();
            this.lbl_no_of_tickets = new System.Windows.Forms.Label();
            this.lbl_movdate = new System.Windows.Forms.Label();
            this.lbl_timing = new System.Windows.Forms.Label();
            this.txt_ticno = new System.Windows.Forms.TextBox();
            this.txt_movname = new System.Windows.Forms.TextBox();
            this.txt_no_of_tic = new System.Windows.Forms.TextBox();
            this.cmb_timing = new System.Windows.Forms.ComboBox();
            this.dtp_moviedate = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // lbl_transid
            // 
            this.lbl_transid.AutoSize = true;
            this.lbl_transid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_transid.Location = new System.Drawing.Point(485, 202);
            this.lbl_transid.Name = "lbl_transid";
            this.lbl_transid.Size = new System.Drawing.Size(73, 16);
            this.lbl_transid.TabIndex = 0;
            this.lbl_transid.Text = "Trans Id: ";
            // 
            // lbl_accntno
            // 
            this.lbl_accntno.AutoSize = true;
            this.lbl_accntno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accntno.Location = new System.Drawing.Point(24, 95);
            this.lbl_accntno.Name = "lbl_accntno";
            this.lbl_accntno.Size = new System.Drawing.Size(91, 16);
            this.lbl_accntno.TabIndex = 1;
            this.lbl_accntno.Text = "Account No:";
            // 
            // lbl_amount
            // 
            this.lbl_amount.AutoSize = true;
            this.lbl_amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_amount.Location = new System.Drawing.Point(24, 362);
            this.lbl_amount.Name = "lbl_amount";
            this.lbl_amount.Size = new System.Drawing.Size(59, 16);
            this.lbl_amount.TabIndex = 3;
            this.lbl_amount.Text = "Amount";
            // 
            // btn_buytickets
            // 
            this.btn_buytickets.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buytickets.Location = new System.Drawing.Point(235, 469);
            this.btn_buytickets.Name = "btn_buytickets";
            this.btn_buytickets.Size = new System.Drawing.Size(206, 23);
            this.btn_buytickets.TabIndex = 10;
            this.btn_buytickets.Text = "Buy Tickets";
            this.btn_buytickets.UseVisualStyleBackColor = true;
            this.btn_buytickets.Click += new System.EventHandler(this.btn_buytickets_Click);
            // 
            // txt_transid
            // 
            this.txt_transid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_transid.Location = new System.Drawing.Point(622, 196);
            this.txt_transid.Name = "txt_transid";
            this.txt_transid.Size = new System.Drawing.Size(209, 22);
            this.txt_transid.TabIndex = 15;
            this.txt_transid.TabStop = false;
            // 
            // txt_accntno
            // 
            this.txt_accntno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_accntno.Location = new System.Drawing.Point(141, 92);
            this.txt_accntno.Name = "txt_accntno";
            this.txt_accntno.Size = new System.Drawing.Size(209, 22);
            this.txt_accntno.TabIndex = 1;
            // 
            // txt_amount
            // 
            this.txt_amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_amount.Location = new System.Drawing.Point(141, 356);
            this.txt_amount.Name = "txt_amount";
            this.txt_amount.Size = new System.Drawing.Size(110, 22);
            this.txt_amount.TabIndex = 6;
            // 
            // lbl_ticketNo
            // 
            this.lbl_ticketNo.AutoSize = true;
            this.lbl_ticketNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ticketNo.Location = new System.Drawing.Point(485, 92);
            this.lbl_ticketNo.Name = "lbl_ticketNo";
            this.lbl_ticketNo.Size = new System.Drawing.Size(79, 16);
            this.lbl_ticketNo.TabIndex = 10;
            this.lbl_ticketNo.Text = "Ticket No:";
            // 
            // lbl_movname
            // 
            this.lbl_movname.AutoSize = true;
            this.lbl_movname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_movname.Location = new System.Drawing.Point(24, 169);
            this.lbl_movname.Name = "lbl_movname";
            this.lbl_movname.Size = new System.Drawing.Size(95, 16);
            this.lbl_movname.TabIndex = 11;
            this.lbl_movname.Text = "Movie Name";
            // 
            // lbl_no_of_tickets
            // 
            this.lbl_no_of_tickets.AutoSize = true;
            this.lbl_no_of_tickets.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_no_of_tickets.Location = new System.Drawing.Point(24, 318);
            this.lbl_no_of_tickets.Name = "lbl_no_of_tickets";
            this.lbl_no_of_tickets.Size = new System.Drawing.Size(102, 16);
            this.lbl_no_of_tickets.TabIndex = 12;
            this.lbl_no_of_tickets.Text = "No Of Tickets";
            // 
            // lbl_movdate
            // 
            this.lbl_movdate.AutoSize = true;
            this.lbl_movdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_movdate.Location = new System.Drawing.Point(24, 213);
            this.lbl_movdate.Name = "lbl_movdate";
            this.lbl_movdate.Size = new System.Drawing.Size(91, 16);
            this.lbl_movdate.TabIndex = 13;
            this.lbl_movdate.Text = "Movie Date:";
            // 
            // lbl_timing
            // 
            this.lbl_timing.AutoSize = true;
            this.lbl_timing.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_timing.Location = new System.Drawing.Point(24, 268);
            this.lbl_timing.Name = "lbl_timing";
            this.lbl_timing.Size = new System.Drawing.Size(55, 16);
            this.lbl_timing.TabIndex = 14;
            this.lbl_timing.Text = "Timing";
            // 
            // txt_ticno
            // 
            this.txt_ticno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ticno.Location = new System.Drawing.Point(622, 86);
            this.txt_ticno.Name = "txt_ticno";
            this.txt_ticno.Size = new System.Drawing.Size(127, 22);
            this.txt_ticno.TabIndex = 16;
            this.txt_ticno.TabStop = false;
            // 
            // txt_movname
            // 
            this.txt_movname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_movname.Location = new System.Drawing.Point(141, 169);
            this.txt_movname.Name = "txt_movname";
            this.txt_movname.Size = new System.Drawing.Size(127, 22);
            this.txt_movname.TabIndex = 2;
            // 
            // txt_no_of_tic
            // 
            this.txt_no_of_tic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_no_of_tic.Location = new System.Drawing.Point(141, 318);
            this.txt_no_of_tic.Name = "txt_no_of_tic";
            this.txt_no_of_tic.Size = new System.Drawing.Size(110, 22);
            this.txt_no_of_tic.TabIndex = 5;
            // 
            // cmb_timing
            // 
            this.cmb_timing.FormattingEnabled = true;
            this.cmb_timing.Location = new System.Drawing.Point(141, 263);
            this.cmb_timing.Name = "cmb_timing";
            this.cmb_timing.Size = new System.Drawing.Size(121, 21);
            this.cmb_timing.TabIndex = 4;
            // 
            // dtp_moviedate
            // 
            this.dtp_moviedate.Location = new System.Drawing.Point(141, 213);
            this.dtp_moviedate.Name = "dtp_moviedate";
            this.dtp_moviedate.Size = new System.Drawing.Size(200, 20);
            this.dtp_moviedate.TabIndex = 3;
            this.dtp_moviedate.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 589);
            this.Controls.Add(this.dtp_moviedate);
            this.Controls.Add(this.cmb_timing);
            this.Controls.Add(this.txt_no_of_tic);
            this.Controls.Add(this.txt_movname);
            this.Controls.Add(this.txt_ticno);
            this.Controls.Add(this.lbl_timing);
            this.Controls.Add(this.lbl_movdate);
            this.Controls.Add(this.lbl_no_of_tickets);
            this.Controls.Add(this.lbl_movname);
            this.Controls.Add(this.lbl_ticketNo);
            this.Controls.Add(this.txt_amount);
            this.Controls.Add(this.txt_accntno);
            this.Controls.Add(this.txt_transid);
            this.Controls.Add(this.btn_buytickets);
            this.Controls.Add(this.lbl_amount);
            this.Controls.Add(this.lbl_accntno);
            this.Controls.Add(this.lbl_transid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_transid;
        private System.Windows.Forms.Label lbl_accntno;
        private System.Windows.Forms.Label lbl_amount;
        private System.Windows.Forms.Button btn_buytickets;
        private System.Windows.Forms.TextBox txt_transid;
        private System.Windows.Forms.TextBox txt_accntno;
        private System.Windows.Forms.TextBox txt_amount;
        private System.Windows.Forms.Label lbl_ticketNo;
        private System.Windows.Forms.Label lbl_movname;
        private System.Windows.Forms.Label lbl_no_of_tickets;
        private System.Windows.Forms.Label lbl_movdate;
        private System.Windows.Forms.Label lbl_timing;
        private System.Windows.Forms.TextBox txt_ticno;
        private System.Windows.Forms.TextBox txt_movname;
        private System.Windows.Forms.TextBox txt_no_of_tic;
        private System.Windows.Forms.ComboBox cmb_timing;
        private System.Windows.Forms.DateTimePicker dtp_moviedate;
    }
}

