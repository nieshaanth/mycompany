﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace movietickets_ado
{
    class tickets_DAL
    {
        

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public void buytickets(Banktrans bt,tickets tic)
        {
            con.Open();
            SqlTransaction trans = con.BeginTransaction();
        
        SqlCommand com_banktr=new SqlCommand("insert banktrans values(@acctno,@amt,getdate())",con);
        
        com_banktr.Parameters.AddWithValue("@acctno", bt.accountno);
        com_banktr.Parameters.AddWithValue("@amt", bt.amt);
        com_banktr.Transaction = trans;

        com_banktr.ExecuteNonQuery();

        SqlCommand com_transid = new SqlCommand("select @@identity", con);

        com_transid.Transaction = trans;
        int transid =Convert.ToInt32( com_transid.ExecuteScalar());
        bt.transid = transid;

        SqlCommand com_tickets = new SqlCommand("insert tickets values (@movname,@movdate,@movtime,@no_tic,getdate(),@transid)", con);
        com_tickets.Parameters.AddWithValue("@movname", tic.moviename);
            com_tickets.Parameters.AddWithValue ("@movdate",tic.movdate);
            com_tickets.Parameters.AddWithValue("@movtime",tic.time);
            com_tickets.Parameters .AddWithValue ("@no_tic",tic.no_tic);
            com_tickets.Parameters .AddWithValue ("@transid",bt.transid);

            com_tickets.Transaction = trans;
            
            com_tickets.ExecuteNonQuery();

        


            SqlCommand com_ticid = new SqlCommand("select @@identity", con);

            com_ticid.Transaction = trans;
            int ticno = Convert.ToInt32(com_ticid.ExecuteScalar());
            tic.ticno = ticno;

            trans.Commit();

            con.Close();       
        
        
        
        
        }
           
    }
}
