﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace movietickets_ado
{
    class tickets
    {
        public int ticno { get; set; }
        public string moviename { get; set; }
        public DateTime movdate { get; set; }
        public string time { get; set; }
        public int no_tic { get; set; }
        public int transid { get; set; }
        public DateTime ticdate { get; set; }
    
    
    
    }



}
