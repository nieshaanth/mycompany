﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace movietickets_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_timing.Items.Add("10.30am");
            cmb_timing.Items.Add("2.00pm");
            cmb_timing.Items.Add("4.30pm");
            cmb_timing.Items.Add("7.00pm");
        }

        private void btn_buytickets_Click(object sender, EventArgs e)
        {
            Banktrans bt = new Banktrans();
            bt.accountno = Convert.ToInt32(txt_accntno.Text);
            bt.amt = Convert.ToInt32(txt_amount.Text);


            tickets tic = new tickets();
          
            tic.moviename = txt_movname.Text;
            tic.movdate = Convert .ToDateTime(dtp_moviedate.Text);
            tic.time = cmb_timing.Text;
            tic.no_tic = Convert.ToInt32(txt_no_of_tic.Text);

            tickets_DAL dal = new tickets_DAL();
            dal.buytickets(bt,tic);

            
            txt_transid.Text = bt.transid.ToString();
            
            txt_ticno.Text = tic.ticno.ToString();

            

        }

        

        
    }
}
