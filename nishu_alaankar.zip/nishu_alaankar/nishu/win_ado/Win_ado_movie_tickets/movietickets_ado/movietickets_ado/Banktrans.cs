﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace movietickets_ado
{
    class Banktrans
    {
        public int transid { get; set; }
        public int accountno { get; set; }
        public int amt { get; set; }
        public DateTime transdt { get; set; }





      

    }
}
