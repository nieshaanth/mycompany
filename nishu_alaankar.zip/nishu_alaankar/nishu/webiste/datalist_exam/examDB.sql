create database web_list
use web_list

create table Questions
(
QuestionId int identity(1,1) primary key,
Question varchar(1000),
Option1 varchar(100),
Option2 varchar(100),
Option3 varchar(100),
Option4 varchar(100),
Answer varchar(100)

)
drop table Questions

insert questions values ('Who is the founder of MicroSoft?','BillGates','Steve Jobs','Sundar Puchai','JeffBesos','1')
insert questions values ('What is the capital of Tamilnadu?' ,'Chennai','Salem','Madurai','Trichy' ,'1')
insert questions values('5+5=?' ,'10','5','15','25','1')
insert questions values ('10*10=?','50','100','200','1000','2')
insert questions values('100-20=?','50','60','80','100','3')
select *from Questions