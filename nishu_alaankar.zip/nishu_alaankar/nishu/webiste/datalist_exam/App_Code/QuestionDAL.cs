﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
/// <summary>
/// Summary description for QuestionDAL
/// </summary>
public class QuestionDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


    public List<Question> GetQuestions()
    {
        List<Question> list_ques=new List<Question>();
        SqlCommand com_getques = new SqlCommand("select QuestionId,Question,Option1,Option2,Option3,Option4 from Questions", con);
        con.Open();
        SqlDataReader dr = com_getques.ExecuteReader();
        while (dr.Read())
        {
            Question q = new Question();
            q.QuestionID = dr.GetInt32(0);
            q.QuestionName = dr.GetString(1);
            q.Option1 = dr.GetString(2);
            q.Option2 = dr.GetString(3);
            q.Option3 = dr.GetString(4);
            q.Option4 = dr.GetString(5);
            list_ques.Add(q);
        }
        con.Close();
        return list_ques;
    
    }

    public int GeQuestAns(int qid,int userans)
    {
        SqlCommand com_checkans = new SqlCommand("select count(*) from Questions where QuestionId=@qid and Answer=@userans", con);
        com_checkans.Parameters.AddWithValue("@qid", qid);
        com_checkans.Parameters.AddWithValue("@userans", userans);
        con.Open();
        int count=Convert.ToInt32(com_checkans.ExecuteScalar());
        con.Close();
        return count;
    
    }
}