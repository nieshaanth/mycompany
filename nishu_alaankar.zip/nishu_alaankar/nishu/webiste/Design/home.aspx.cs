﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //lbl_username.Text = Request.QueryString(Login.Text);
        if (!IsPostBack)
        {
            ddb_empcity.Items.Add("selected");
            ddb_empcity.Items.Add("Mumbai");
            ddb_empcity.Items.Add("Delhi");
            ddb_empcity.Items.Add("Salem");

            ddb_empcity.Items.Add("Chennai");
        }



    }
    protected void btn_addemployee_Click(object sender, EventArgs e)
    {
        //DAL
       
        fileupload_empimages.SaveAs(MapPath("~/emp_images/"+txt_empid.Text+".jpg"));
        Response.Write("<script>alert(employee Added Successfully')</script> ");




    }
    protected void btn_reset_Click(object sender, EventArgs e)
    {

    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        
    }
    protected void ddb_empcity_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}