﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class data_caching : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_getprod_Click(object sender, EventArgs e)
    {
        
        if(Cache["product"]==null)
        {
        //dal
        product obj = new product();
        obj.prodId = 1000;
        obj.prodName = "apple";
        obj.prodPrice = 40;

        lbl_pid.Text = obj.prodId.ToString();
        lbl_pname.Text = obj.prodName.ToString();
        lbl_pprice.Text = obj.prodPrice.ToString();
           //absolute expiration in this no sliding--->  Cache.Insert("product",obj,null,DateTime.Now.AddSeconds(20),TimeSpan.Zero);
            //sliding expiration in this wen we slide within 20sec ,time gets increased 
            Cache.Insert("product", obj, null, DateTime.MaxValue, TimeSpan.FromSeconds(20) );
            btn_getprod.Text="Data from DAL";
             }
        else
        {
        product obj=Cache["product"] as product;
            btn_getprod.Text="Data From Cache";
            lbl_pid.Text=obj.prodId.ToString();
            lbl_pname.Text=obj.prodName.ToString();
            lbl_pprice.Text=obj.prodPrice.ToString();
         }
    }
}