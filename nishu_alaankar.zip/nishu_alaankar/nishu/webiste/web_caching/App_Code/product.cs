﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for product
/// </summary>
public class product
{
    public int prodId { get; set; }
    public string prodName { get; set; }
    public int prodPrice { get; set; }
        
}