﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lst_cities.Items.Add("Pune");
            lst_cities.Items.Add("Chennai");
            lst_cities.Items.Add("Mumbai");
        }
    }
    protected void btn_test_Click(object sender, EventArgs e)
    {
        lbl_msg.Text = "hello from asp.net";
    }
    protected void lst_cities_SelectedIndexChanged(object sender, EventArgs e)
    {   
        lbl_cities.Text = lst_cities.Text;
    }
    protected void btn_home_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/home.aspx?orderId=" + txt_orderId.Text);
        
        //  Response.Redirect("http://www.google.com");
      
        // Server.Transfer("http://www.google.com");
        
    }
}