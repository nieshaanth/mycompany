﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;
/// <summary>
/// Summary description for employeeDAL
/// </summary>
public class employeeDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public bool addemployee(employee e,string securityquestion,string answer,string email,string pwd)
    {
        SqlCommand com_addemp = new SqlCommand("insert employeelogin values(@name,@city)", con);
        com_addemp.Parameters.AddWithValue("@name", e.EmployeeName);
        com_addemp.Parameters.AddWithValue("@city", e.EmployeeCity);
        con.Open();
        com_addemp.ExecuteNonQuery();

        SqlCommand com_empid = new SqlCommand("select @@identity", con);
        int id = Convert.ToInt32(com_empid.ExecuteScalar());
        con.Close();
        e.EmployeeId = id;

        MembershipCreateStatus status;
        Membership.CreateUser(e.EmployeeId.ToString(), pwd, email, securityquestion, answer, true,out status);
        if (status == MembershipCreateStatus.Success)
        {
            return true;
        }
        else 
        {
            return false;
        }
        


         



        return true;
    }
}