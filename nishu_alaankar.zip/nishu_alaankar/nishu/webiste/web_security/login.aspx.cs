﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;


public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_login_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(txt_loginid.Text, txt_loginpwd.Text))
        {
            FormsAuthentication.SetAuthCookie(txt_loginid.Text, chk_rememberme.Checked);
            Response.Redirect("~/home.aspx");
        }
        else
            lbl_msg1.Text = "Invalid Username or Password";
                
    }
    protected void btn_addemp_Click(object sender, EventArgs e)
    {
        employee emp = new employee();
        employeeDAL dal = new employeeDAL();
        emp.EmployeeName = txt_empname.Text;
        emp.EmployeeCity = txt_empcity.Text;


        if (dal.addemployee(emp, txt_ques.Text, txt_ans.Text, txt_mail.Text, txt_signuppwd.Text))
        {

            txt_empid.Text = emp.EmployeeId.ToString();
            
            lbl_msg2.Text = ("You are added Successfully and your Employee Id:" + emp.EmployeeId);
        }
        else { 
        lbl_msg2.Text="Error Pls Try Again ";
        }
    }
}