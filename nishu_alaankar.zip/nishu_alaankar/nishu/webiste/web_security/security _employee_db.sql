create table employeelogin
(
EmployeeId int identity(1,1) primary key,
EmployeeName varchar(100),
EmployeeCity varchar(100)

)
sp_help employeelogin

drop table employeelogin

select * from employeelogin

