﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;




public class productsDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public bool addproducts(products_class prod)
    {
        SqlCommand com_addprod = new SqlCommand("insert products values(@name,@desc,@price,@cat,@mod,null)", con);
        com_addprod.Parameters.AddWithValue("@name", prod.ProductName);
        com_addprod.Parameters.AddWithValue("@desc", prod.ProductDescription);
        com_addprod.Parameters.AddWithValue("@price", prod.ProductPrice);
        com_addprod.Parameters.AddWithValue("@cat", prod.ProductCategory);
        com_addprod.Parameters.AddWithValue("@mod", prod.ProductModel);
        con.Open();
        com_addprod.ExecuteNonQuery();

        SqlCommand com_prodid = new SqlCommand("select @@identity", con);
        int prodid = Convert.ToInt32(com_prodid.ExecuteScalar());

        prod.ProductId = prodid;
        prod.ProductImageaddr = "/productimages/" + prodid + ".jpg";

        SqlCommand update_prod = new SqlCommand("update products set productimageaddress=@prodimgaddr where productid=@prodid", con);
        update_prod.Parameters.AddWithValue("@prodimgaddr", prod.ProductImageaddr);
        update_prod.Parameters.AddWithValue("@prodid", prod.ProductId);
        update_prod.ExecuteNonQuery();
        con.Close();
        return true;

    }
    public List<products_class> getproductslist()
    {
        List<products_class> prod_list=new List<products_class>();
        SqlCommand com_getprodlist = new SqlCommand("select * from products", con);
        con.Open();
        SqlDataReader dr = com_getprodlist.ExecuteReader();
        while(dr.Read())
        {
            products_class p = new products_class();
            p.ProductId=dr.GetInt32(0);
            p.ProductName=dr.GetString(1);
            p.ProductDescription=dr.GetString(2);
            p.ProductPrice=dr.GetInt32(3);
            p.ProductCategory=dr.GetString(4);
            p.ProductModel=dr.GetString(5);
            p.ProductImageaddr=dr.GetString(6);
            prod_list.Add(p);
                   
        }
        con.Close();
            return prod_list;      
    }
    public products_class showproducts(int pid)
    {
                SqlCommand com_getproducts = new SqlCommand("select * from products where productid=@id", con);
        com_getproducts.Parameters.AddWithValue("@id", pid);
        con.Open();
        com_getproducts.ExecuteNonQuery();
        SqlDataReader dr = com_getproducts.ExecuteReader();
        products_class p = new products_class();

        while (dr.Read())
        {
            
            p.ProductId = dr.GetInt32(0);
            p.ProductName = dr.GetString(1);
            p.ProductDescription = dr.GetString(2);
            p.ProductPrice = dr.GetInt32(3);
            p.ProductCategory = dr.GetString(4);
            p.ProductModel = dr.GetString(5);
            p.ProductImageaddr = dr.GetString(6);
            

        }
        return p;
        con.Close();
    
    }

   
	
}



//productid, ProductName,ProductDescription,ProductPrice,ProductCategory,ProductModel,productimageaddress