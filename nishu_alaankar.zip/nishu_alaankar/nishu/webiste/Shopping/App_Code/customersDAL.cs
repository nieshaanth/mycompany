﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;



public class customersDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
   

    public bool addcustomer(customers cust,string mail,string pwd,string ques,string ans)
    {
       
            SqlCommand com_addcustomer = new SqlCommand("insert customers values(@name,@mobile) ", con);
            com_addcustomer.Parameters.AddWithValue("@name", cust.CustomerName);
            com_addcustomer.Parameters.AddWithValue("@mobile", cust.CustomerMobile);
            
            con.Open();
            
            com_addcustomer.ExecuteNonQuery();
            SqlCommand com_custid = new SqlCommand("select @@identity", con);
           
         
            int id = Convert.ToInt32(com_custid.ExecuteScalar());
            cust.CustomerId = id;
            con.Close();

            MembershipCreateStatus stat;
            Membership.CreateUser(cust.CustomerId.ToString(), pwd, mail, ques, ans, true, out stat);
            if (stat == MembershipCreateStatus.Success)
            {
              
                return true;
            }
            else
            {
               
                return false;
            }
        
        




    }
	
}