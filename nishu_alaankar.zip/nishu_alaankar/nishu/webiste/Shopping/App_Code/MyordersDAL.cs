﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for MyordersDAL
/// </summary>
public class MyordersDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public bool addtoorder(myorders_class ord)
    {
        
        try
        {
            SqlCommand com_addorder = new SqlCommand("insert orders values(@prodid,@custid,@qty,@price,getdate()) ", con);
           

            com_addorder.Parameters.AddWithValue("@prodid", ord.ProductId);
            com_addorder.Parameters.AddWithValue("@custid", ord.CustomerId);
            com_addorder.Parameters.AddWithValue("@qty", ord.Qty);
            com_addorder.Parameters.AddWithValue("@price", ord.Price);

            
            con.Open();

            SqlTransaction tran = con.BeginTransaction();
            com_addorder.Transaction = tran;
            com_addorder.ExecuteNonQuery();


            SqlCommand com_ordid = new SqlCommand("select @@identity", con);
            com_ordid.Transaction = tran;
            int ord_id = Convert.ToInt32(com_ordid.ExecuteScalar());
            ord.OrderId = ord_id;

            SqlCommand removefromcart = new SqlCommand("delete cart where productid=@pid and customerid=@cid", con);
            removefromcart.Parameters.AddWithValue("@pid", ord.ProductId);
            removefromcart.Parameters.AddWithValue("cid", ord.CustomerId);
            removefromcart.Transaction = tran;
            removefromcart.ExecuteNonQuery();

            tran.Commit();
            return true;
        }
        finally
        {
            if (con.State == System.Data.ConnectionState.Open)
            {
                
                con.Close();

            }


        }
           
        }

    public List<myorders_class> getorders(int cid)
    {
        List<myorders_class> ord_list = new List<myorders_class>();
        SqlCommand com_showorder = new SqlCommand("select * from orders where customerid=@cid", con);
        com_showorder.Parameters.AddWithValue("@cid", cid);
        con.Open();
        SqlDataReader dr = com_showorder.ExecuteReader();
        while (dr.Read())
        {
            myorders_class o = new myorders_class();
            o.OrderId = dr.GetInt32(0);
            o.ProductId = dr.GetInt32(1);
            o.CustomerId = dr.GetInt32(2);
            o.Qty=dr.GetInt32(3);
            o.Price = dr.GetInt32(4);
            o.OrderDate = dr.GetDateTime(5);
            ord_list.Add(o);

        
        }
        con.Close();
        return ord_list;


    
    }

}