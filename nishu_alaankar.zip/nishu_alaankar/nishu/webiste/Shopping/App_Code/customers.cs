﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Customers
/// </summary>
public class customers
{
    public int CustomerId { get; set; }
    public string CustomerName { get; set; }
    public string CustomerMobile { get; set; }

}