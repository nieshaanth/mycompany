﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for mycart
/// </summary>
public class mycart_class
{
    public int ProductId { get; set; }
    public int CustomerId { get; set; }
    public DateTime Addeddate { get; set; }

}