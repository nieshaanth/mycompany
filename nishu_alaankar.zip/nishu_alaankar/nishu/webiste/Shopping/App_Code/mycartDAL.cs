﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for mycartDAL
/// </summary>
public class mycartDAL
{
   
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool addtocart(mycart_class c)
            {
             SqlCommand con_check = new SqlCommand("select count(*) from cart where productid=@pid and customerId=@cid", con);
             con_check.Parameters.AddWithValue("@pid", c.ProductId);
             con_check.Parameters.AddWithValue("@cid", c.CustomerId);
             con.Open();
             int count = Convert.ToInt32(con_check.ExecuteScalar());
             if (count == 0)
             {


                 SqlCommand com_addtocart = new SqlCommand("insert cart values (@cid,@pid,getdate())", con);
                 com_addtocart.Parameters.AddWithValue("@pid", c.ProductId);
                 com_addtocart.Parameters.AddWithValue("@cid", c.CustomerId);

                 com_addtocart.ExecuteNonQuery();
                 con.Close();
                 return true;
             }
             else
             {
                 con.Close();
             return false;
             }
    
    }


        public List<products_class> getcartlist(int cid)
        {
            List<products_class> my_cart_list = new List<products_class>();
            SqlCommand com_getcartlist = new SqlCommand("select productid,productname,productprice from products where productid in(select productid from cart where customerid=@cid)", con);
            com_getcartlist.Parameters.AddWithValue("@cid", cid);
            con.Open();
            SqlDataReader dr=com_getcartlist.ExecuteReader();
            
            while(dr.Read())
            {
                products_class p=new products_class();
                p.ProductId = dr.GetInt32(0);
                p.ProductName=dr.GetString(1);                
                p.ProductPrice=dr.GetInt32(2);
                my_cart_list.Add(p);
            
            }
            con.Close();
            return my_cart_list;

        
        }
}