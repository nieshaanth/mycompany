﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for products
/// </summary>
public class products_class
{
    public int ProductId { get; set; }
    public string ProductName { get; set; }
    public int ProductPrice { get; set; }
    public string ProductDescription { get; set; }
    public string ProductCategory { get; set; }
    public string ProductModel { get; set; }
    public string ProductImageaddr { get; set; }
}
         
