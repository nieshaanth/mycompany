﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for myorders
/// </summary>
public class myorders_class

{
    public int OrderId { get; set; }
    public int ProductId { get; set; }
    public int CustomerId { get; set; }
    public int Qty { get; set; }
    public int Price { get; set; }
    public DateTime OrderDate { get; set; }

}