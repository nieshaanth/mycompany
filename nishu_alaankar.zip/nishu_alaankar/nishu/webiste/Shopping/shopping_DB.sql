create database shopping
use shopping

create table Customers(
CustomerId int identity(1000,1) primary key,
CustomerName varchar(100),
CustomerMobile varchar(10),

)
create table Products(
 ProductId int identity(2000,1) primary key,
 ProductName varchar(100),
 ProductDescription varchar(1000),
 ProductPrice int,
 ProductCategory varchar(100),
 ProductModel varchar(100),
 ProductImageAddress varchar(1000)
)

create table Orders(
OrderId int identity(3000,1) primary key,
ProductId int foreign key references Products(ProductId),
CustomerId int,
Qty int,
Price int,
OrderDate Datetime
)

create table Cart(
CustomerId int,
ProductId int foreign key references Products(ProductId),
Addeddate Datetime
)
drop table customers
drop table cart
drop table orders
SELECT * FROM customers 
select * from products
select *from cart
select *from orders