﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class add_products : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_addprod_Click(object sender, EventArgs e)
    {
        products_class p = new products_class();
        productsDAL dal = new productsDAL();

        p.ProductName = txt_prodname.Text;
        p.ProductDescription = txt_proddesc.Text;
        p.ProductPrice = Convert.ToInt32(txt_prodprice.Text);
        p.ProductCategory = txt_prodcat.Text;
        p.ProductModel = txt_prodmodel.Text;
        dal.addproducts(p);
        img_prod.SaveAs(MapPath(p.ProductImageaddr));
        lbl_msg4.Text = "Your Product is Added Succefully and Your ProductId is" + p.ProductId;

       
    }
}