﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class placeorder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        productsDAL dal = new productsDAL();



        products_class p= dal.showproducts(Convert.ToInt32(Request.QueryString["prod_cid"]));

       
        lbl_prodid.Text = p.ProductId.ToString();
        lbl_custid.Text = Page.User.Identity.Name;

        lbl_price.Text = p.ProductPrice.ToString();
                
    }
    protected void btn_proceed_Click(object sender, EventArgs e)
    {
        myorders_class o = new myorders_class();
        MyordersDAL dal = new MyordersDAL();
        o.ProductId =Convert.ToInt32( lbl_prodid.Text);
        o.CustomerId=Convert.ToInt32(lbl_custid.Text);
        o.Price=Convert.ToInt32( lbl_price.Text);
        o.Qty=Convert.ToInt32(txt_qty.Text);
        dal.addtoorder(o);
        Response.Write("<script>alert('Product added to orders');</script>");
        Response.Redirect("~/myorders.aspx");
       
        

    }
}