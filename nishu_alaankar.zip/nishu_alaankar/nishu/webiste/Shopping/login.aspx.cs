﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_addcustomer_Click(object sender, EventArgs e)
    {
        customers cust = new customers();
        customersDAL dal = new customersDAL();
       
        cust.CustomerName = txt_custname.Text;
        cust.CustomerMobile = txt_custmobile.Text;

        if (dal.addcustomer(cust, txt_mail.Text, txt_custpwd.Text, txt_ques.Text, txt_ans.Text))
        {

            lbl_msg2.Text = "You are Successfully added and Your LoginId is" + cust.CustomerId;
        }
        else 
        {
            lbl_msg2.Text = "Error Occured Pls Try Again Later";

        }
    }
    protected void btn_signup_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(txt_loginid.Text, txt_pwd.Text))
        {
            FormsAuthentication.SetAuthCookie(txt_loginid.Text, chk_rememberme.Checked);
            Response.Redirect("~/customerhome.aspx");
        }
        else {
            lbl_msg1.Text = "Wrong UserId and Password";
        }
    }
}