﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class see_details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int pro_id =Convert.ToInt32( Request.QueryString["pid"]);
        productsDAL dal = new productsDAL();
        products_class p = dal.showproducts(pro_id);
        

        txt_prodid.Text = p.ProductId.ToString();
         txt_prodname.Text=p.ProductName.ToString() ;
         txt_proddesc.Text = p.ProductDescription.ToString();
         txt_prodprice.Text=p.ProductPrice.ToString() ;
         txt_prodcat.Text = p.ProductCategory.ToString();
         txt_prodmodel.Text = p.ProductModel.ToString();
         img_prodimage.ImageUrl = p.ProductImageaddr;
        
        Session["product_id"] = Request.QueryString["pid"];

    }



    protected void btn_addtocart_Click1(object sender, EventArgs e)
    {
        mycart_class c = new mycart_class();
        
        c.CustomerId = Convert.ToInt32(Page.User.Identity.Name);
        c.ProductId = Convert.ToInt32(txt_prodid.Text);
        mycartDAL dal = new mycartDAL();
        if (dal.addtocart(c))
        {
            Response.Redirect("~/mycart.aspx");
        }
        else {
            Response.Write("<script>alert('Already added to Cart');</script>");
        }

        
    }
}