﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class products : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            productsDAL dal = new productsDAL();
            dl_prodlist.DataSource = dal.getproductslist();
            dl_prodlist.DataBind();
        }
    }


    protected void dl_prodlist_ItemCommand(object source, DataListCommandEventArgs e)
    {
        
       int prodid=Convert.ToInt32((e.Item.FindControl("lbl_prodid") as Label).Text);
       Response.Redirect("~/see_details.aspx?pid=" +prodid);
    }
    protected void dl_prodlist_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}