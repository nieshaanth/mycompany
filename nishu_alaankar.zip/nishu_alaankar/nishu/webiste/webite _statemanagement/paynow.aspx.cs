﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class paynow : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lbl_acctno.Text = Session["accountid"].ToString(); ;
        lbl_amt.Text = Session["amount"].ToString();
    }

    protected void btn_paynow_Click(object sender, EventArgs e)
    {
        int accno = Convert.ToInt32(Session["accountid"].ToString());
        int amt = Convert.ToInt32(Session["amount"].ToString());
        Label3.Text = Session.SessionID;
        //DAL
    }
}