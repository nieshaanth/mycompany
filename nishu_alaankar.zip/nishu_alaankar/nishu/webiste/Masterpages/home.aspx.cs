﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class home : System.Web.UI.Page
{
    protected override void OnPreInit(EventArgs e)
    {
        this.MasterPageFile = "~/Master.master";
    }




    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_home_Click(object sender, EventArgs e)
    {
       Label lbl= this.Master.FindControl("lbl_msg") as Label;
        lbl.Text = "Hello From the Content Page";

    //this.master is keyword tht access master page
    }
}