﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;


public class ProductsDAL
{
	
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        
        public bool addproducts(Products p)
         {
         SqlCommand com_addprod=new SqlCommand("insert products values (@name,@price,null)",con);
             com_addprod.Parameters.AddWithValue("@name",p.ProductName);
             com_addprod.Parameters.AddWithValue("@price",p.ProductPrice);
             
             con.Open();
             com_addprod.ExecuteNonQuery();

             SqlCommand com_prodid = new SqlCommand("select @@identity", con);
            int prod_id=Convert.ToInt32(com_prodid.ExecuteScalar());
            p.ProductID = prod_id;
            p.ProductImageAddress = "~/Product_Images/" + prod_id + ".jpg";


            SqlCommand com_update = new SqlCommand("update products set ProductImageAddress=@addr where ProductID=@id", con);
            com_update.Parameters.AddWithValue("@addr", p.ProductImageAddress);
            com_update.Parameters.AddWithValue("@id", p.ProductID);
            com_update.ExecuteNonQuery();
            con.Close();
            return true;


             

         
         
	}


    public List <Products> getproducts()
    {

        List<Products> prod_list = new List<Products>();

    SqlCommand com_add_prodtolist=new SqlCommand("select * from products ",con);
    
        con.Open();
            SqlDataReader dr=com_add_prodtolist.ExecuteReader();
        while(dr.Read())
        {
        Products p=new Products();
        p.ProductID=dr.GetInt32(0);
            p.ProductName=dr.GetString(1);
            p.ProductPrice=dr.GetInt32(2);
            p.ProductImageAddress=dr.GetString(3);
            prod_list.Add(p);
            
        }
        con.Close();
        return prod_list;
    
    }

    public Products getproducts(int pid)
    {

        SqlCommand com_getproducts = new SqlCommand("select * from products where ProductID=@id", con);
        com_getproducts.Parameters.AddWithValue("@id", pid);
        con.Open();
        SqlDataReader dr = com_getproducts.ExecuteReader();
        Products p = new Products();
        while (dr.Read())
        {
           
            p.ProductID = dr.GetInt32(0);
            p.ProductName = dr.GetString(1);
            p.ProductPrice = dr.GetInt32(2);
            p.ProductImageAddress = dr.GetString(3);

        }
        con.Close();
        return p;
             
    
    
    }
}