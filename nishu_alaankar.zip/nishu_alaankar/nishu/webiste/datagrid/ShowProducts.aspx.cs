﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowProducts : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int pid = Convert.ToInt32(Request.QueryString["pid"]);
        ProductsDAL dal = new ProductsDAL();
        Products p= dal.getproducts(pid);
        lbl_pid.Text = p.ProductID.ToString();
        lbl_pname.Text = p.ProductName.ToString();
        lbl_pprice.Text = p.ProductPrice.ToString();
        img_prodimage.ImageUrl = p.ProductImageAddress;
        
    }
}