create database web_emp
use web_emp

create table products
(
ProductID int identity(1000,1) primary key,
ProductName varchar(40),
ProductPrice int,
ProductImageAddress varchar(100)

)
sp_help products

drop table products
select * from products


