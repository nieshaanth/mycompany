﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_addproducts_Click(object sender, EventArgs e)
    {
        Products p = new Products();
        ProductsDAL dal = new ProductsDAL();
        p.ProductName = txt_prodname.Text;
        p.ProductPrice = Convert.ToInt32(txt_prodprice.Text);
        dal.addproducts(p);
        ful_prodimage.SaveAs(MapPath(p.ProductImageAddress));
        txt_prodid.Text = p.ProductID.ToString();
        Response.Write("<script> alert('Product Added Successfully');</script>");
     

            
    }
}