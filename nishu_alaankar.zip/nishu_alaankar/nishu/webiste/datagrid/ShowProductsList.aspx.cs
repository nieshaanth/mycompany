﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowProductsList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_showproducts_Click(object sender, EventArgs e)
    {
        ProductsDAL dal = new ProductsDAL();
        gv_showprodlist.DataSource=dal.getproducts();
        gv_showprodlist.DataBind();
    }
    protected void gv_showprodlist_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label lbl = gv_showprodlist.SelectedRow.FindControl("lbl_pid") as Label;
        int pid = Convert.ToInt32(lbl.Text);
        Response.Redirect("~/ShowProducts.aspx?pid=" + pid);

    }
}