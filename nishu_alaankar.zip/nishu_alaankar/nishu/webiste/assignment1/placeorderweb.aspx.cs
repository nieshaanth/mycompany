﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class placeorder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lst_city.Items.Add("selected");
        lst_city.Items.Add("Chennai");
        lst_city.Items.Add("Pune");
        lst_city.Items.Add("Mumbai");

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void btn_palceorder_Click(object sender, EventArgs e)
    {
        PlaceOrder order = new PlaceOrder();
        order.CustomerID = Convert.ToInt32(txt_customerid.Text);
        if (rb_net.Checked == true)
        {
            order.PaymentType = "Net Banking";
        }
        else if (rb_cash.Checked == true)
        {
            order.PaymentType = "Cash";
        }
        else if (rb_card.Checked == true)
        {
            order.PaymentType = "Card";
        }
        order.ItemID = Convert.ToInt32(txt_itemid.Text);
        order.ItemPrice = Convert.ToInt32(txt_itemprice.Text);
        order.ItemQuantity = Convert.ToInt32(txt_itemqty.Text);
        order.OrderCity = lst_city.SelectedItem.ToString();
        order.Address = txt_addr.Text;
        PlaceOrderDAL dal = new PlaceOrderDAL();
        bool status = dal.PlaceOrder(order);
        if (status)
        {
            lbl_msg.Text = "Order "+ order.OrderID+" Placed Successfully";
        }
        else
        {
            lbl_msg.Text = "Order Not Placed";
        }
    }
}