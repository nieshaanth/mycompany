﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_Login_Click(object sender, EventArgs e)
    {
        Customer cust = new Customer();
        CustomerDAL dal = new CustomerDAL();
        cust.CustomerID = Convert.ToInt32( txt_loginid.Text);
        cust.CustomerPassword =txt_password.Text;
        if (dal.Login(cust))
        {
            Response.Redirect("~/placeorderweb.aspx");
        }
        else
        {
            lbl_msg.Text = "Invalid User";
        }
    }
}