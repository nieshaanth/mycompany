﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
/// <summary>
/// Summary description for CustomerDAL
/// </summary>
public class CustomerDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public bool Login(Customer obj)
    {
        con.Open();
        SqlCommand com_login = new SqlCommand("select count(*) from customers where customerid=@custid and customerpassword=@custpwd", con);
        com_login.Parameters.AddWithValue("@custid", obj.CustomerID);
        com_login.Parameters.AddWithValue("@custpwd", obj.CustomerPassword);
        int count = Convert.ToInt32(com_login.ExecuteScalar());
        con.Close();
        if (count == 1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}