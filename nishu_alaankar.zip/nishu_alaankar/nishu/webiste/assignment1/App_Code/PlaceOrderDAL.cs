﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
/// <summary>
/// Summary description for PlaceOrderDAL
/// </summary>
public class PlaceOrderDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public bool PlaceOrder(PlaceOrder obj)
    {
        con.Open();
        
        SqlCommand com_place_order = new SqlCommand("insert OrdersASP values(@custid,@itemid,@itemprice,@itemqty,@type,@city,@addr)", con);
        com_place_order.Parameters.AddWithValue("@custid", obj.CustomerID);
        com_place_order.Parameters.AddWithValue("@itemid", obj.ItemID);
        com_place_order.Parameters.AddWithValue("@itemprice", obj.ItemPrice);
        com_place_order.Parameters.AddWithValue("@itemqty", obj.ItemQuantity);
        com_place_order.Parameters.AddWithValue("@type", obj.PaymentType);
        
        com_place_order.Parameters.AddWithValue("@city", obj.OrderCity);
        com_place_order.Parameters.AddWithValue("@addr", obj.Address);

        
        int count = Convert.ToInt32(com_place_order.ExecuteNonQuery());

        SqlCommand com_orderid = new SqlCommand("select @@identity ", con);

        int orderid = Convert.ToInt32(com_orderid.ExecuteScalar());
        obj.OrderID = orderid;
       

        
          con.Close();

         
        if (count == 1)
        {
            return true;
        }
        else
        {
            return false;
        }

    }
}