﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public class PlaceOrder
{
	

      public int OrderID { get; set; }
    public int CustomerID { get; set; }
    public int ItemID { get; set; }
    public int ItemPrice { get; set; }
    public int ItemQuantity { get; set; }
    public string PaymentType { get; set; }
    public string OrderCity { get; set; }
    public string Address { get; set; }

	
}