﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    { if(!IsPostBack)
    {
        ddl_type.Items.Add("Select any One");
        ddl_type.Items.Add("Customer");
        ddl_type.Items.Add("Employees");
    }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void btn_login_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(txt_loginid.Text, txt_pwd.Text))
        {
            FormsAuthentication.SetAuthCookie(txt_loginid.Text, chk_rememberme.Checked);
            Response.Redirect("~/customerhome.aspx");

        }
        else {
            lbl_msg1.Text = "invalid username and password";

        }
       
    }
    protected void add_customer_Click(object sender, EventArgs e)
    {
        customer cust = new customer();
        customerDAL dal = new customerDAL();

        cust.CustomerName = txt_custname.Text;
        cust.CustomerDesignation = txt_custdesig.Text;

        if (dal.addcustomer(cust, txt_custmail.Text, txt_custpw.Text, txt_custques.Text, txt_custans.Text))
        {
            lbl_msg2.Text="You are added Successfully and your Customer Id="+cust.CustomerId;
            
        }
        else
        {
        lbl_msg2.Text="Sry Cant process Your request";
        }
    }
}