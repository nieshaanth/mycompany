create database web_bank
use web_bank
create table customer(
CustomerId int identity(1000,1) primary key,
CustomerName varchar(100),
CustomerDesgination varchar(100)
)
select * from customer

