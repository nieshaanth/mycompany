﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for customer
/// </summary>
public class customer
{
    public int CustomerId { get; set; }
    public string CustomerName { get; set; }
    public string CustomerDesignation { get; set; }
}