﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;

/// <summary>
/// Summary description for customerDAL
/// </summary>
public class customerDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public bool addcustomer(customer obj,string mail,string pwd,string ques,string ans)
    {
        SqlCommand com_addcustomer = new SqlCommand("insert customer values (@custname,@custdesig)", con);
        com_addcustomer.Parameters.AddWithValue("@custname", obj.CustomerName);
        com_addcustomer.Parameters.AddWithValue("@custdesig", obj.CustomerDesignation);
        con.Open();
        com_addcustomer.ExecuteNonQuery();
        SqlCommand com_custid=new SqlCommand("select @@identity ",con);
        int custid=Convert.ToInt32(com_custid.ExecuteScalar());
        con.Close();
        obj.CustomerId=custid;

        MembershipCreateStatus stat;
        Membership.CreateUser(obj.CustomerId.ToString(),pwd, mail, ques, ans, true, out stat);
        if (stat == MembershipCreateStatus.Success)
        {
            return true;
        }
        else 
        {
            return false;
        }

       
            }
}