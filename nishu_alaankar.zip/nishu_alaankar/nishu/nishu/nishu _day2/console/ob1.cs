﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ob1
{
    class Program
    {
        static void Main(string[] args)
        {


            student st = new student(1000, "abcd");
            Console.WriteLine(st.Pstud_id);
            Console.WriteLine(st.Pstud_name);
            st.Pstud_name = "abcdefgh";
                Console.WriteLine(st.Pstud_name+"\n enter the marks");
            

                st.Pstud_marks =Convert.ToInt32( Console.ReadLine());
                Console.WriteLine(st.Pstud_marks);
            Console.WriteLine(st.Pstud_status);

            test2 obj = new test2();
            obj.cust_name = "nishanth";
            Console.WriteLine(obj.cust_name);
            
            Console.ReadLine();


            









            /*Console.WriteLine("enter the Customer id");
            
            int customerId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ënter the customer name");
            string customerName = Console.ReadLine();

            Console.WriteLine("Enter The customer age");
            int customerAge = Convert.ToInt32(Console.ReadLine());

            customer obj = new customer(customerId, customerName, customerAge);


            

          

           string details= obj.GetCustomerDetails();

           obj.getdata("abc", 200);
           obj.getdata("xyz");
           obj.getdata(i: 300, str: "pqrs");
            
           Console.WriteLine(details);
           Console.ReadLine();
            */

        }
    }
}
