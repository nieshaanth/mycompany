﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ob1
{
    class customer
    {
        public void getdata(string str, int i = 100)
        {
            Console.WriteLine(str + " " + i);
        }



         private int customerId;//4
         private string customerName;//2bytes for customer name to be stored in heap. spl case .class type instance.so there is no predefined space.now its null.
       
        private int customerAge;//4


        public customer(int customerID,string customerName,int customerAge) 
        {
            this.customerId=customerId;
            this.customerName=customerName;
            this.customerAge=customerAge;

            Console.WriteLine("customer object created");
        }

        

        public string GetCustomerDetails()
        {
             
        return customerId+" "+customerName;}
        }
    
}
