﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ob1
{
     partial class test
    {
        public string userid;
        public void getdata() { 
        }
    }
}
