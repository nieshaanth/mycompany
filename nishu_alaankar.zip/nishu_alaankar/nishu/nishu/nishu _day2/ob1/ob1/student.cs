﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ob1
{
    class student
    {
        int stud_id;
        public int Pstud_id
        {
            get
            {
                return stud_id;
            }



        }
       
        string stud_name;
        public string Pstud_name
        {
            get
            {
                return stud_name;
            }
            set
            {
                stud_name = value;
            }
        }
        int stud_marks;
        public int Pstud_marks 
        {
            get {
                return stud_marks;
            }
            set{
                if ((value > 100) || (value < 0))
                {
                    stud_marks = 0;
                }
                else
                {
                    stud_marks = value;
                            if (stud_marks > 50)
                                 {
                                 stud_status = true;
                                }
                       
                    
                    else
                    {
                        stud_status = false; 
                    }
                }
            

            }
        }
        


        bool stud_status;
    public bool Pstud_status
    {
            get{
                return stud_status;
    }
} 
        public student(int stud_id, string stud_name) {
            this.stud_id = stud_id;
            this.stud_name = stud_name;
        }
        public student(int stud_id)
        {this.stud_id=stud_id;
            //db code
            this.stud_name="abcd";
            this.stud_marks=60;
        }

        }

        }
    

