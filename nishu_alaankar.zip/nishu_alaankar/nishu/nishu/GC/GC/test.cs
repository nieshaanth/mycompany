﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GC
{
    class test
    {

        public test()
        {
            Console.WriteLine("object created");

        }
        ~test()
        {
            Console.WriteLine("object destroyed");
        }
    }
}
