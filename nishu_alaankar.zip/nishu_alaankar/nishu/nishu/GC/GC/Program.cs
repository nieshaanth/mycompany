﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GC
{
    class Program
    {
        static void Main(string[] args)




        {


            using (xyz obj = new xyz()) 
            { 
            }
            System.GC.Collect();

                   
            int i = 0;
            int marks=0;
            while (i < 5)
            {
                test obj = new test();
                if (i == 3)
                {
                    System.GC.SuppressFinalize(obj);
                   
                }
                obj = null;


               
                marks = 5000;//objects
                i++;
               
            }
            Console.WriteLine(marks);
            
            System.GC.Collect();
            Console.ReadLine();
        }
    }
}
