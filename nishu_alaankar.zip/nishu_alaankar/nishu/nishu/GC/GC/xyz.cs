﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GC
{
    class xyz:IDisposable
    {


        public void Dispose()
        {
            Console.WriteLine("dispose");
        }
    }
}
