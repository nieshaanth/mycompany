﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstract_account
{
    class current :account
    {

        public current(int accountId, string customerName, int accountBal)
            : base(accountId, customerName, accountBal)
        { 
        }



        public override bool withdraw(int amt)
        {
            if ((accountBal - amt) > 0)//current account can hav 0 balance
            {
                accountBal = accountBal - amt;
                return true;
            }
            else 
            {
                return false;
            }
        }

        public override bool deposit(int amt)
        {
            accountBal = accountBal + amt;//no interest for current account
                return true;
        }
    }
}
