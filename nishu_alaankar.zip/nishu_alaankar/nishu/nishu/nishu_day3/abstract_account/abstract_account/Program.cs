﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstract_account
{
    class Program
    {
        static void Main(string[] args)
        {
            int id, bal=0;
            string name,type;
            Console.WriteLine("enter the account id");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the name");
            name = Console.ReadLine();
            Console.WriteLine("enter the type of account");
            type = Console.ReadLine();
            

            account obj;//we cant create like concrete defn like account obj=new acoount();
            if(type=="saving")
                {
                    obj = new saving(id, name, bal);
  
                }
            else  
            {
                obj = new current(id, name, bal);

            }

            

            obj.deposit(2500);
                bal=obj.getBalance();
            Console.WriteLine("balance:"+bal);

            obj.withdraw(2000);
                bal=obj.getBalance();
            Console.WriteLine("balance:"+bal);

            obj.stopPayment();
             Console.ReadLine();

            


        }
    }
}
