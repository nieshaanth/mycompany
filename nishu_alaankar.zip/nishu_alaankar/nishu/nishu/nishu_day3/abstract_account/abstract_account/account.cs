﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstract_account
{///going to be used as an template(abstract class)
    abstract class account
    {

   protected     int accountId;
   protected string customerName;
   protected int accountBal;
   public account(int accountId, string customerName, int accountBal)
   {
       this.accountId = accountId;
       this.accountBal = accountBal;
       this.customerName = customerName;
       Console.WriteLine("account got created");
      

   }
        //funvtions which are common put in abstarct class with body
   public void stopPayment()
   {
       Console.WriteLine("stop payment");

   }
   public int getBalance()
   {
       return accountBal;

   }
   public void getStatetment()
   {
       Console.WriteLine("bank statement");
   }
   public abstract bool withdraw(int amt);////these fun will defined in derived class because they willl diffrent case depending on the type of account like saving ,current.etc
   public abstract bool deposit(int amt);
        





    }


}
