﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace overriding
{
    class employee_contract :employee
    {
        public employee_contract(int empId, string empName, int basicsalary)
            : base(empId, empName, basicsalary)
        { 
        
        }
        public override int getSalary()
        {

            return basicsSalary + 1000;

        }

        public  override string getWork()
        {
            return "working as a contract worker";

        }


    }
}
