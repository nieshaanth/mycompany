﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace overriding
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("enter the empolyee id");
            int empId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the employee name");
            string empName = Console.ReadLine();
            Console.WriteLine("enter the basic salary");
            int basic = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("enter the type of employee");
            string type = Console.ReadLine();
            employee obj;

            if (type == "employee")
            {
                obj = new employee(empId, empName, basic);
            }
            else if (type == "intern")
            { 
            obj=new employee_intern(empId,empName,basic);
            }
            else
            {
                obj = new employee_contract(empId, empName, basic);
            }
            
            Console.WriteLine(obj.getDetails());
            Console.WriteLine(obj.getWork());
            Console.WriteLine(obj.getSalary());
            Console.ReadLine();



        }
    }
}
