﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace overriding
{
    class employee
    {
        

        string empName; 
        int empID;
       protected int basicsSalary;
        public employee(int empId, String empName, int basicsalary)
        {
            this.empID = empId;
            this.empName = empName;
            this.basicsSalary = basicsSalary;
        }
        public virtual string  getWork()
        {
            return "working as a programmer";
        }
        public string getDetails()
        {
            return empID + " " + empName;

        }

        public virtual int getSalary() 
        {
            int tax = 1200;
            return basicsSalary + 2500 - tax;
        }



           }
}
