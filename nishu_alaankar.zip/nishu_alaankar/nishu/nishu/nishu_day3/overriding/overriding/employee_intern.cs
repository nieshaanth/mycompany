﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace overriding
{
    class employee_intern:employee_contract
    {
        public employee_intern(int empId, string empName,int basicsalary) : base(empId,empName,basicsalary)

        { 
        }
        public override int getSalary()
        {
            return 15000;
        }
        public override string getWork()
        {
            return "working as a intern";

        }
    }
}
