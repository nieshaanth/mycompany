﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oop2
{
    class customer
    {
        protected int customerId;
        string customerName;
        public customer(int customerId, string customerName) {
            this.customerId = customerId;
            this.customerName = customerName;


        }
        public customer(int customerId)
        {
            this.customerId = customerId;
            this.customerName = "abcd";//database
        }

        public string getdetails()
        {
            return customerId + " " + customerName;
        }
    }
}
