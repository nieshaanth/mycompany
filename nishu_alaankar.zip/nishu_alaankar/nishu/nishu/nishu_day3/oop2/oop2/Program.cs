﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oop2
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("enter the customer id");
            int cusid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the customer name");
            string cusname = Console.ReadLine();

            Console.WriteLine("enter the type of customer");
            string type = Console.ReadLine();
            if (type == "customer")
            {


                customer obj = new customer(cusid, cusname);

                string details = obj.getdetails();
            }
            else {
                Console.WriteLine("enter the address");
                string cusaddr = Console.ReadLine();
                customer_spl obj = new customer_spl(cusid, cusname, cusaddr, 10000);

              //  Object  obj2 = new customer_spl(cusid, cusname, cusaddr, 10000);

/*
                string details=obj.getdetails();
                Console.WriteLine(details);
                Console.WriteLine(obj.getdetails());
                string addr=obj.getaddr();
                Console.WriteLine(addr);
                Console.ReadLine();
 */

            }
                

            //derived class

            


            
        }
    }
}
