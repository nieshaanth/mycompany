﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oop2
{
    class customer_spl : customer
    {

        string customerAddr;
        int creditLimit;
        bool paymentStatus;




        public customer_spl(int customerId,string customerName, string customerAddr,int creditLimit ):base(customerId,customerName)
        {
            this.customerAddr = customerAddr;
            this.creditLimit = creditLimit;
        }
        public string getaddr()
        {
            
            return customerAddr;
        }

    
    
    
    
    
    }
}
