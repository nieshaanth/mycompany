﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class assembly
    {
        public int getsal(int salary,int days)
        {
            return salary * days;
        }
    }
}
