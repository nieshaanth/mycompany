﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace classemployee
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           

        }

        private void btn_gen_Click(object sender, EventArgs e)
        {
            int sal = Convert.ToInt32(txt_sal.Text);
            int day = Convert.ToInt32(txt_day.Text);
            ClassLibrary1.assembly obj = new ClassLibrary1.assembly();
            int rslt = obj.getsal(sal, day);
            MessageBox.Show(rslt.ToString());

        }
    }
}
