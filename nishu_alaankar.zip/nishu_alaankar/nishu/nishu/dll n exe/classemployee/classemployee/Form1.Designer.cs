﻿namespace classemployee
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_sal = new System.Windows.Forms.Label();
            this.lbl_days = new System.Windows.Forms.Label();
            this.txt_sal = new System.Windows.Forms.TextBox();
            this.txt_day = new System.Windows.Forms.TextBox();
            this.btn_gen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_sal
            // 
            this.lbl_sal.AutoSize = true;
            this.lbl_sal.Location = new System.Drawing.Point(43, 37);
            this.lbl_sal.Name = "lbl_sal";
            this.lbl_sal.Size = new System.Drawing.Size(72, 13);
            this.lbl_sal.TabIndex = 0;
            this.lbl_sal.Text = "salary per day";
            // 
            // lbl_days
            // 
            this.lbl_days.AutoSize = true;
            this.lbl_days.Location = new System.Drawing.Point(46, 91);
            this.lbl_days.Name = "lbl_days";
            this.lbl_days.Size = new System.Drawing.Size(32, 13);
            this.lbl_days.TabIndex = 1;
            this.lbl_days.Text = "days.";
            // 
            // txt_sal
            // 
            this.txt_sal.Location = new System.Drawing.Point(144, 37);
            this.txt_sal.Name = "txt_sal";
            this.txt_sal.Size = new System.Drawing.Size(100, 20);
            this.txt_sal.TabIndex = 2;
            // 
            // txt_day
            // 
            this.txt_day.Location = new System.Drawing.Point(144, 91);
            this.txt_day.Name = "txt_day";
            this.txt_day.Size = new System.Drawing.Size(100, 20);
            this.txt_day.TabIndex = 3;
            // 
            // btn_gen
            // 
            this.btn_gen.Location = new System.Drawing.Point(118, 153);
            this.btn_gen.Name = "btn_gen";
            this.btn_gen.Size = new System.Drawing.Size(75, 23);
            this.btn_gen.TabIndex = 4;
            this.btn_gen.Text = "generate";
            this.btn_gen.UseVisualStyleBackColor = true;
            this.btn_gen.Click += new System.EventHandler(this.btn_gen_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btn_gen);
            this.Controls.Add(this.txt_day);
            this.Controls.Add(this.txt_sal);
            this.Controls.Add(this.lbl_days);
            this.Controls.Add(this.lbl_sal);
            this.Name = "Form1";
            this.Text = "tt";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_sal;
        private System.Windows.Forms.Label lbl_days;
        private System.Windows.Forms.TextBox txt_sal;
        private System.Windows.Forms.TextBox txt_day;
        private System.Windows.Forms.Button btn_gen;
    }
}

