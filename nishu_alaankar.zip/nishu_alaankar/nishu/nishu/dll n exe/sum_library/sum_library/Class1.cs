﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sum_library
{
    public class Sum 
    {
   public int getSum(int num1,int num2)
    {
    int tot=num1+num2+1000;
    return tot;
    }


    }
}
