﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_delegate
{
    class event_testing
    {
        //publisher 
        public delegate void delvt(string msg);//publisher delgate defn
        public event delvt evt; //event is created by frame work addr of evt is given to delvt

        public void fire()
        {
            if (evt != null)
            {
                evt("hello from event");
                
            }

        } 


        //subcriber

        public void call(string str)
        {
            Console.WriteLine("call:\n" + str);
        }
        public void bind()
        {
            delvt obj = new delvt(call);
            this.evt += new delvt(call);
        }






    }
}
