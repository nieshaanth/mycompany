﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_delegate
{
    class test
    {

        public delegate void del(string str);
        public void getdata(string msg)//delegate func
        {
            Console.WriteLine("get data function" + msg);

        
        }
        public void setdata(string str)
        {
            Console.WriteLine("setdata" +str);

        }

        public void bind()
        {
            del obj = new del(getdata);//addr of getdata is stored in obj
            obj += new del(setdata);
            
            obj -= new del(getdata);

            obj += delegate(string str)//anonymous func
            {
                Console.WriteLine(str);
            };

            obj("hello");

            
            
            
            obj("next");

            


        
        }

    }
}
