﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_delegate
{
    class Program
    {
        static void Main(string[] args)
        {
            event_testing obj = new event_testing();
            obj.bind();
            obj.fire();
            Console.ReadLine();




            /*
            test t = new test();
            t.bind();
            Console.ReadLine();
        */
        }
    }
}
