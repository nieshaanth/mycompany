﻿namespace win_first_application
{
    partial class frm_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_cities = new System.Windows.Forms.ListBox();
            this.btn_getcity = new System.Windows.Forms.Button();
            this.cmb_itemids = new System.Windows.Forms.ComboBox();
            this.chk_oderstatus = new System.Windows.Forms.CheckBox();
            this.rdb_male = new System.Windows.Forms.RadioButton();
            this.rdb_femlae = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lst_cities
            // 
            this.lst_cities.FormattingEnabled = true;
            this.lst_cities.Location = new System.Drawing.Point(39, 30);
            this.lst_cities.Name = "lst_cities";
            this.lst_cities.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lst_cities.Size = new System.Drawing.Size(120, 95);
            this.lst_cities.TabIndex = 0;
            this.lst_cities.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // btn_getcity
            // 
            this.btn_getcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_getcity.ForeColor = System.Drawing.Color.Crimson;
            this.btn_getcity.Location = new System.Drawing.Point(315, 30);
            this.btn_getcity.Name = "btn_getcity";
            this.btn_getcity.Size = new System.Drawing.Size(129, 49);
            this.btn_getcity.TabIndex = 1;
            this.btn_getcity.Text = "GetCity";
            this.btn_getcity.UseVisualStyleBackColor = true;
            this.btn_getcity.Click += new System.EventHandler(this.btn_getcity_Click);
            // 
            // cmb_itemids
            // 
            this.cmb_itemids.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_itemids.FormattingEnabled = true;
            this.cmb_itemids.Location = new System.Drawing.Point(372, 187);
            this.cmb_itemids.Name = "cmb_itemids";
            this.cmb_itemids.Size = new System.Drawing.Size(121, 32);
            this.cmb_itemids.TabIndex = 2;
            this.cmb_itemids.SelectedIndexChanged += new System.EventHandler(this.cmb_itemids_SelectedIndexChanged);
            // 
            // chk_oderstatus
            // 
            this.chk_oderstatus.AutoSize = true;
            this.chk_oderstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_oderstatus.Location = new System.Drawing.Point(118, 187);
            this.chk_oderstatus.Name = "chk_oderstatus";
            this.chk_oderstatus.Size = new System.Drawing.Size(136, 28);
            this.chk_oderstatus.TabIndex = 6;
            this.chk_oderstatus.Text = "is completed";
            this.chk_oderstatus.UseVisualStyleBackColor = true;
            this.chk_oderstatus.CheckedChanged += new System.EventHandler(this.chk_oderstatus_CheckedChanged);
            // 
            // rdb_male
            // 
            this.rdb_male.AutoSize = true;
            this.rdb_male.Location = new System.Drawing.Point(389, 263);
            this.rdb_male.Name = "rdb_male";
            this.rdb_male.Size = new System.Drawing.Size(47, 17);
            this.rdb_male.TabIndex = 7;
            this.rdb_male.TabStop = true;
            this.rdb_male.Tag = "";
            this.rdb_male.Text = "male";
            this.rdb_male.UseVisualStyleBackColor = true;
            this.rdb_male.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rdb_femlae
            // 
            this.rdb_femlae.AutoSize = true;
            this.rdb_femlae.Location = new System.Drawing.Point(389, 287);
            this.rdb_femlae.Name = "rdb_femlae";
            this.rdb_femlae.Size = new System.Drawing.Size(56, 17);
            this.rdb_femlae.TabIndex = 8;
            this.rdb_femlae.TabStop = true;
            this.rdb_femlae.Text = "female";
            this.rdb_femlae.UseVisualStyleBackColor = true;
            // 
            // frm_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 400);
            this.Controls.Add(this.rdb_femlae);
            this.Controls.Add(this.rdb_male);
            this.Controls.Add(this.chk_oderstatus);
            this.Controls.Add(this.cmb_itemids);
            this.Controls.Add(this.btn_getcity);
            this.Controls.Add(this.lst_cities);
            this.Name = "frm_Home";
            this.Text = "frm_Home";
            this.Load += new System.EventHandler(this.frm_Home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_cities;
        private System.Windows.Forms.Button btn_getcity;
        private System.Windows.Forms.ComboBox cmb_itemids;
        private System.Windows.Forms.CheckBox chk_oderstatus;
        private System.Windows.Forms.RadioButton rdb_male;
        private System.Windows.Forms.RadioButton rdb_femlae;
    }
}