﻿namespace win_first_application
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_loginId = new System.Windows.Forms.Button();
            this.lbl_loginId = new System.Windows.Forms.Label();
            this.lbl_pw = new System.Windows.Forms.Label();
            this.txt_loginId = new System.Windows.Forms.TextBox();
            this.txt_pw = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_loginId
            // 
            this.btn_loginId.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_loginId.ForeColor = System.Drawing.Color.Teal;
            this.btn_loginId.Location = new System.Drawing.Point(114, 201);
            this.btn_loginId.Name = "btn_loginId";
            this.btn_loginId.Size = new System.Drawing.Size(298, 39);
            this.btn_loginId.TabIndex = 0;
            this.btn_loginId.Text = "Login";
            this.btn_loginId.UseVisualStyleBackColor = true;
            this.btn_loginId.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl_loginId
            // 
            this.lbl_loginId.AutoSize = true;
            this.lbl_loginId.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_loginId.Location = new System.Drawing.Point(109, 60);
            this.lbl_loginId.Name = "lbl_loginId";
            this.lbl_loginId.Size = new System.Drawing.Size(110, 25);
            this.lbl_loginId.TabIndex = 1;
            this.lbl_loginId.Text = "Login Id :";
            this.lbl_loginId.Click += new System.EventHandler(this.lbl_loginId_Click);
            // 
            // lbl_pw
            // 
            this.lbl_pw.AutoSize = true;
            this.lbl_pw.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pw.Location = new System.Drawing.Point(109, 107);
            this.lbl_pw.Name = "lbl_pw";
            this.lbl_pw.Size = new System.Drawing.Size(128, 25);
            this.lbl_pw.TabIndex = 2;
            this.lbl_pw.Text = "Password :";
            this.lbl_pw.Click += new System.EventHandler(this.lbl_pw_Click);
            // 
            // txt_loginId
            // 
            this.txt_loginId.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_loginId.Location = new System.Drawing.Point(262, 60);
            this.txt_loginId.Name = "txt_loginId";
            this.txt_loginId.Size = new System.Drawing.Size(298, 31);
            this.txt_loginId.TabIndex = 3;
            this.txt_loginId.TextChanged += new System.EventHandler(this.txt_loginId_TextChanged);
            // 
            // txt_pw
            // 
            this.txt_pw.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pw.Location = new System.Drawing.Point(262, 107);
            this.txt_pw.Name = "txt_pw";
            this.txt_pw.PasswordChar = '*';
            this.txt_pw.Size = new System.Drawing.Size(298, 31);
            this.txt_pw.TabIndex = 4;
            this.txt_pw.TextChanged += new System.EventHandler(this.txt_pw_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(595, 482);
            this.Controls.Add(this.txt_pw);
            this.Controls.Add(this.txt_loginId);
            this.Controls.Add(this.lbl_pw);
            this.Controls.Add(this.lbl_loginId);
            this.Controls.Add(this.btn_loginId);
            this.Name = "Form1";
            this.Text = "string";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_loginId;
        private System.Windows.Forms.Label lbl_loginId;
        private System.Windows.Forms.Label lbl_pw;
        private System.Windows.Forms.TextBox txt_loginId;
        private System.Windows.Forms.TextBox txt_pw;
    }
}

