﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace win_first_application
{
    public partial class frm_Home : Form
    {
        public frm_Home()
        {
            InitializeComponent();
        }

        private void frm_Home_Load(object sender, EventArgs e)
        {

            lst_cities.Items.Add("chennai");
            lst_cities.Items.Add("mumbai");
            lst_cities.Items.Add("goa");

            cmb_itemids.Items.Add("1001");
            cmb_itemids.Items.Add("1002");
            cmb_itemids.Items.Add("1003");

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_getcity_Click(object sender, EventArgs e)
        {
            if (rdb_male.Checked)
            {
                MessageBox.Show("male");
            }
            else if (rdb_femlae.Checked)
            { MessageBox.Show("female");
            }
            else
            {
                MessageBox.Show(" select gender");
            }
      

            if (chk_oderstatus.Checked)
            {
                MessageBox.Show("order is finished");

            }
            else {
                MessageBox.Show("order is pending");

            }


            if (lst_cities.Text == "")
            {
                MessageBox.Show("select a city");
            }
            else
            {
            string city = lst_cities.Text;
            MessageBox.Show(city);

        
            }
        }
            
        private void chk_oderstatus_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cmb_itemids_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
