﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace win_first_application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userid = txt_loginId.Text;//text is a property tht give value from user
            string password = txt_pw.Text;

            if (userid == "")
            {
                MessageBox.Show("enter user id");

            }
            else if (password == "")
            {
                MessageBox.Show("enter the password");
            }
            else
            {


                if ((userid == "user123") && (password == "pass123"))
                {
                    MessageBox.Show("you have logged in successfullly");
                    frm_Home obj = new frm_Home();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("Accsess denied \n Invalid user");
                }

            }
        }

        private void lbl_pw_Click(object sender, EventArgs e)
        {

        }

        private void lbl_loginId_Click(object sender, EventArgs e)
        {

        }

        private void txt_loginId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_pw_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
}
