﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//to add collections add collections
using System.Collections;


namespace Console_generics
{
    class Program
    {
        static void Main(string[] args)
        {

            Dictionary<int, string> names = new Dictionary<int, string>();
            names.Add(10001, "abcd");
            names.Add(10002,"efgh"); //cant use "for each" loop because there is no indexing
            string str=names[10001];
            Console.WriteLine(str);



            /*


            List<int> marks = new List<int>();//list means generic array and noo need boxing and unboxing.list s a generic collection napi
           
            marks.Add(50);
            marks.Add(100);
            marks.Add(10100);
          
         
      
            foreach (int i in marks)
            {      Console.WriteLine(i+"    "+marks.Count);
            }
            Console.WriteLine(g);


            /*
            ArrayList list = new ArrayList();
            list.Add("abc");//0 index
            list.Add(500);//1 index
            list.Add(true);//2 index
            int i = 100;//boxing
            list.Add(i);


            int x = Convert.ToInt32(list[1]);///[] means indexer and its not a array
            string str = list[0].ToString();//unboxing 

            Console.WriteLine(x + "   " + str);
            
            
            
            
            
            
            
            
            /*
            test obj = new test();
            int i = obj.getData<int>(Convert.ToInt32(Console.ReadLine()));
            string str = obj.getData<string>("hello");
            Console.WriteLine(i   + "\n "+str  );
              */
            Console.ReadLine();
            
        }
    }
}
