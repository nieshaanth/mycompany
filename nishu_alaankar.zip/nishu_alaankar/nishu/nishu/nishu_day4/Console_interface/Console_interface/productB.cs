﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class productB :Itransport ,Itesting
    {

        public string productId;
        public string productName;
        public string customerName;
        public string customerAddr;

        public void Run()
        { 
        }

        public void stop()
        { 
        }

        public string getcustomerdetails()
        {
            return  customerName +" "+ customerAddr;

        }


        public string getcustomeraddr()
        {
            return customerName + " " + customerAddr;
        }

        bool Itesting.run()
        {
            this.Run();
                return true;
        }

        public bool halt()
        {
            this.stop();
            return true;
        }
    }
}
