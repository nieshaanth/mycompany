﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class productA: Itransport , Itesting
    {
        public string pId;
        public string pName;
        public string cAddr;
        public string cName;

        public void play()
        { 
        }

        public void stop()

        { 
        }

        public string getproductdetails()
        {
            return pId + " " + pName ;
        }

        public string getcustomeraddr()
        {
            return pId + " " + pName ; //u can also call getprductdetails() here
            this.getproductdetails();
            
        }

        public bool run()
        {
            this.play();
            return true;
        }

        bool Itesting.halt()
        {
            this.stop();
            return true;

        }

    }
}
