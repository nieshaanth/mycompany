﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class testing
    {


        public bool receive_product_for_testing(Itesting obj)
            
        {
            bool status1 = obj.run();
            bool status2 = obj.halt();

            if ((status1 == true) && (status2 == true))
            {
                return true;

            }
            else 
            {
                return false;
            }

        }

        
    }
}
