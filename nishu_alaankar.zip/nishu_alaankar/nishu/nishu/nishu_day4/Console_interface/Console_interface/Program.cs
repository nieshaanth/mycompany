﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class Program
    {
        static void Main(string[] args)
        {

            productA a = new productA();
            a.pId = "121";
            a.pName = "mobile";
            a.cName = "abcd";
            a.cAddr = "chennai";

            productB b = new productB();
            b.productName = "laptop";
            b.productId = "456";
            b.customerName = "nishanth";
            b.customerAddr = "tambaram";



            testing test = new testing();
            bool statusA= test.receive_product_for_testing(a);
            bool statusB = test.receive_product_for_testing(b);

             


            transport t = new transport();

            if (statusA == true)
            {

                t.Recieve_product(a);

            }
            else {
                Console.WriteLine( "the product A is not wroking");
            }


            if (statusB == true)
            {


                t.Recieve_product(b);
            }
            else 
            {
                Console.WriteLine("the prdct B is not working");

            }

                Console.ReadLine();

            



        }
    }
}
