﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    interface Itesting
    {
        bool run();
            bool halt();
    }
}
