﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_string
{
    class Program
    {
        static void Main(string[] args)
        {

            int[][] jaggedarray = new int[3][];

            jaggedarray[0] = new int[2];
            jaggedarray[1] = new int[3];
            jaggedarray[2] = new int[4];


            jaggedarray[0][0] = 55;
            jaggedarray[0][1] = 56;

            jaggedarray[1][0] = 65;
            jaggedarray[1][1] = 66;
            jaggedarray[1][2]=67;

            jaggedarray[2][0] = 75;
            jaggedarray[2][1] = 76;
            jaggedarray[2][2] = 77; 
            jaggedarray[2][3] = 78;

            foreach (int[] array in jaggedarray)
            {
                foreach (int x in array)
                {
                    Console.WriteLine(x);
                }
                Console.WriteLine("");
            }

            
            
            
            /*
           
            
            string name = "abc";
            char[] charray={'a','b','c'};

            object obj =new string(charray);
            if(name==obj)
            {
            Console.WriteLine("==true");
            }
            else{
            Console.WriteLine("==false");


            }

            if(name.Equals(obj))
            {
                Console.WriteLine("==true1");
            }
            else
            {
            Console.WriteLine("==false1");
            }


            /*
            string str = "hello";
            string str1="äbc";
            str = str1;

            str1 = "xyz";
            str1 = "abc";
            

            Console.WriteLine(str);



           

            foreach (char ch in str)
            {
                Console.WriteLine(ch);
                
            }*/
            Console.ReadLine();

        }

    }
}
