﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
 

namespace Win_exceptionHandling
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void btn_getvalue_Click(object sender, EventArgs e)
        {
            

            
            try
            {


                test obj = new test();
                int i = Convert.ToInt32(txt_value.Text);
                MessageBox.Show(i.ToString());
                
                /*
                // obj = new object();
                //obj = null;
                //obj.ToString();



                i = Convert.ToInt32(txt_value.Text);
                MessageBox.Show(i.ToString());*/
            }

            catch (NullReferenceException exp)
            {
                MessageBox.Show(exp.Message);
            }

            catch (Exception exp)
            {
                MessageBox.Show("Enter the right values");
            }

            finally 
            {
                MessageBox.Show("Finally");

            }
            MessageBox.Show("Äfter finally");
            

           
        }
    }
}
