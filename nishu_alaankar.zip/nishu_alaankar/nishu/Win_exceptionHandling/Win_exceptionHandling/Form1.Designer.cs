﻿namespace Win_exceptionHandling
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_value = new System.Windows.Forms.TextBox();
            this.btn_getvalue = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_value
            // 
            this.txt_value.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_value.Location = new System.Drawing.Point(347, 97);
            this.txt_value.Name = "txt_value";
            this.txt_value.Size = new System.Drawing.Size(171, 26);
            this.txt_value.TabIndex = 0;
            // 
            // btn_getvalue
            // 
            this.btn_getvalue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_getvalue.Location = new System.Drawing.Point(117, 73);
            this.btn_getvalue.Name = "btn_getvalue";
            this.btn_getvalue.Size = new System.Drawing.Size(146, 75);
            this.btn_getvalue.TabIndex = 1;
            this.btn_getvalue.Text = "Get Value";
            this.btn_getvalue.UseVisualStyleBackColor = true;
            this.btn_getvalue.Click += new System.EventHandler(this.btn_getvalue_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 449);
            this.Controls.Add(this.btn_getvalue);
            this.Controls.Add(this.txt_value);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_value;
        private System.Windows.Forms.Button btn_getvalue;
    }
}

