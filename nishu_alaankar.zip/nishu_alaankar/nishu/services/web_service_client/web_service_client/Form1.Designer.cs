﻿namespace web_service_client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_days = new System.Windows.Forms.TextBox();
            this.txt_salary = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_getsalary = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "No of Days";
            // 
            // txt_days
            // 
            this.txt_days.Location = new System.Drawing.Point(129, 32);
            this.txt_days.Name = "txt_days";
            this.txt_days.Size = new System.Drawing.Size(100, 20);
            this.txt_days.TabIndex = 1;
            // 
            // txt_salary
            // 
            this.txt_salary.Location = new System.Drawing.Point(141, 104);
            this.txt_salary.Name = "txt_salary";
            this.txt_salary.Size = new System.Drawing.Size(100, 20);
            this.txt_salary.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Per Day Salary";
            // 
            // btn_getsalary
            // 
            this.btn_getsalary.Location = new System.Drawing.Point(84, 177);
            this.btn_getsalary.Name = "btn_getsalary";
            this.btn_getsalary.Size = new System.Drawing.Size(75, 23);
            this.btn_getsalary.TabIndex = 4;
            this.btn_getsalary.Text = "Get Salary";
            this.btn_getsalary.UseVisualStyleBackColor = true;
            this.btn_getsalary.Click += new System.EventHandler(this.btn_getsalary_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btn_getsalary);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_salary);
            this.Controls.Add(this.txt_days);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_days;
        private System.Windows.Forms.TextBox txt_salary;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_getsalary;
    }
}

