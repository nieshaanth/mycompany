﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace web_service_client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_getsalary_Click(object sender, EventArgs e)
        {
            int days = Convert.ToInt32(txt_days.Text);
            int per_day_sal = Convert.ToInt32(txt_salary.Text);
            localhost.WebService proxy = new localhost.WebService();

            int total = proxy.getsalary(days, per_day_sal);
            //this proxy will send soap msg -> sent to the service
            MessageBox.Show("Salary is" + total);
            

        }
    }
}
