 create table BankTrans
 (
 transid int identity (1000,1) primary key,
 accountno varchar(30),
 amount int,
 transdate datetime
  
 )
 
 create table tickets
 (
 
 ticketno int identity(2000,1) primary key, 
 moviename varchar(30),
 moviedate datetime,
 timing varchar(20),
 No_of_tickets int,
 ticketdate datetime,
 transid int foreign key references Banktrans(transid),
 )
  
  select * from BankTrans
  select * from tickets
  drop table tickets
  
