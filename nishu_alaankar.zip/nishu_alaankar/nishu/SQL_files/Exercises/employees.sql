create database InautixJan2017ADO

use InautixJan2017ADO

create table customers
(
customerid int identity(1000,1) primary key,
customername varchar(30),
customercity varchar(30),
customerage int,
customerdoj datetime),
customerpassword varchar(30)
)

select * from employees

create table cities
(
cityid int identity(1,1),
cityname varchar(50)
)

insert cities values('Salem')
insert cities values('Chennai')
insert cities values('Karur')
insert cities values('Trichy')


select * from cities