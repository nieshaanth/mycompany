create database InautixJan2017

use InautixJan2017

create table customers(customerid int, customername varchar(20), customercity varchar(30), customerage int)

sp_help customers

insert customers values(1002, 'Nishanth', 'Chennai', 21)
insert customers values(1003, 'Alankar', null, 30)
insert customers(customername, customerid) values('Vijay',1004)

select * from customers
select * from customers

update customers set customercity='Chennai'
select * from customers
update customers set customercity='Salem' where customerid=1001
select * from customers
update customers set customercity='Calcutta', customerage=30 where customerid=1003
select * from customers
delete customers where customerid=1003
select * from customers
drop table customers

alter table customers add customercontactno varchar(10)
select * from customers
alter table customers drop column customercontactno
select * from customers
alter table customers alter column customername varchar(50)
sp_help customers
sp_rename 'customers','customersinfo'

select * from customersinfo
sp_rename 'customersinfo','customers'
select * from customers
sp_rename 'customers.customercity','customeraddress' 
select * from customers

select * into customernew from customers
select * from customernew
select * from customers
select customerid,customername into customername from customers
select * from customername

create table employees
(
employeeid int,
employeename varchar(30),
employeecity varchar(30),
employeedoj datetime,
employeesalary int
)
sp_help employees

insert employees values(1001,'Ganesh','Salem','01/18/2017',15000)
insert employees values(1002,'Nishanth','Chennai','08/02/2010',50000)
insert employees values(1003,'Sundhar','Hyderabad','01/02/2017',25000)
insert employees values(1004,'Jeyaprakash','Trichy','12/10/2005',27000)
insert employees values(1005,'Dinesh','Namakkal','02/01/2014',50000)

select * from employees

select employeeid,'Name : ' + employeename from employees
delete employees

select * from employees where employeecity = 'chennai' and employeesalary > 25000

select * from employees where employeecity in ('Chennai','Trichy')

select employeeid,employeename + ',' +employeecity as 'employee details' from employees

select * from employees where employeesalary between 18000 and 30000
select * from employees order by employeecity asc, employeesalary desc

select top 1 * from employees order by employeesalary desc

select len(employeename) from employees

select len('Hello')
select substring('hello',1,4)
select ltrim('      hello')
select rtrim('hello          ')
select lower('HELLO')
select upper('hello')
select left('hello',2)
select right('hello',2)
select isnumeric('1225')
select ceiling(24.01)
select floor(25.99)
select round(253.2595,2
select customerid , IsNull(customeraddress,'NA') as 'City' from customers
select upper(customeraddress) from customers

select sum(employeesalary) as totalsalary from employees
select sum(employeesalary) as 'Total Salary' from employees where employeecity='Chennai'
select max(employeesalary) from employees
select min(employeesalary) from employees
select count(*) from employees
select getdate()

insert employees values(1005,'Dinesh','Namakkal',getdate(),50000)
select * from employees

select dateadd(mm,20,getdate()) 
select employeeid, employeename, datediff(mm, employeedoj, getdate()) as 'Years experience' from employees
select employeeid, employeename, datepart(mm, employeedoj) from employees

select convert(varchar(20),employeeid) + ',' + employeename from employees
select cast(employeeid as varchar(20)) + ',' + employeename from employees

select convert(varchar(20),getdate(),6)
select convert(varchar(20),getdate(),1)
select convert(varchar(20),getdate(),2)
select convert(varchar(20),getdate(),3)
select convert(varchar(20),getdate(),4)
select convert(varchar(20),getdate(),9)
select convert(varchar(20),getdate(),7)
select convert(varchar(20),getdate(),0)

select employeesalary, employeecity, count(*) as 'No. of employees',sum(employeesalary) from employees where employeesalary > 15000 group by employeecity, employeesalary having count(*) > 1

select * from employees
select employeeid, employeesalary, row_number() over(order by employeesalary desc) from employees
select employeeid, employeesalary, rank() over (order by employeesalary desc) from employees
select employeeid, employeesalary,dense_rank() over(order by employeesalary desc) from employees

create database Emp_db

create table Employee(Employeeid int,EmployeeFirstname varchar(30),EmployeeLastname varchar(30), Employeecity varchar(20), Employeeage int, EmployeeSalary int)
select * from Employees
alter table Employee add EmployeeDept varchar(20)
alter table Employee add EmployeeDoj Date

insert Employee values(1001,'Ganesh','Sundarrajan','Salem',21,25000,'Developer','01/18/2017')
insert Employee values(1002,'Nishanth','Jayabalu','Chennai',22,50000,'Manager','05/20/2010')
insert Employee values(1003,'Jeyaprakash','Palanisamy','Trichy',20,15000,'Developer','01/10/2015')
insert Employee values(1004,'Pabeethra','Muthukumarasamy','Thirunelvi',50,5000,'BPO','09/18/1995')
insert Employee values(1005,'Meenakshi','Nehru','Madurai',27,35000,'Developer','07/15/2013')
insert Employee values(1006,'Vignesh','Periyasamy','Theni',23,45000,'HR','03/20/2016')
insert Employee values(1007,'Dinesh','Kumar','Namakkal',19,27000,'Developer','02/21/2017')
insert Employee values(1008,'Adhavan','Keerthi','Namakkal',25,20000,'HR','04/01/2014')
insert Employee values(1009,'Alankar','Sooraj','Calcutta',30,100000,'Tutor','03/19/2010')
insert Employee values(1010,'Sreenath','Rajagopalan','Chennai',40,150000,'CEO','10/18/2007')

alter table Employee alter column EmployeeDoj varchar(30) 
delete Employee
select * from Employee

select * from Employee where Employeecity='Chennai'
select * from Employee where Employeesalary between 25000 and 50000
select Employeefirstname+' '+ Employeelastname as 'Full Name', Employeeid, Employeecity from Employee
select sum(Employeesalary) as TotalSalary from Employee
select count(*) as TotalEmployees from Employee
select * from Employee where datename(mm,EmployeeDoj)='January'
select * from Employee where datediff(yy,EmployeeDoj, getdate())>5
select EmployeeDept, count(*) as 'No. of Employees' from Employee group by EmployeeDept
select Employeecity, count(*) as 'No. of Employees' from Employee group by Employeecity
update Employee set Employeecity='Pune' where Employeecity='Chennai'
select EmployeeDept, sum(Employeesalary) as 'Sum of Salary' from Employee group by EmployeeDept having sum(Employeesalary)>50000
delete Employee where Employeeid='1010'
delete Employee where Employeeid='1009'
select * from Employee