create table orders(orderid int identity(1000,1), CustomerName varchar(30), itemname varchar(30), itemqty int, itemprice int)
insert orders values('John','Mobile',1,10000)
insert orders values('Peter','Laptop',1,40000)
select * from orders
insert orders values('Smith','Mobile',1,20000)
select * from orders
select @@identity 
select * from orders
insert orders values('parker','Computer',1,75000)
select * from orders
delete orders

create table items(itemid int identity(1000,1) primary key, itemname varchar(30) not null, itemprice int check(itemprice > 0))
insert items values('LG Mobile',15000)
insert items values('LAVA Mobile',40000)
select * from items
create table customerinfo(customerid int identity(1,1) primary key, customername varchar(30) not null, customercity varchar(30) not null)
insert customerinfo values('Nishanth','Chennai')
insert customerinfo values('Ganesh','Salem')
select * from customerinfo
create table invoices(invoiceid int identity(10000,1) primary key, customerid int foreign key references customerinfo(customerid), invoicedate datetime, invoiceaddress varchar(50) not null, customercontactno varchar(15) not null, paymenttype varchar(30) check(paymenttype in('Cash','Card','NetBanking')),Transid int unique)
create table invoicedetails(invoiceid int foreign key references invoices(invoiceid), itemid int foreign key references items(itemid),itemqty int check(itemqty>0),primary key(invoiceid,itemid))
insert invoices values(1,getdate(),'Chennai','2525552','card',2541)
select * from invoices
insert invoicedetails values(10000,1000,2)
select * from invoicedetails
insert invoicedetails values(10000,1001,3)
select * from invoicedetails

select * from items
select * from customerinfo
select * from invoices
select * from invoicedetails

insert customerinfo values('Jeyaprakash','Trichy')
insert customerinfo values('Ranjith','Vellore')
insert customerinfo values('Senthil','Karur')

insert invoices values(2,getdate(),'Salem','8940322355','cash',2545)
insert invoices values(3,getdate(),'Trichy','25232131','card',2542)
insert invoices values(2,getdate(),'Salem','252454552','cash',2547)
insert invoices values(3,getdate(),'Trichy','252552454','card',2549)

insert invoicedetails values(10003,1000,5)
insert invoicedetails values(10004,1001,10)
insert invoicedetails values(10002,1001,9)
insert invoicedetails values(10001,1000,7)

select * from customerinfo where customerid in (select distinct customerid from invoices)
insert items values('iPhone',55000)
select * from items
select * from items where itemid not in (select distinct itemid from invoicedetails)
select * from customerinfo where customerid in (select customerid from invoices group by customerid having count(*) > 1)
select top 1 * from items where itemid in (select itemid from invoicedetails group by itemid having max(itemqty)>avg(itemqty))

select * from items where itemid in
(
select top 1 with ties itemid from invoicedetails where invoiceid in
(
select invoiceid from invoices where datepart(yy,invoicedate) = datepart(yy,getdate())
)
group by itemid 
order by sum(itemqty) desc
)
select * from items
select * from invoices
select * from invoicedetails
select * from customerinfo


select * from employee e1 where e1.employeesalary > (
select avg(e2.employeesalary) from employee e2 where e2.employeecity = e1.employeecity
)

-------------------------------------------Joins-------------------------------------------------

select * from customerinfo
select * from invoices
select * from invoicedetails

select customerinfo.customerid, customerinfo.customername, invoices.invoiceid, invoices.invoicedate 
from customerinfo join invoices on customerinfo.customerid = invoices.customerid


select customerinfo.customerid, customerinfo.customername, invoices.invoiceid, invoices.invoicedate, invoicedetails.itemid, items.itemprice
from customerinfo join invoices on customerinfo.customerid = invoices.customerid 
join invoicedetails on invoices.invoiceid = invoicedetails.invoiceid
join items on invoicedetails.itemid = items.itemid

select invoices.invoiceid, invoices.invoicedate,

select customerinfo.customerid, customerinfo.customername, count(invoices.invoiceid) 
from customerinfo join invoices on customerinfo.customerid = invoices.customerid
group by customerinfo.customerid,customerinfo.customername


select customerid, count(*) as NoofInvoices from invoices group by customerid

select customerinfo.customerid, customerinfo.customername,invoices.invoiceid, invoices.invoicedate 
from customerinfo full join invoices on customerinfo.customerid = invoices.customerid

select * from customerinfo self join customerinfo

create table employeesinfo(employeeid int identity(1000,1) primary key, employeename varchar(30), employeecity varchar(30), managerid int)
insert employeesinfo values('Ganesh','Chennai',null)
insert employeesinfo values('Nishanth','Chennai',1000)
insert employeesinfo values('Sundhar','Chennai',1000)
insert employeesinfo values('Vikki','Chennai',1001)

select * from employeesinfo
select e.employeeid,e.employeename,isnull(e.managerid,0),isnull(m.employeename,'NA') from employeesinfo e left join employeesinfo m
on e.managerid = m.employeeid

Select * from invoices

select * into invoices_copy from invoices

select * from
(
select * from invoices
union
select * from invoices_copy
) 
as x
order by x.invoiceid desc


select * from(
select customerinfo.customerid, customerinfo.customername, invoices.invoiceid, invoices.invoicedate, invoicedetails.itemid, items.itemprice
from customerinfo join invoices on customerinfo.customerid = invoices.customerid 
join invoicedetails on invoices.invoiceid = invoicedetails.invoiceid
join items on invoicedetails.itemid = items.itemid ) as x
order by x.itemprice desc




------------------------------------TSQL----------------------------------

declare @count int
set @count = 0
while(@count < 10)
begin
select @count
set @count = @count +1;
end
if(@count > 5)
begin
select 'True'
end
else
begin 
select 'False'
end


create procedure sp_getcustomersinvoice(@customerid int)
as
begin
select customerinfo.customerid, customerinfo.customername, invoices.invoiceid, invoices.invoicedate, invoicedetails.itemid, items.itemprice
from customerinfo join invoices on customerinfo.customerid = invoices.customerid 
join invoicedetails on invoices.invoiceid = invoicedetails.invoiceid
join items on invoicedetails.itemid = items.itemid
where customerinfo.customerid = @customerid
end

exec sp_getcustomersinvoice 1

create table customerdetails(customerid int identity(1000,1) primary key, customername varchar(30), customerage int, customerpassword varchar(30))
insert customerdetails values('Ganesh',21,'pass@123')
insert customerdetails values('Dinesh',25,'admin@123')
insert customerdetails values('Nishanth',29,'pass@1234')
insert customerdetails values('Vikki',27,'admin@1234')

select * from customerdetails

create table customerlogin(customerid int, logindt datetime)


alter procedure sp_customerlogin(@custid int, @custpwd varchar(30))
as
begin
declare @count int
select @count = count(*) from customerdetails 
where customerid=@custid and customerpassword=@custpwd
if(@count > 0)
begin
insert customerlogin values(@custid,getdate())
end
return @count
end

declare @retvalue int
exec @retvalue=sp_customerlogin 1003, 'admin@1234'
select @retvalue as status

select * from customerlogin order by logindt desc

create procedure sp_getcustdetails(@custid int, @custname varchar(30) output, @custage int output)
as
begin
select @custname = Customername, @custage = customerage from customerdetails 
where customerid=@custid
end

declare @customername varchar(30)
declare @customerage int
exec sp_getcustdetails 1000,@customername output,@customerage output
select @customername as CustomerName,@customerage as CustomerAge








select invoicedetails.invoiceid,accountinfo.accountbalance, count(transactioninfo.accountid)
from accountinfo join transactioninfo
on
accountinfo.accountid = transactioninfo.accountid
group by transactioninfo.accountid


select * from customerdetails

alter trigger trg_customerdetails_insert
on customerdetails
for insert --action
as 
begin
select 'Trigger Fired'
end

insert customerdetails values('Alankar','25','pass@123')

select * from customerdetails


create table stock
(
itemid int,
stockqty int
)
insert stock values(1000,100)
insert stock values(1001,100)
select * from stock

create table ordersinfo
(
orderid int identity(1,1) primary key,
customername varchar(30),
itemid int,
itemqty int
)


alter trigger trg_orders_stock_update
on ordersinfo
for insert
as 
begin
declare @itemid int
declare @itemqty int
select @itemid = itemid, @itemqty = itemqty from inserted
update stock set stockqty = stockqty - @itemqty where itemid=@itemid
DECLARE @stockqty int
select @stockqty = stockqty from stock where itemid = @itemid
if(@stockqty<0)
begin
select 'Order Cancelled'
rollback tran
end
end

insert ordersinfo values('A',1001,125)
select * from stock

sp_helptrigger ordersinfo