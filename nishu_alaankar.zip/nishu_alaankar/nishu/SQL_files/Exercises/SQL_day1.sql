create database inautixjan2017 
use inautixjan2017



create table customers
(
customerId int,
customerName varchar(20),
customerCity varchar(30),
customerAge int
)


sp_help customers  --shows the structure of customer table


insert customers values(0007,'nishanth','chennai',21)

insert customers values(0008,'nisha','pune',20)

insert customers values(1003,'abcd',null,25)



select * from customers

update customers set customercity='chennai'
where customerid=1003

select  * from customers


update customers set customercity='chennai',customerage=25 where customerid=1003

select *from customers


delete customers where customerid=10001

//drop table customers //deleting the complete table

alter table customers add customerphone varchar(20))

select *from customers


alter table customers drop column customerphone

alter table customers alter column customername varchar(50)

select *from customers

sp_help Customers

sp_rename'customers','customerinfo' -- 'currentname','newname'
sp_rename 'customerinfo','customers'-- 




sp_rename 'customers.customercity','customers.customeraddr'

select *from customers
 
select * into customersNew from customers --copy a table

select * from customersnew

select * from customers


----------------------------------------------------------------------------
create table employee
(
employeeId int,
employeeName varchar(30),
employeeCity varchar(20),
employeeDOJ varchar(20),
employeesalary int
)

insert employee values(1,'nishanth','chennai','10/16/1996',400000)
insert employee values(2,'ganesh','salem','01/18/2017',200000)
insert employee values(3,'abcd','pune','05/01/2017',101)
insert employee values(4,'xyz','delhi','02/10/1996',1500)
insert employee values(5,'pqrs','trichy' ,'10/10/1996',1500)


select * from employee

select employeeid,'Name:' +employeename,'Ciy:'+employeecity from employee

select employeeid,employeename+','+employeecity as 'employee details' from employee


select * from employee where employeecity='chennai' and employeesalary>20000

select * from employee where employeecity in('chennai','pune')

select *from employee where employeesalary between 10000 and 30000

select *from employee order by employeecity desc,employeesalary asc

select *from employee order by employeesalary desc

select top 1 with ties * from employee order by employeesalary


-----------------------------------------------------------------------------

select len('hello')



select len(employeename) from employee

select count(len(employeename)) from employee


select substring('helllo',A,3)

select ltrim('   hello')
select rtrim('hello    ')

select lower ('HELLO')
select upper('hello')

select sum(employeesalary) as 'total salary' from employee
select sum(employeesalary ) as 'total chennai salary' from employee where employeecity='chennai'
 


select avg(employeesalary) as 'total salary' from employee

select min(employeesalary) as 'total salary' from employee

select max(employeesalary) as 'total salary' from employee

select count(*)from employee

select employeecity,count(*)as totalcount,sum(employeesalary)as 'details' from employee group by employeecity

--where and having class

select employeecity,count(*),sum(employeesalary)as 'details' from employee group by employeecity having count(*)>1 --having clause 

select employeecity,count(*),sum(employeesalary)as 'details' from employee where employeesalary>10000 group by employeecity having count(*)>1 --having clause 


select *from employee
------------------------------------------------------------------------------


create table orders
(

orderId int identity(1,1),
customername varchar(20),
itemname varchar(30),
itemQty int,
itemprice int)

insert orders values('john','mobile',1,40000)
                                                                                        
delete orders where orderId=3

select * from orders


select @@identity

-----------------------------------------------------------------------------








 
