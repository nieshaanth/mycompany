create database Emp_db1
use Emp_db1

create table Employees
(empid int,
empname varchar(30),
emplname varchar(30),
empcity varchar(30),
empage int,
empsalary int)

alter  table employees add empdept varchar(30) ,empDoj Datetime 
alter table employees add emppw varchar(30)
alter table employees drop column emppw 
select * from Employees
drop TABLE employees
insert employees values(100,'nishanth','jaybalu','chennai',22,100,'developer','01/01/2016','4567')

insert employees values(200,'ganesh','K.S','chennai',25,200000,'coder','02/02/2017','1234')

insert Employees values(300,'thomas','edison','america',60,30000,'scientist','03/03/2017','1234')

insert employees values(400,'modi','narendra','world tour',6000,10000000,'prime minsiter','04/04/2016','1234')

insert Employees values(500,'mini','mom','tamilnadu',60,101,'servant','10/10/2016')


insert employees values(600,'panner','mitcher','tamilnadu',50,50000,'servant','1/12/2016')

insert employees values(700,'rahul','gandhi','india',40,1000,'kibitzer','1/01/2016')

insert employees values(800,'soniya','gandhi','france',70,2000,'patient','3/2/2014')

insert employees values(900,'pabithra','MK','madurai',20,2500,'coder','1/09/2017')

insert employees values (1000,'srilekha','S','australia',30,60000,'singer','7/2/2013')






select empfname+' , '+emplname as employeeName from employees where empcity='chennai'

select empfname+' '+emplname as employeeName from employees where empsalary between 25000 and 50000

select empfname +','+emplname as empFullname from employees

select sum(empsalary) from employees

select count(*) as totalemployees from employees

select * from employees where datename(MM,empdoj)='jan'

select * from employees where datediff(yy,empdoj,getdate())>5

select empdept,count(*) from employees group by empdept

select empcity,count(*) from employees group by empcity

update  Employees set empcity='pune' where empcity='chennai'

select empdept,sum(empsalary) as sum_of_salary from employees   group by empdept having sum(empsalary)>50000

select * from Employees
delete Employees where empid=500;
delete Employees where empid=800;
delete Employees where empid=400;


EXEC sp_RENAME 'employees.empfname' , 'empname', 'COLUMN'





alter procedure proc_login(@empid int, @emppw varchar(30),@empname varchar(30) output)
as
begin
declare @count int
select @count=COUNT(*) from employees
where empid=@empid and emppw=@emppw
if(@count>0) 
begin select @empname=empname from employees
where empid=@empid
end 
return @count
end



SELECT * FROM EMPLOYEES
 