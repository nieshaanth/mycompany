create database WPF
use WPF
create table products(
ProductId int identity (1000,1) primary key,
ProductName varchar(50),
ProductPrice int


)
sp_help products


