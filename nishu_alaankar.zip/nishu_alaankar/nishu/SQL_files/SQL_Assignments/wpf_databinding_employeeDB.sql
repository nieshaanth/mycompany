create database wpf_employee_databinding
use wpf_employee_databinding
create table employees
(
employeeId int identity(1,1) primary key,
employeeName varchar(30),
employeeDept varchar(30),
employeeDesignation varchar(30),
employeeExperience int,
employeePassword varchar(40),
managerId int

)



sp_help employees

create table leaverequests(
leaveId int identity(1000,1) primary key,
employeeId int foreign key references employees(employeeId),
requestedDate Datetime,
leaveDate Datetime,
totalDays int,
leavetype varchar(30),
reason varchar(100),
leaveStatus varchar(50),
managerId int 


)
drop  employees
sp_help leaverequests

insert employees values('Nishanth','dotnet','trainee',1,'1234',null)
select * from employees