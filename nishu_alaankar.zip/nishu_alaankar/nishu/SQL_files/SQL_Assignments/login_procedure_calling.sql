select * from employees


create table employee
(

)
alter procedure proc_login(@empid int, @emppw varchar(30),@empname varchar(30) output)
as
begin
declare @count int
select @count=COUNT(*) from employees
where empid=@empid and emppw=@emppw
if(@count>0) 
begin select @empname=empname from employees
where empid=@empid
end 
return @count
end