create database wpf_db
use wpf_db

create table products
(
productId int identity(1000,1) primary key,
productName varchar(30),
productPrice int
)
insert products values ('Lenova Mobile',20000)
insert products values('sony mobiles',30000)
insert products values('apple iphone',40000)
insert products  values('oneplus 3' , 50000)
insert products values('virtue' , 100000)

create table orders(
orderId int identity(2000,1) primary key,
customerId int ,
orderDate Datetime,
orderAddress varchar(30),
productId int foreign key references  products(productId),
productPrice int,
productQty int

)
sp_help products
sp_help orders


create table customers
(
customerId int identity(3000,1) primary key,
customerName varchar(30),
customerEmail varchar(50),
customerPassword varchar(30)
)


insert customers values('nishanth','nieshaanth@gmail.com','1234')
insert customers values('jayabalu' ,'jayabalu@gmail.com','4567')
insert customers values('1','1@gmail.com','1234');
insert customers values('2','1@gmail.com','2');

	select * from customers
	select * from products
	select * from orders
	
	create table OrdersASP 
( 
OrderID int identity(10000,1) primary key, 
CustomerID int foreign key references customers(customerId), 
ItemID int, 
ItemPrice int, 
ItemQuantity int, 
PaymentType varchar(30), 
OrderCity varchar(20), 
DeliveryAddress varchar(30) 
)

drop table OrdersASP
select * from OrdersASP