create table transdata (
transid int identity(1000,1),
accid int,
transtype varchar(10),
amt int ,
transdate datetime
)
drop table transdata
insert transdata values(2,'C',2000,getdate())
insert transdata values(2,'C',2000,getdate())
insert transdata values(2,'D',500,getdate())
insert transdata values(2,'D',500,getdate())

select * from transdata


select accid,[C] as 'credit',[D] as 'debit' from (select accid,transtype,amt from transdata) as T pivot (count(transtype) for transtype in([C],[D])) as pvt
select accid,[C] as 'credit',[D] as 'debit' from (select accid,transtype,amt from transdata) as T pivot (count(transtype) for transtype in([C],[D])) as pvt

declare @count int =0
while(@count<70000)
begin
insert transdata values(201,'C',2000,getdate())
insert transdata values(202,'D',2000,getdate())
set @count=@count+1
end

select * from transdata where transid=65000

create clustered index idx
on transdata(transid)


delete transdata where transid=100


create nonclustered index id1
on transdata(transtype)



