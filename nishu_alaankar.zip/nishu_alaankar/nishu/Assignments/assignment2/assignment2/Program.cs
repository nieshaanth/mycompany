﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace assignment2
{
    class Program
    {
        static void Main(string[] args)

        {   
            int flag=1,id,qty,price,tot=0;
            string name;
                 
            while(flag==1)
            {
           Console.WriteLine("1.order 2.exit");
            int n=Convert.ToInt32( Console.ReadLine());
            switch(n)
              {
                 case 1: 

                    order b=new order();
                            
                    Console.WriteLine("enter ur name");
                    name=Console.ReadLine();

                    Console.WriteLine("enter the item id");
                    id=Convert.ToInt32( Console.ReadLine());

                    Console.WriteLine("ënter the qty");
                        qty=Convert.ToInt32( Console.ReadLine());

                    Console.WriteLine("enter the price");
                    price=Convert.ToInt32( Console.ReadLine());

                    order o = new order(name, id, qty, price);

                            Console.WriteLine("\n\norder details");
                            Console.WriteLine("Name                  "+o.pcustomerName);
                            Console.WriteLine("item id               "+ o.pitemId);
                            Console.WriteLine("qty                    "+o.pitemQty);
                            Console.WriteLine("price of each qty        "+o.pitemPrice);
                            Console.WriteLine("total                  "+o.orderValue);

                            Console.WriteLine("your order id  0000" + b.porder);
                            tot = b.px;


                           
                    break;
                case 2: flag++;
                    break;
                                 }
               
            
                    
            }
            Console.WriteLine("total order is" + tot);
            Console.ReadLine();
        }
    }
}


