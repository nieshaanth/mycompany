﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace assignment2
{
    class order
    {
         int  orderId = 0;
        static int x;
       int itemId, itemQty, itemPrice;
        string customerName;

        public order()
        {

              x++;
             orderId=x;
        }

        public int px {
            get { return x; }
        }

        public int porder
        {
        get
        {
        return orderId;
             }
        }





        public string pcustomerName
        {
            get
            {
                return customerName;
            }
            set
            {
                customerName = value;

            }
        }
        public int pitemId
        {
            get
            {
                return itemId;
            }
            set
            {
                itemId = value;
            }
        }
        public int pitemQty
        {
            get
            {
                return itemQty;
            }
            set
            {
                itemQty = value;
            }
        }

        public int pitemPrice
        {
            get
            {
                return itemPrice;
            }
            set
            {
                itemPrice = value;
            }
        }

        public int orderValue
        {
            get
            {
                return itemQty * itemPrice;
            }
        }

        public order(string customerName, int itemId, int itemQty, int itemPrice)
        {
            this.customerName = customerName;
            this.itemId = itemId;
            this.itemQty = itemQty;
            this.itemPrice = itemPrice;
        }
    }



}
