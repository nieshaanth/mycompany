﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Company_empolyees
{
    class company
    {


        











        int companyId;
        string companyName;
        List<employee> emplist = new List<employee>();

        List<employee> emplist_leaveRequest = new List<employee>();

 
                    public  company(int companyId,string companyName)
                    {
                    this.companyId=companyId;
                    this.companyName=companyName;
        
                    }

        //delegate_handler

                    public void notify(int Empid, string msg)
                    {
                        Console.WriteLine("company:" + Empid + " " + msg);
                        emplist_leaveRequest.Add(searchEmployee(Empid));


                    } //event handler for subscriber


                    public void employee_leave_request_approval()
                    {
                        foreach (employee e in emplist_leaveRequest)
                        {
                            e.leav_approval();
                        }
                        emplist_leaveRequest.Clear();
                        
                    }





        public void addEmployee(employee emp)
        {
        emplist.Add(emp);

        emp.evt_leave_request += new employee.delleave(notify);
        }


        public bool removeEmployee(int empId)
        {
            foreach (employee e in emplist)
            {
                if (e.PempId == empId)
                {
                    emplist.Remove(e);
                    return true;
                }
            }
                return false;
            
        }


        public employee searchEmployee(int empId)
        {
            foreach (employee e in emplist)
            {
                if (e.PempId == empId)
                {
                    return e; 
                }
            }
            return null;
        }



        public void showEmployee()
        {
            foreach (employee e in emplist)
            {
                Console.WriteLine(e.ToString());
            }
        }











    }
}
