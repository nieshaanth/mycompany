﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Company_empolyees
{
    class Program
    {
        static void Main(string[] args)
        {


            company comp = new company(1001, "inautix");

            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1.add 2.remove 3.find 4.show 5.exit 6.company approval");
                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                { 
                    case 1:
                        Console.WriteLine("enter the empId");
                        int empId = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter the emp name");
                        string empName = Console.ReadLine();
                        Console.WriteLine("enter the empId city");
                        string empCity = Console.ReadLine();
                        employee emp = new employee(empId, empName, empCity);
                        comp.addEmployee(emp);
                        Console.WriteLine("employee added successfully");
                        break;

                    case 2:
                        Console.WriteLine("enter the emp id for remove");
                        int rem_empId = Convert.ToInt32(Console.ReadLine());
                        bool status = comp.removeEmployee(rem_empId);
                        if (status == true)
                        {
                            Console.WriteLine("employee is removed");

                        }
                        else {
                            Console.WriteLine("employee is not removed");
                        }
                        break;

                    case 3:
                        Console.WriteLine("enter the emp id to found");
                        int find_eid = Convert.ToInt32(Console.ReadLine());
                        employee emp1 = comp.searchEmployee(find_eid);
                        if (emp1 == null)
                        {
                            Console.WriteLine("empolyeeId is not found");

                        }
                        else {

                            Console.WriteLine("enter 1.show 2.leave request");

                            int opt = Convert.ToInt32(Console.ReadLine());
                            if (opt == 1)
                            {
                                Console.WriteLine(emp1.ToString());


                            }
                            else 
                            {
                                Console.WriteLine("ënter the reason");
                                string reason = Console.ReadLine();
                                emp1.requestleave( reason);

                            }
                                
                            Console.WriteLine("employeeId is found");

                        }
                        break;
                    case 4 :
                        comp.showEmployee();
                        break;
                    case 5:
                        flag = false;
                        break;



                    case 6:
                        comp.employee_leave_request_approval();
                        break;


                        



                }
       
            }

               
        }
    }
}
