﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Company_empolyees
{
    class employee
    {
        public delegate void delleave(int empId, string msg);
        public event delleave evt_leave_request;

        public void requestleave(String msg)
        {
            if (evt_leave_request != null)
            {
                evt_leave_request(empId, msg);
            }
        
        }

        bool leav_status = false;
        public bool Pstatus 
        {
            get
            {
                return leav_status;
            }
        }

        public void leav_approval()
        {
            leav_status = true;

        }
















        string empName;
        string empCity;
        int empId;
        //emp id is unique for everyoneso get property is being used
        public int PempId
        {

                get {
                    return empId;
                     }
        
        }



        public employee(int empId, string empName, string empCity)
        {
            this.empId = empId;
            this.empName = empName;
            this.empCity = empCity;

        }

        public override string ToString()
        {
            {
                return empId + " " + empName + " " + empCity+" "+leav_status ;
            }
        }









    }
}
