﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shopping_abstract
{
    class order_overseas : order
    {
        public order_overseas(int orderId, string custName, int itemQty, int itemPrice)
            : base(orderId, custName, itemQty, itemPrice)
        { 
        }


        public override int getAmount(int itemQty, int itemPrice)
        {
            return itemPrice * itemQty + 1000;
        }
    }

}
