﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shopping_abstract
{
    class orderoffshore:order
    {

        public orderoffshore(int orderId, string custName, int itemQty, int itemPrice)
            : base(orderId, custName, itemQty, itemPrice)
        { }

        public override int getAmount(int itemQty, int itemPrice)
        {
            return itemPrice * itemQty;
        }
    }
}
