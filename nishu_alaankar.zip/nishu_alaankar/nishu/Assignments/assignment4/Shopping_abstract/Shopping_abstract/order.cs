﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shopping_abstract
{
  abstract  class  order
    {

      protected int orderId,itemQty,itemPrice;
      protected string custName;
      public order(int orderId,string  custName,int itemQty,int itemPrice)
      {
      this.orderId=orderId;
          this.custName=custName;
          
          this.itemQty=itemQty;
          this.itemPrice=itemPrice;
          Console.WriteLine("order created");
      }

      public abstract  int getAmount(int itemQty,int itemPrice);

      
      


    }
}
