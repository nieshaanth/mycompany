﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shopping_abstract
{
    class Program
    {
        static void Main(string[] args)
        {


            int orderId, itemPrice, itemQty;
            string custName;



            Console.WriteLine("enter the orderId");
            orderId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ënter the customer name");
            custName = Console.ReadLine();
            Console.WriteLine("ënter the orderQty");
            itemQty = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the orderPrice");
            itemPrice = Convert.ToInt32(Console.ReadLine());
             
            Console.WriteLine("enter the type of transaction 1.offshore 2.overseas");
            string type = Console.ReadLine();
            order obj;

            if (type == "overseas")
            {
                obj = new order_overseas(orderId, custName, itemQty, itemPrice);


            }
            else
            {
                obj = new orderoffshore(orderId, custName, itemQty, itemPrice);
            }


            int total = obj.getAmount(itemQty, itemPrice);
           Console.WriteLine("amount=" + total);
           Console.ReadLine();



        }
    }
}
