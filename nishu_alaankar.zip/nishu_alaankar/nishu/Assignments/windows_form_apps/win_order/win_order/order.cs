﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace win_order
{
    class order
    {
        int price, oid, qty, iid;
        DateTime dat;
        string name, payment, addr, city;
        public order(int price, int oid, int qty, int iid, string name,  string addr)
        {
            this.addr = addr;
        
          
            this.iid = iid;
            this.oid = oid;
            this.name = name;
            
            this.price = price;
            this.qty = qty;
        }

        public int getorderValue(int qty, int price)
        {
            return qty * price;
        }
    }
}
