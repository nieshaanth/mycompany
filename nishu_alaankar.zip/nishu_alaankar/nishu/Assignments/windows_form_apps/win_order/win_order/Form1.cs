﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace win_order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       

        private void btn_placeOrder_Click(object sender, EventArgs e)
        {


            
                if (txt_orderId.Text == "")
                {
                    MessageBox.Show("enter the order id");
                }
                    
                else if (txt_custName.Text == "")
                {
                    MessageBox.Show("enter the name");
                }
                else if (txt_addr.Text == "")
                {
                    MessageBox.Show("enter the address");
                }

                else if (txt_itemId.Text == "")
                {
                    MessageBox.Show("enter the itemid");
                }

                else if (txt_itemQty.Text == "")
                {
                    MessageBox.Show("enter the qty");
                }

                else if (txt_itemPrice.Text == "")
                {
                    MessageBox.Show("enter the price");
                }
                else
                {
                    int orderId = Convert.ToInt32(txt_orderId.Text);
                    string custName = txt_custName.Text;
                    string addr = txt_addr.Text;
                    int itemId = Convert.ToInt32(txt_itemId.Text);
                    int itemQty = Convert.ToInt32(txt_itemQty.Text);
                    int itemPrice = Convert.ToInt32(txt_itemPrice.Text);




                    order obj = new order(itemPrice, orderId, itemQty, orderId, custName, addr);
                    int tot = obj.getorderValue(itemQty, itemPrice);


                    txt_total.Text = tot.ToString();

                    MessageBox.Show(orderId + "\n" + custName + "\n" + itemId + "\n" + itemQty + "\n" + itemPrice + "\n" + itemQty + "\n" + cmb_city.Text );
                }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_city.Items.Add("Chennai");
            cmb_city.Items.Add("Mumbai");
            cmb_city.Items.Add("delhi");
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_itemId.Clear();
            txt_orderId.Clear();
            txt_custName.Clear();
            txt_addr.Clear();
            txt_itemId.Clear();
            txt_itemPrice.Clear();
            txt_total.Clear();
            
            txt_itemQty.Clear();
            cmb_city.Text=null;
            rdb_cod.Checked=false;
            rdb_debit.Checked=false;
            rdb_net.Checked=false;
            
        
        }

        
            

        

        

       

        private void cmb_city_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       

    }
}

