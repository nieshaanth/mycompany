﻿namespace win_order
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_orderId = new System.Windows.Forms.Label();
            this.lbl_custName = new System.Windows.Forms.Label();
            this.lbl_itemId = new System.Windows.Forms.Label();
            this.lbl_itemQty = new System.Windows.Forms.Label();
            this.lbl_itemPrice = new System.Windows.Forms.Label();
            this.lbl_orderCity = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_payment = new System.Windows.Forms.Label();
            this.txt_orderId = new System.Windows.Forms.TextBox();
            this.txt_custName = new System.Windows.Forms.TextBox();
            this.txt_itemId = new System.Windows.Forms.TextBox();
            this.txt_itemQty = new System.Windows.Forms.TextBox();
            this.txt_itemPrice = new System.Windows.Forms.TextBox();
            this.cmb_city = new System.Windows.Forms.ComboBox();
            this.rdb_cod = new System.Windows.Forms.RadioButton();
            this.rdb_debit = new System.Windows.Forms.RadioButton();
            this.rdb_net = new System.Windows.Forms.RadioButton();
            this.btn_placeOrder = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.lbl_total = new System.Windows.Forms.Label();
            this.lbl_addr = new System.Windows.Forms.Label();
            this.txt_addr = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // lbl_orderId
            // 
            this.lbl_orderId.AutoSize = true;
            this.lbl_orderId.Location = new System.Drawing.Point(59, 40);
            this.lbl_orderId.Name = "lbl_orderId";
            this.lbl_orderId.Size = new System.Drawing.Size(42, 13);
            this.lbl_orderId.TabIndex = 0;
            this.lbl_orderId.Text = "OrderId";
            // 
            // lbl_custName
            // 
            this.lbl_custName.AutoSize = true;
            this.lbl_custName.Location = new System.Drawing.Point(59, 84);
            this.lbl_custName.Name = "lbl_custName";
            this.lbl_custName.Size = new System.Drawing.Size(82, 13);
            this.lbl_custName.TabIndex = 1;
            this.lbl_custName.Text = "Customer Name";
            // 
            // lbl_itemId
            // 
            this.lbl_itemId.AutoSize = true;
            this.lbl_itemId.Location = new System.Drawing.Point(62, 189);
            this.lbl_itemId.Name = "lbl_itemId";
            this.lbl_itemId.Size = new System.Drawing.Size(39, 13);
            this.lbl_itemId.TabIndex = 2;
            this.lbl_itemId.Text = "Item Id";
            // 
            // lbl_itemQty
            // 
            this.lbl_itemQty.AutoSize = true;
            this.lbl_itemQty.Location = new System.Drawing.Point(59, 253);
            this.lbl_itemQty.Name = "lbl_itemQty";
            this.lbl_itemQty.Size = new System.Drawing.Size(46, 13);
            this.lbl_itemQty.TabIndex = 3;
            this.lbl_itemQty.Text = "Item Qty";
            // 
            // lbl_itemPrice
            // 
            this.lbl_itemPrice.AutoSize = true;
            this.lbl_itemPrice.Location = new System.Drawing.Point(59, 300);
            this.lbl_itemPrice.Name = "lbl_itemPrice";
            this.lbl_itemPrice.Size = new System.Drawing.Size(54, 13);
            this.lbl_itemPrice.TabIndex = 4;
            this.lbl_itemPrice.Text = "Item Price";
            // 
            // lbl_orderCity
            // 
            this.lbl_orderCity.AutoSize = true;
            this.lbl_orderCity.Location = new System.Drawing.Point(59, 346);
            this.lbl_orderCity.Name = "lbl_orderCity";
            this.lbl_orderCity.Size = new System.Drawing.Size(24, 13);
            this.lbl_orderCity.TabIndex = 5;
            this.lbl_orderCity.Text = "City";
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Location = new System.Drawing.Point(438, 9);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(30, 13);
            this.lbl_date.TabIndex = 6;
            this.lbl_date.Text = "Date";
            // 
            // lbl_payment
            // 
            this.lbl_payment.AutoSize = true;
            this.lbl_payment.Location = new System.Drawing.Point(59, 403);
            this.lbl_payment.Name = "lbl_payment";
            this.lbl_payment.Size = new System.Drawing.Size(92, 13);
            this.lbl_payment.TabIndex = 7;
            this.lbl_payment.Text = "Mode Of Payment";
            // 
            // txt_orderId
            // 
            this.txt_orderId.Location = new System.Drawing.Point(157, 40);
            this.txt_orderId.Name = "txt_orderId";
            this.txt_orderId.Size = new System.Drawing.Size(310, 20);
            this.txt_orderId.TabIndex = 1;
            // 
            // txt_custName
            // 
            this.txt_custName.Location = new System.Drawing.Point(157, 84);
            this.txt_custName.Name = "txt_custName";
            this.txt_custName.Size = new System.Drawing.Size(310, 20);
            this.txt_custName.TabIndex = 2;
            // 
            // txt_itemId
            // 
            this.txt_itemId.Location = new System.Drawing.Point(157, 189);
            this.txt_itemId.Name = "txt_itemId";
            this.txt_itemId.Size = new System.Drawing.Size(310, 20);
            this.txt_itemId.TabIndex = 4;
            // 
            // txt_itemQty
            // 
            this.txt_itemQty.Location = new System.Drawing.Point(157, 253);
            this.txt_itemQty.Name = "txt_itemQty";
            this.txt_itemQty.Size = new System.Drawing.Size(310, 20);
            this.txt_itemQty.TabIndex = 5;
            // 
            // txt_itemPrice
            // 
            this.txt_itemPrice.Location = new System.Drawing.Point(157, 293);
            this.txt_itemPrice.Name = "txt_itemPrice";
            this.txt_itemPrice.Size = new System.Drawing.Size(310, 20);
            this.txt_itemPrice.TabIndex = 6;
            // 
            // cmb_city
            // 
            this.cmb_city.FormattingEnabled = true;
            this.cmb_city.Location = new System.Drawing.Point(157, 343);
            this.cmb_city.Name = "cmb_city";
            this.cmb_city.Size = new System.Drawing.Size(121, 21);
            this.cmb_city.TabIndex = 7;
            this.cmb_city.Text = "choose your city";
            this.cmb_city.SelectedIndexChanged += new System.EventHandler(this.cmb_city_SelectedIndexChanged);
            // 
            // rdb_cod
            // 
            this.rdb_cod.AutoSize = true;
            this.rdb_cod.Location = new System.Drawing.Point(193, 403);
            this.rdb_cod.Name = "rdb_cod";
            this.rdb_cod.Size = new System.Drawing.Size(48, 17);
            this.rdb_cod.TabIndex = 8;
            this.rdb_cod.TabStop = true;
            this.rdb_cod.Text = "COD";
            this.rdb_cod.UseVisualStyleBackColor = true;
            // 
            // rdb_debit
            // 
            this.rdb_debit.AutoSize = true;
            this.rdb_debit.Location = new System.Drawing.Point(318, 403);
            this.rdb_debit.Name = "rdb_debit";
            this.rdb_debit.Size = new System.Drawing.Size(75, 17);
            this.rdb_debit.TabIndex = 9;
            this.rdb_debit.TabStop = true;
            this.rdb_debit.Text = "Debit Card";
            this.rdb_debit.UseVisualStyleBackColor = true;
            // 
            // rdb_net
            // 
            this.rdb_net.AutoSize = true;
            this.rdb_net.Location = new System.Drawing.Point(441, 403);
            this.rdb_net.Name = "rdb_net";
            this.rdb_net.Size = new System.Drawing.Size(84, 17);
            this.rdb_net.TabIndex = 10;
            this.rdb_net.TabStop = true;
            this.rdb_net.Text = "Net Banking";
            this.rdb_net.UseVisualStyleBackColor = true;
            // 
            // btn_placeOrder
            // 
            this.btn_placeOrder.Location = new System.Drawing.Point(62, 465);
            this.btn_placeOrder.Name = "btn_placeOrder";
            this.btn_placeOrder.Size = new System.Drawing.Size(213, 33);
            this.btn_placeOrder.TabIndex = 11;
            this.btn_placeOrder.Text = "Place Order";
            this.btn_placeOrder.UseVisualStyleBackColor = true;
            this.btn_placeOrder.Click += new System.EventHandler(this.btn_placeOrder_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(533, 475);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 12;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // txt_total
            // 
            this.txt_total.Location = new System.Drawing.Point(408, 344);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(100, 20);
            this.txt_total.TabIndex = 22;
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Location = new System.Drawing.Point(315, 346);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(58, 13);
            this.lbl_total.TabIndex = 23;
            this.lbl_total.Text = "Total Price";
            // 
            // lbl_addr
            // 
            this.lbl_addr.AutoSize = true;
            this.lbl_addr.Location = new System.Drawing.Point(62, 135);
            this.lbl_addr.Name = "lbl_addr";
            this.lbl_addr.Size = new System.Drawing.Size(44, 13);
            this.lbl_addr.TabIndex = 3;
            this.lbl_addr.Text = "address";
            // 
            // txt_addr
            // 
            this.txt_addr.Location = new System.Drawing.Point(158, 135);
            this.txt_addr.Name = "txt_addr";
            this.txt_addr.Size = new System.Drawing.Size(310, 20);
            this.txt_addr.TabIndex = 3;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(502, 9);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 27;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(917, 585);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txt_addr);
            this.Controls.Add(this.lbl_addr);
            this.Controls.Add(this.lbl_total);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_placeOrder);
            this.Controls.Add(this.rdb_net);
            this.Controls.Add(this.rdb_debit);
            this.Controls.Add(this.rdb_cod);
            this.Controls.Add(this.cmb_city);
            this.Controls.Add(this.txt_itemPrice);
            this.Controls.Add(this.txt_itemQty);
            this.Controls.Add(this.txt_itemId);
            this.Controls.Add(this.txt_custName);
            this.Controls.Add(this.txt_orderId);
            this.Controls.Add(this.lbl_payment);
            this.Controls.Add(this.lbl_date);
            this.Controls.Add(this.lbl_orderCity);
            this.Controls.Add(this.lbl_itemPrice);
            this.Controls.Add(this.lbl_itemQty);
            this.Controls.Add(this.lbl_itemId);
            this.Controls.Add(this.lbl_custName);
            this.Controls.Add(this.lbl_orderId);
            this.Name = "Form1";
            this.Text = "e";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_orderId;
        private System.Windows.Forms.Label lbl_custName;
        private System.Windows.Forms.Label lbl_itemId;
        private System.Windows.Forms.Label lbl_itemQty;
        private System.Windows.Forms.Label lbl_itemPrice;
        private System.Windows.Forms.Label lbl_orderCity;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label lbl_payment;
        private System.Windows.Forms.TextBox txt_orderId;
        private System.Windows.Forms.TextBox txt_custName;
        private System.Windows.Forms.TextBox txt_itemId;
        private System.Windows.Forms.TextBox txt_itemQty;
        private System.Windows.Forms.TextBox txt_itemPrice;
        private System.Windows.Forms.ComboBox cmb_city;
        private System.Windows.Forms.RadioButton rdb_cod;
        private System.Windows.Forms.RadioButton rdb_debit;
        private System.Windows.Forms.RadioButton rdb_net;
        private System.Windows.Forms.Button btn_placeOrder;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.TextBox txt_total;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.Label lbl_addr;
        private System.Windows.Forms.TextBox txt_addr;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}

