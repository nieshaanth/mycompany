﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace singleton
{
    class Program
    {
        public static void Main(string[] args)
        {
            manager obj1 = manager.getmanager();
            manager obj2 = manager.getmanager();
            manager obj3 = manager.getmanager();
            if (obj1 == obj2)
            { Console.WriteLine("Same Manäger    ");
            }
            Console.WriteLine(obj1+"\n"+obj3);
            Console.ReadLine();
            

        }
    }
}
