﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace singleton
{
    class manager
    {
        string managerName;
        int managerId;

        public string pmanagerName
        {
            get
            {
                return managerName;

            }
        }
        public int pmanagerId
        {
            get
            {
                return managerId;
            }
        }

        
        public manager(string managerName,int managerId)
        {
        this.managerId=managerId;
        this.managerName=managerName;
        }
        static manager m;

        public static  manager getmanager()
        {
            if (m == null)
            {
                 m = new manager("abc", 21);
            }
            return m;
        }
    }
}
