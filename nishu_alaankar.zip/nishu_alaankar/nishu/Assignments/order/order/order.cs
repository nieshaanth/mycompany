﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace assignment2
{
    class order
    {
        int orderId=0, itemId, itemQty, itemPrice;
        string customerName;
        
        public order()
        {
            Console.WriteLine("order id" + orderId++);
            Console.WriteLine("enter ur name");
            customername = Console.ReadLine();
            Console.WriteLine("enter the item id");
            itemId = Console.ReadLine();
            Console.WriteLine("enter the qty");
            itemQty = Console.ReadLine();
            Console.WriteLine("enter the price of item");
            itemPrice = Console.ReadLine();
               

        
                 
            
        }
        



        public string pcustomerName
        {
            get
            {
                return customerName;
            }
            set
            {
                customerName = value;

            }
        }
        public int pitemId
        {
            get 
            { return itemId;
            }
            set
            {
                itemId = value;
            }
        }
        public int pitemQty
        {
            get
            {
                return itemQty;
            }
            set 
            {
                itemQty = value;
            }
        }

        public int pitemPrice
        {
            get
            {
                return itemPricel;
            }
            set
            {
                itemPrice = value;
            }
        }
               
        public int orderValue
        {
              get{  return itemQty*itemPrice;
        }
        }

      }



}
