﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int n=0;
            Console.WriteLine("1.Order   2.exit");
            n=Convert.ToInt32(Console.ReadLine());
            while (n != 2)
            { 
                
            }

        }
    }
}
