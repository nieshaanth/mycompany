﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace employee_interface
{
    class Program
    {
        static void Main(string[] args)
        {
            string empName, empCity, empAddr, empProjdetails, empBankName;
            int empId, empSalary, empExp, empAccountno, empAge;

            Console.WriteLine("enter the employee name");
            empName=Console.ReadLine();

            Console.WriteLine("enter the employee city");
            empCity = Console.ReadLine();

            Console.WriteLine("enter the employee address");
           empAddr= Console.ReadLine();

            Console.WriteLine("enter the employee project details");
            empProjdetails= Console.ReadLine();

            Console.WriteLine("enter the employee bank name ");
            empBankName= Console.ReadLine();

            Console.WriteLine("enter the employee id");
           empId=Convert.ToInt32( Console.ReadLine());

           Console.WriteLine("enter the employee salary");
            empSalary= Convert.ToInt32( Console.ReadLine());

            Console.WriteLine("enter the employee experience ");
           empExp= Convert.ToInt32( Console.ReadLine());

          Console.WriteLine("enter the employee account no");
              empAccountno=Convert.ToInt32( Console.ReadLine());

           Console.WriteLine("enter the employee age");
           empAge=  Convert.ToInt32( Console.ReadLine());


           employee obj = new employee(empName, empCity, empAddr, empProjdetails, empBankName, empId, empSalary, empExp, empAccountno, empAge);

           hr obj1 = new hr();
         string tot=  obj1.rec_hr();
         Console.WriteLine(tot);

           Console.ReadLine();

           
            

        }
    }
}
