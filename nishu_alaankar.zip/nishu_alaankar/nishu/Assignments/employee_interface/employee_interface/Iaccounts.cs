﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace employee_interface
{
    interface Iaccounts
    {
        int getempSal();
        int getempId();
        int getempAccno();
        
    }
}
