﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace employee_interface
{
    interface Imanager
    {

        int getempId();
        int getempExp();
        string getempProjdetails();
    }
}
