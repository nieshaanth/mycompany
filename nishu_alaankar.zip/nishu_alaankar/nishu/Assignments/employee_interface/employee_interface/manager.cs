﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace employee_interface
{
    class manager
    {

        public void rec_manager(Imanager obj)
        {
            int id2 = obj.getempId();
            int exp = obj.getempExp();
            string empProjdetails = obj.getempProjdetails();
        }

    }
}
