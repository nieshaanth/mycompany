﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace employee_interface
{
    class accounts
    {
        public void rec_accounts(Iaccounts obj)
        {
            int sal1 = obj.getempSal();
            int id1 = obj.getempId();
            int acc1 = obj.getempAccno();
            Console.WriteLine(sal1 + " " + id1 + " " + acc1);
        }


    }






}
