﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace employee_interface
{
    class employee
    {
        string empName, empCity, empAddr, empProjdetails,  empBankName;
        int empId, empSalary, empExp, empAccountno,empAge;

        public employee(string empName, string empCity, string empAddr, string empProjdeatils, string empBankName, int empId, int empSalary, int empExp, int empAccountno, int empAge)
        {
            this.empAccountno = empAccountno;
            this.empAddr = empAddr;
            this.empAge = empAge;
            this.empBankName = empBankName;
            this.empCity = empCity;
            this.empExp = empExp;
            this.empId = empId;
            this.empName = empName;
            this.empProjdetails = empProjdetails;
            this.empSalary = empSalary;
            
        }

        public string getempAddr()
        {
            return empAddr;
        }

        public int getempSalary()
        {
        return empSalary;
        }

        public int getempId()
        {
        return empId;
        }

        public int getempAccountno()
        {
        return empAccountno;
        }

        public string getempProjdetails()
        {
            return empProjdetails;

        }

        public int getexp()
        {
            return empExp;
        }
        

        
        
        }
}
