﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace employee_interface
{
    class hr
    {

        public void rec_hr(Ihr obj)
        {
            string addr = obj.getempAddr();
            int sal = obj.getempSalary();
            int id = obj.getempId();
            Console.WriteLine(id+" "+addr+" "+sal);


        }
    }
}
