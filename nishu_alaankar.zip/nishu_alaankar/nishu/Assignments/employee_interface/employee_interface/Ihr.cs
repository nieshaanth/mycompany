﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace employee_interface
{
    interface Ihr
    {
        string getempAddr();
        int getempSalary();
        int getempId();
    }
}
