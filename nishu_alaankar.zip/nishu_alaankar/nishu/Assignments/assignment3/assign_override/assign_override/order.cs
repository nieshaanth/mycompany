﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace assign_override
{
    class order
    {
        string custName;
        int itemQty, itemPrice, orderId;

    }
}
