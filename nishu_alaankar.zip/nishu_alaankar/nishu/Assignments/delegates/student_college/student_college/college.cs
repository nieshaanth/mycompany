﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace student_college
{
    class college
    {

        int collegeId;
        string collegeName;
        List<student> studlist = new List<student>();
        List<student> studlist_leaveReq = new List<student>();

        public college(int collegeId, string collegeName)
        {
            this.collegeId = collegeId;
            this.collegeName = collegeName;
        }


        public void notify(int studId, string msg)
        { 
        Console.WriteLine("College:"+studId+" "+msg);
        studlist_leaveReq.Add(searchstudent(studId));
            
        }

        public void student_leave_request_approval()
        {
            foreach (student s in studlist_leaveReq)
            {
                s.leav_approval();
            }
            studlist_leaveReq.Clear();
        }

        public student searchstudent(int studId)
        {
            foreach (student s in studlist)
            {
                if (s.PstudId == studId)
                {
                    return s;
                }
            }
            return null;
        }


        public void addstudent(student s)
        {
            studlist.Add(s);

            s.evt_leaveReq += new student.delleave(notify);
        }

        public void showEmployee()
        {
            foreach (student s in studlist)
            {
                Console.WriteLine(s.ToString());

            }
        }

     }
    }


