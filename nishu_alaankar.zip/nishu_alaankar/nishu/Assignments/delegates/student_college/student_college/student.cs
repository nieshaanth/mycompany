﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace student_college
{
    class student
    {
        int studId;
        string studName;

        public int PstudId
        {
            get
            {
                return studId;
            }
        }

        public student(int studId,string studName)
            {
                this.studId = studId;
                this.studName = studName;

    
            }

        public override string ToString()
        {
            {
                return studId+" "+studName+" leave confimation"+leav_status ;
            }
        }

        public delegate void delleave(int studId, string msg);
        public event delleave evt_leaveReq;
        public void leaveReq(string msg)
        {
            if (evt_leaveReq != null)
            {
                evt_leaveReq(studId, msg);

            }
        }

        bool leav_status=false;

        public bool Pstatus
        {
            get
            {
                return leav_status;

            }
        }

        public void leav_approval()
        {
            leav_status = true;

        }




    }
}
