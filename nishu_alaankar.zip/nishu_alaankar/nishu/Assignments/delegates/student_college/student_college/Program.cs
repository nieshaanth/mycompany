﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace student_college
{
    class Program
    {
        static void Main(string[] args)
        {

            college col = new college(4125, "abc");

            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1.add student 2. find student 3.college approval 4.exit");
               int option=Convert.ToInt32(Console.ReadLine());
               switch (option)
               {
                   case 1:


                       Console.WriteLine("enter the stud id");
                       int studId = Convert.ToInt32(Console.ReadLine());
                       Console.WriteLine("Enter the stud name");
                       string studName = Console.ReadLine();

                       student stud = new student(studId, studName);
                       col.addstudent(stud);
                       Console.WriteLine("student added Succecfully");
                       break;


                   case 2:
                       Console.WriteLine("enter the student id to found");
                       int find_sid = Convert.ToInt32(Console.ReadLine());
                       student stud1 = col.searchstudent(find_sid);

                       if (stud1 == null)
                       {
                           Console.WriteLine("studentId is not found");

                       }
                       else
                       {

                           Console.WriteLine("enter 1.show 2.leave request");

                           int opt = Convert.ToInt32(Console.ReadLine());
                           if (opt == 1)
                           {
                               Console.WriteLine(stud1.ToString());


                           }
                           else
                           {
                               Console.WriteLine("ënter the reason");
                               string reason = Console.ReadLine();
                               stud1.leaveReq(reason);

                           }

                           Console.WriteLine("student id is found");

                       }

                       break;

                   case 3:
                       col.student_leave_request_approval();
                       break;

                   case 4:
                       flag = false;
                       break;




               }
            }
        }
    }
}
