﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int customer_id = 0;
            int deposit = 0;
            int withdraw = 0;
            string customer_name, type_of_account;
            int exit = 1;
            int balance = 0;
            while (exit == 1)
            {
                Console.WriteLine("-------------------------------------------\n\nEnter your choice\n 1.New Account 2.Deposit 3.Withdraw 4.Check_Balance 5.Exit\n\n");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("\n--------------     Welcome    ---------------- \n\nNew Account Details\n\nEnter your Customer id\n");
                        customer_id = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("\nEnter your name\n\n");
                        customer_name = Console.ReadLine();
                        Console.WriteLine("\nEnter the which type of account you need 1.Savings 2.Current\n");
                        type_of_account = Console.ReadLine();

                        Console.WriteLine("\n-------------------------------------------------------\nAccount Details\n Account NO : " + customer_id + "\n Customer Name : " + customer_name + "\n Type Of Account : " + type_of_account + "\n Balance : " + balance);
                        break;
                    case 2:
                        Console.WriteLine("\n\nDeposit \n How much you need to deposit?\n\n");
                        deposit = Convert.ToInt32(Console.ReadLine());
                        if (deposit < 500)
                        {
                            Console.WriteLine("\n\nSry ! Minimum Deposit Amount is Rs.500 \nPls Try again\n\n");
                        }
                        else
                        {
                            Console.WriteLine("\n\nYou have deposited " + deposit + " in your  Account\n\n");
                            balance = balance + deposit;
                        }
                        break;
                    case 3:
                        Console.WriteLine("\n\nWithdraw \n Enter the amount to be Withdrawn\n\n");
                        withdraw = Convert.ToInt32(Console.ReadLine());
                        if (withdraw >= 5000)
                        {
                            Console.WriteLine("\n\nYou have exceeded the limit of withdrawal amount\nWithdrawal Limit is 5000 per day\n\n");
                        }
                        else if (withdraw > deposit)
                        { Console.WriteLine("\n\nSry You Have Low Balance. Your transaction Cannot br Processed\n\n"); }
                        else
                        {
                            Console.WriteLine("Your Transaction is Completed. ");

                            balance = deposit - withdraw;
                        }
                        break;
                    case 4:
                        Console.WriteLine("\n\nAccount Balance\n You have " + balance + "  in your account\n\n");
                        break;
                    case 5:
                        Console.WriteLine("\n\nThank you For visiting Our page !!Come Again Later\n\n");
                        exit = 0;
                        break;


                    default:
                        Console.WriteLine("\n\nNo Such Option Exists \n Sry Please Try Again\n\n");
                        break;



                }
            }
        }
    }
}
